#!/usr/bin/env python3
"""
SPACE INVADERS
==============
Launch script for the Space Invaders terminal arcade game.
"""

from space_invaders import main

if __name__ == "__main__":
    main()
