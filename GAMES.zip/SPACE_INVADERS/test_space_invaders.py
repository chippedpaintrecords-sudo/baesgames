import unittest
from unittest.mock import patch

from space_invaders import Bomb, Laser, SpaceInvaders


NO_ACTIONS = {
    "left": False,
    "right": False,
    "fire": False,
    "pause": False,
    "mute": False,
    "quit": False,
    "restart": False,
    "start": False,
}


class GameplayTests(unittest.TestCase):
    def setUp(self):
        self.patches = [
            patch("space_invaders.SoundManager"),
            patch("space_invaders.InputHandler"),
            patch("space_invaders.load_high_score", return_value=0),
            patch("space_invaders.save_high_score"),
        ]
        for active_patch in self.patches:
            active_patch.start()
            self.addCleanup(active_patch.stop)
        self.game = SpaceInvaders()
        self.game.init_wave(1)
        self.game.player_invuln_timer = 0

    def test_laser_travels_same_distance_with_different_frame_sizes(self):
        self.game.aliens = []
        self.game.bunkers = []
        self.game.lasers = [Laser(0, 15)]
        for _ in range(20):
            self.game._update_playing(0.02, NO_ACTIONS)
        self.assertEqual(self.game.lasers[0].y, 5)

        self.game.lasers = [Laser(0, 15)]
        for _ in range(4):
            self.game._update_playing(0.1, NO_ACTIONS)
        self.assertEqual(self.game.lasers[0].y, 5)

    def test_laser_hits_alien_across_multiple_cells_and_saves_bonus(self):
        alien = self.game.aliens[0]
        self.game.aliens = [alien]
        self.game.lasers = [Laser(alien.x, alien.y + 4)]

        self.game._update_playing(0.2, NO_ACTIONS)

        self.assertEqual(self.game.state, "WAVE_CLEAR")
        self.assertEqual(self.game.score, alien.points + 1000)
        self.assertEqual(self.game.high_score, self.game.score)
        from space_invaders import save_high_score
        save_high_score.assert_called_with(self.game.score)

    def test_bomb_hits_player_across_multiple_cells(self):
        self.game.aliens = []
        self.game.bombs = [Bomb(self.game.player_x + 2, self.game.player_y_turret - 3, 0)]

        self.game._update_playing(0.3, NO_ACTIONS)

        self.assertEqual(self.game.state, "PLAYER_HIT")
        self.assertEqual(self.game.lives, 2)


if __name__ == "__main__":
    unittest.main()
