# 👾 SPACE INVADERS - Terminal Arcade Edition

A feature-complete, retro-authentic clone of the classic 1978 **Space Invaders** arcade game, built in Python and played entirely in your terminal with zero external dependencies!

---

## 🕹️ Quick Start

To launch and play the game:

```bash
python main.py
```
*(or `python space_invaders.py`)*

> **Tip:** For the best visual experience, maximize or enlarge your terminal window (at least 80 columns by 30 rows). The game will automatically center itself within your window.

---

## 🎮 Controls

| Action | Keys |
| :--- | :--- |
| **Move Left** | `A` or `←` (Left Arrow) |
| **Move Right** | `D` or `→` (Right Arrow) |
| **Fire Laser** | `Spacebar` or `W` or `↑` (Up Arrow) |
| **Pause / Resume** | `P` |
| **Mute / Unmute Audio** | `M` |
| **Restart (Game Over)** | `R` or `Spacebar` |
| **Quit Game** | `Q` or `Esc` |

---

## 🏆 Scoring & Advance Table

| Target | Sprite | Points | Description |
| :--- | :---: | :---: | :--- |
| **Mystery UFO** | `<(o-o)>` | **50 - 300** | Periodically zooms across the top of the screen |
| **Squid (Commander)** | `/""\` / `\""/` | **30** | Top row invader |
| **Crab** | `{oo}` / `<oo>` | **20** | Middle two rows |
| **Octopus** | `[▼▼]` / `(▼▼)` | **10** | Bottom two rows |
| **Wave Clear Bonus** | — | **+1,000 × Wave** | Awarded upon clearing the invader fleet |

---

## ✨ Features

- **Flicker-Free ANSI Rendering**: Uses a double-buffered character and color matrix written in a single pass with cursor repositioning (`\033[H`). Zero screen flashing or tearing.
- **Classic Invader March Physics**:
  - The fleet marches left and right, stepping downward and reversing direction upon hitting the boundary.
  - Authentic tempo acceleration: as you eliminate aliens, the remaining invaders march faster and faster, reaching lightning-fast speeds for the final lone alien!
- **Consistent Projectile Speed**: Lasers and bombs move at the same speed across different terminal frame rates, and every crossed cell is checked for hits.
- **Destructible Bunkers (Shields)**:
  - 4 defensive bunkers with multi-hit health blocks (`█` full health, `▒` damaged, ` ` destroyed).
  - Both player lasers and alien bombs carve realistic craters into bunker defenses.
  - Invaders will crush and chew through any bunker blocks they touch as they descend.
- **Mystery Flying Saucer (UFO)**:
  - Spawns at random intervals and flies along the top lane with retro audio sirens.
  - Awards mystery bonus points (50, 100, 150, 200, or 300) when shot down!
- **Alien Bomb Attacks**:
  - Lowest living aliens in active columns drop 3 types of projectiles: fast beams (`│`), plunger bombs (`v`), and rolling squiggly bombs (`§`/`~`).
- **Retro Audio Synthesizer**:
  - Multi-threaded chiptune audio generator utilizing `winsound` on Windows.
  - Plays the 4-tone descending bass march, laser fire sweeps, explosion rumbles, UFO sirens, and wave clear fanfares without dropping a single frame!
  - Press `M` at any time to toggle sound on or off.
- **Particles & FX**:
  - Multi-particle debris explosions when enemies and bunkers are hit.
  - Floating score popups (`+30`, `+100`, `+300!`).
  - Twinkling deep space starfield in the background.
- **Wave Progression & Difficulty Scaling**:
  - Clearing a wave advances to the next wave, starting the fleet lower down, accelerating base marching speed, and increasing bomb drop rates.
- **Persistent High Scores**:
  - Saves a new high score as soon as it is earned, including wave bonuses, so returning to the title screen keeps it.
- **Pure Standard Library**:
  - Requires no `pip install` packages. Runs out of the box with standard Python 3!
