#!/usr/bin/env python3
"""
SPACE INVADERS - Classic Arcade Terminal Clone
===============================================
A complete, retro-authentic Space Invaders arcade clone designed for the terminal.
Features:
  - 100% Flicker-free ANSI double-buffered rendering
  - Authentic alien fleet marching with accelerating tempo
  - Destructible multi-hit bunkers with erosion physics
  - Mystery UFO (flying saucer) with bonus points
  - Multi-threaded retro chiptune audio synthesizer (mute toggle with 'M')
  - Explosions, particle effects, and floating score popups
  - Wave progression & persistent high-score tracking
  - Cross-platform support (Windows msvcrt + Unix termios/select fallback)
"""

import sys
import os
import time
import json
import random
import queue
import threading

# ---------------------------------------------------------------------------
# Platform and Terminal Configuration
# ---------------------------------------------------------------------------

IS_WINDOWS = sys.platform == "win32"

if IS_WINDOWS:
    import msvcrt
    import ctypes
    # Enable Virtual Terminal Processing for ANSI colors & UTF-8 output
    try:
        sys.stdout.reconfigure(encoding="utf-8")
    except Exception:
        pass
    try:
        kernel32 = ctypes.windll.kernel32
        kernel32.SetConsoleOutputCP(65001)
        kernel32.SetConsoleCP(65001)
        h_stdout = kernel32.GetStdHandle(-11)  # STD_OUTPUT_HANDLE
        mode = ctypes.c_ulong()
        if kernel32.GetConsoleMode(h_stdout, ctypes.byref(mode)):
            mode.value |= 0x0004  # ENABLE_VIRTUAL_TERMINAL_PROCESSING
            kernel32.SetConsoleMode(h_stdout, mode)
    except Exception:
        pass
else:
    import select
    import tty
    import termios


# ---------------------------------------------------------------------------
# ANSI Color Codes & Styles
# ---------------------------------------------------------------------------

RESET = "\033[0m"
BOLD = "\033[1m"
DIM = "\033[2m"

# Foreground Colors
C_RED = "\033[91m"
C_GREEN = "\033[92m"
C_YELLOW = "\033[93m"
C_BLUE = "\033[94m"
C_MAGENTA = "\033[95m"
C_CYAN = "\033[96m"
C_WHITE = "\033[97m"
C_GRAY = "\033[90m"
C_ORANGE = "\033[38;5;208m"

# Cursor Controls
CURSOR_HIDE = "\033[?25l"
CURSOR_SHOW = "\033[?25h"
CURSOR_HOME = "\033[H"
CLEAR_SCREEN = "\033[2J"


# ---------------------------------------------------------------------------
# Non-blocking Keyboard Input Handler
# ---------------------------------------------------------------------------

class InputHandler:
    def __init__(self):
        self.old_term_settings = None
        if not IS_WINDOWS:
            try:
                self.old_term_settings = termios.tcgetattr(sys.stdin)
                tty.setcbreak(sys.stdin.fileno())
            except Exception:
                pass

    def cleanup(self):
        if not IS_WINDOWS and self.old_term_settings:
            try:
                termios.tcsetattr(sys.stdin, termios.TCSADRAIN, self.old_term_settings)
            except Exception:
                pass

    def poll_keys(self):
        """Returns a dict of action flags detected in the input buffer."""
        actions = {
            "left": False,
            "right": False,
            "fire": False,
            "pause": False,
            "mute": False,
            "quit": False,
            "restart": False,
            "start": False,
        }

        if IS_WINDOWS:
            while msvcrt.kbhit():
                try:
                    ch = msvcrt.getch()
                except Exception:
                    break
                if ch in (b"\x00", b"\xe0"):
                    try:
                        ch2 = msvcrt.getch()
                    except Exception:
                        break
                    if ch2 == b"K":  # Left Arrow
                        actions["left"] = True
                    elif ch2 == b"M":  # Right Arrow
                        actions["right"] = True
                    elif ch2 == b"H":  # Up Arrow
                        actions["fire"] = True
                else:
                    c = ch.decode("latin1", errors="ignore").lower()
                    if c in ("a",):
                        actions["left"] = True
                    elif c in ("d",):
                        actions["right"] = True
                    elif c in (" ", "w"):
                        actions["fire"] = True
                        actions["start"] = True
                    elif c in ("p",):
                        actions["pause"] = True
                    elif c in ("m",):
                        actions["mute"] = True
                    elif c in ("q", "\x1b"):
                        actions["quit"] = True
                    elif c in ("r",):
                        actions["restart"] = True
                    elif c in ("\r", "\n"):
                        actions["start"] = True
        else:
            while True:
                rlist, _, _ = select.select([sys.stdin], [], [], 0)
                if not rlist:
                    break
                try:
                    ch = sys.stdin.read(1)
                except Exception:
                    break
                if ch == "\033":
                    # Escape sequence for arrow keys
                    seq = ""
                    rlist2, _, _ = select.select([sys.stdin], [], [], 0.01)
                    if rlist2:
                        seq += sys.stdin.read(1)
                        if seq == "[":
                            rlist3, _, _ = select.select([sys.stdin], [], [], 0.01)
                            if rlist3:
                                code = sys.stdin.read(1)
                                if code == "D":
                                    actions["left"] = True
                                elif code == "C":
                                    actions["right"] = True
                                elif code == "A":
                                    actions["fire"] = True
                    else:
                        actions["quit"] = True
                else:
                    c = ch.lower()
                    if c in ("a",):
                        actions["left"] = True
                    elif c in ("d",):
                        actions["right"] = True
                    elif c in (" ", "w"):
                        actions["fire"] = True
                        actions["start"] = True
                    elif c in ("p",):
                        actions["pause"] = True
                    elif c in ("m",):
                        actions["mute"] = True
                    elif c in ("q",):
                        actions["quit"] = True
                    elif c in ("r",):
                        actions["restart"] = True
                    elif c in ("\r", "\n"):
                        actions["start"] = True

        return actions


# ---------------------------------------------------------------------------
# Retro Chiptune Audio Synthesizer (Background Worker)
# ---------------------------------------------------------------------------

class SoundManager:
    """Threaded sound synthesizer producing retro arcade effects."""
    def __init__(self):
        self.enabled = True
        self.queue = queue.Queue(maxsize=10)
        self.running = True
        self.thread = threading.Thread(target=self._worker, daemon=True)
        self.thread.start()

    def _worker(self):
        while self.running:
            try:
                item = self.queue.get(timeout=0.1)
            except queue.Empty:
                continue
            if item is None:
                break
            freq, dur = item
            if self.enabled and IS_WINDOWS:
                try:
                    import winsound
                    winsound.Beep(freq, dur)
                except Exception:
                    pass
            self.queue.task_done()

    def play(self, freq, dur=35):
        if not self.enabled or not IS_WINDOWS:
            return
        if not self.queue.full():
            try:
                self.queue.put_nowait((freq, dur))
            except queue.Full:
                pass

    def march_step(self, step_idx):
        tones = [165, 147, 131, 116]
        self.play(tones[step_idx % 4], 30)

    def shoot(self):
        self.play(980, 25)

    def invader_hit(self):
        self.play(180, 45)

    def ufo_tone(self, step):
        self.play(680 if step % 2 == 0 else 820, 30)

    def player_hit(self):
        self.play(95, 120)

    def wave_clear(self):
        # Arpeggio
        for f in (523, 659, 784, 1046):
            self.play(f, 60)

    def toggle(self):
        self.enabled = not self.enabled
        return self.enabled

    def stop(self):
        self.running = False
        try:
            self.queue.put_nowait(None)
        except Exception:
            pass


# ---------------------------------------------------------------------------
# High Score Manager
# ---------------------------------------------------------------------------

SCORE_FILE = os.path.join(os.path.dirname(os.path.abspath(__file__)), "highscore.json")

def load_high_score():
    try:
        if os.path.exists(SCORE_FILE):
            with open(SCORE_FILE, "r", encoding="utf-8") as f:
                data = json.load(f)
                return int(data.get("high_score", 0))
    except Exception:
        pass
    return 0

def save_high_score(score):
    try:
        data = {"high_score": score}
        with open(SCORE_FILE, "w", encoding="utf-8") as f:
            json.dump(data, f)
    except Exception:
        pass


# ---------------------------------------------------------------------------
# Game Sprites & Entities
# ---------------------------------------------------------------------------

# Alien Sprites (Width 4, Height 1)
# Squid (Top Row - 30 pts)
SPRITE_SQUID = [
    '/""\\',  # Frame 0
    '\\""/',  # Frame 1
]
# Crab (Middle Rows - 20 pts)
SPRITE_CRAB = [
    r"{oo}",  # Frame 0
    r"<oo>",  # Frame 1
]
# Octopus (Bottom Rows - 10 pts)
SPRITE_OCTO = [
    r"[▼▼]",  # Frame 0
    r"(▼▼)",  # Frame 1
]

# Player Cannon
CANNON_TURRET = r"  ▲  "
CANNON_BASE   = r"[███]"

# Mystery UFO
SPRITE_UFO = r"<(o-o)>"  # 7 chars wide

# Bunker Initial Grid (Height 3, Width 7)
# 2 = Full Health '█', 1 = Damaged '▒', 0 = Empty ' '
BUNKER_TEMPLATE = [
    [0, 2, 2, 2, 2, 2, 0],
    [2, 2, 2, 2, 2, 2, 2],
    [2, 2, 0, 0, 0, 2, 2],
]


class Alien:
    def __init__(self, row, col, kind, points, color):
        self.row = row
        self.col = col
        self.kind = kind  # 0: Squid, 1: Crab, 2: Octopus
        self.points = points
        self.color = color
        self.alive = True
        self.x = 0
        self.y = 0


class Bunker:
    def __init__(self, x, y):
        self.x = x
        self.y = y
        self.w = 7
        self.h = 3
        # Deep copy template
        self.grid = [row[:] for row in BUNKER_TEMPLATE]

    def hit(self, local_x, local_y):
        """Damage a block and potentially cause small blast crater."""
        if 0 <= local_y < self.h and 0 <= local_x < self.w:
            if self.grid[local_y][local_x] > 0:
                self.grid[local_y][local_x] -= 1
                # Small chance of cratering neighbor block
                if random.random() < 0.35:
                    nx = local_x + random.choice([-1, 1])
                    if 0 <= nx < self.w and self.grid[local_y][nx] > 0:
                        self.grid[local_y][nx] -= 1
                return True
        return False


class Laser:
    def __init__(self, x, y):
        self.x = x
        self.y = y
        self.travel = 0.0


class Bomb:
    def __init__(self, x, y, bomb_type):
        self.x = x
        self.y = y
        self.type = bomb_type  # 0: Straight beam, 1: Plunger, 2: Squiggly
        self.frame = 0
        self.travel = 0.0


def projectile_steps(projectile, dt, cells_per_second):
    """Keep fractional travel so projectile speed does not depend on FPS."""
    projectile.travel += dt * cells_per_second
    steps = int(projectile.travel)
    projectile.travel -= steps
    return steps


class UFO:
    def __init__(self, width):
        self.active = False
        self.x = 0
        self.y = 0  # Local row 0
        self.dx = 1
        self.width = width
        self.step_timer = 0
        self.sound_step = 0

    def spawn(self):
        self.active = True
        self.y = 0
        self.sound_step = 0
        if random.random() < 0.5:
            self.x = 1
            self.dx = 1
        else:
            self.x = self.width - 8
            self.dx = -1

    def update(self, dt, sound_mgr):
        if not self.active:
            return
        self.step_timer += dt
        if self.step_timer >= 0.08:
            self.step_timer = 0
            self.x += self.dx
            self.sound_step += 1
            if self.sound_step % 3 == 0:
                sound_mgr.ufo_tone(self.sound_step)
            if self.dx > 0 and self.x > self.width - 8:
                self.active = False
            elif self.dx < 0 and self.x < 1:
                self.active = False


class Particle:
    def __init__(self, x, y, char, color, life, dx, dy):
        self.x = float(x)
        self.y = float(y)
        self.char = char
        self.color = color
        self.life = life
        self.dx = dx
        self.dy = dy


class FloatingText:
    def __init__(self, x, y, text, color, life=14):
        self.x = x
        self.y = y
        self.text = text
        self.color = color
        self.life = life


# ---------------------------------------------------------------------------
# Space Invaders Main Game Engine
# ---------------------------------------------------------------------------

class SpaceInvaders:
    # Dimensions of playable canvas
    CANVAS_WIDTH = 70
    CANVAS_HEIGHT = 24

    def __init__(self):
        self.sound_mgr = SoundManager()
        self.input_handler = InputHandler()
        self.high_score = load_high_score()
        self.state = "TITLE"  # TITLE, PLAYING, PAUSED, WAVE_CLEAR, PLAYER_HIT, GAME_OVER

        # Game Session Variables
        self.score = 0
        self.lives = 3
        self.wave = 1
        self.new_high_score = False

        # Canvas & Layout
        self.player_x = (self.CANVAS_WIDTH - 5) // 2
        self.player_y_turret = 21
        self.player_y_base = 22
        self.player_invuln_timer = 0.0
        self.player_shoot_cooldown = 0.0

        # Lasers & Bombs
        self.lasers = []  # Player lasers
        self.bombs = []   # Alien bombs
        self.bomb_timer = 0.0
        self.bomb_interval = 1.1

        # Alien Fleet
        self.aliens = []
        self.fleet_x = 12
        self.fleet_y = 2
        self.fleet_dx = 1
        self.fleet_frame = 0
        self.fleet_move_timer = 0.0
        self.march_sound_idx = 0
        self.total_wave_aliens = 40

        # Bunkers
        self.bunkers = []

        # Mystery UFO
        self.ufo = UFO(self.CANVAS_WIDTH)
        self.ufo_spawn_timer = random.uniform(15.0, 25.0)

        # Visual Effects
        self.particles = []
        self.floating_texts = []
        self.stars = []
        self._init_stars()

        # State transition timers
        self.state_timer = 0.0

        # Title Screen pulse
        self.title_pulse = 0.0

    def _init_stars(self):
        """Generate subtle background stars for deep space ambiance."""
        rng = random.Random(42)
        self.stars = []
        for _ in range(24):
            sx = rng.randint(0, self.CANVAS_WIDTH - 1)
            sy = rng.randint(0, self.CANVAS_HEIGHT - 2)
            char = rng.choice([".", "·", "*", "+"])
            self.stars.append((sx, sy, char))

    def reset_session(self):
        self.score = 0
        self.lives = 3
        self.wave = 1
        self.new_high_score = False
        self.init_wave(1)
        self.state = "PLAYING"

    def init_wave(self, wave_num):
        self.wave = wave_num
        self.lasers.clear()
        self.bombs.clear()
        self.bomb_timer = 0.0
        self.particles.clear()
        self.floating_texts.clear()
        self.ufo.active = False
        self.ufo.step_timer = 0.0
        self.ufo_spawn_timer = random.uniform(15.0, 25.0)

        # Player setup
        self.player_x = (self.CANVAS_WIDTH - 5) // 2
        self.player_invuln_timer = 1.5
        self.player_shoot_cooldown = 0.0

        # Fleet setup (5 rows x 8 cols = 40 aliens)
        self.aliens.clear()
        # Waves start lower down (up to row 6)
        start_y = min(2 + (wave_num - 1), 6)
        self.fleet_x = 11
        self.fleet_y = start_y
        self.fleet_dx = 1
        self.fleet_frame = 0
        self.fleet_move_timer = 0.0
        self.march_sound_idx = 0
        self.bomb_interval = max(0.55, 1.2 - (wave_num - 1) * 0.15)

        for r in range(5):
            for c in range(8):
                if r == 0:
                    kind = 0  # Squid (Row 0)
                    pts = 30
                    color = C_MAGENTA
                elif r in (1, 2):
                    kind = 1  # Crab (Rows 1-2)
                    pts = 20
                    color = C_CYAN
                else:
                    kind = 2  # Octopus (Rows 3-4)
                    pts = 10
                    color = C_GREEN
                alien = Alien(r, c, kind, pts, color)
                self.aliens.append(alien)
        self.total_wave_aliens = len(self.aliens)
        self._update_alien_positions()

        # Re-build / Repair 4 Bunkers
        self.bunkers = [
            Bunker(7, 17),
            Bunker(23, 17),
            Bunker(39, 17),
            Bunker(55, 17),
        ]

    def _update_alien_positions(self):
        for a in self.aliens:
            if a.alive:
                a.x = self.fleet_x + a.col * 6
                a.y = self.fleet_y + a.row * 2

    def _add_score(self, points):
        self.score += points
        if self.score > self.high_score:
            self.high_score = self.score
            self.new_high_score = True
            save_high_score(self.high_score)

    # -----------------------------------------------------------------------
    # Game Loop Updates
    # -----------------------------------------------------------------------

    def update(self, dt, actions):
        if actions["mute"]:
            self.sound_mgr.toggle()

        if self.state == "TITLE":
            self.title_pulse += dt
            if actions["start"] or actions["fire"]:
                self.reset_session()
            elif actions["quit"]:
                return False

        elif self.state == "PLAYING":
            if actions["pause"]:
                self.state = "PAUSED"
                return True
            if actions["quit"]:
                self.state = "TITLE"
                return True

            self._update_playing(dt, actions)

        elif self.state == "PAUSED":
            if actions["pause"] or actions["fire"] or actions["start"]:
                self.state = "PLAYING"
            elif actions["quit"]:
                self.state = "TITLE"

        elif self.state == "PLAYER_HIT":
            self._update_particles(dt)
            self.state_timer -= dt
            if self.state_timer <= 0:
                if self.lives <= 0:
                    self.state = "GAME_OVER"
                else:
                    self.player_x = (self.CANVAS_WIDTH - 5) // 2
                    self.player_invuln_timer = 2.0
                    self.state = "PLAYING"

        elif self.state == "WAVE_CLEAR":
            self._update_particles(dt)
            self._update_floating_texts(dt)
            self.state_timer -= dt
            if self.state_timer <= 0:
                self.init_wave(self.wave + 1)
                self.state = "PLAYING"

        elif self.state == "GAME_OVER":
            self._update_particles(dt)
            if actions["restart"] or actions["start"] or actions["fire"]:
                self.reset_session()
            elif actions["quit"]:
                self.state = "TITLE"

        return True

    def _update_playing(self, dt, actions):
        # Update cooldowns
        if self.player_invuln_timer > 0:
            self.player_invuln_timer -= dt
        if self.player_shoot_cooldown > 0:
            self.player_shoot_cooldown -= dt

        # Player Movement
        if actions["left"]:
            self.player_x = max(1, self.player_x - 1)
        if actions["right"]:
            self.player_x = min(self.CANVAS_WIDTH - 6, self.player_x + 1)

        # Player Shooting (Max 2 lasers on screen simultaneously)
        if actions["fire"] and self.player_shoot_cooldown <= 0:
            if len(self.lasers) < 2:
                # Spawn laser from tip of turret
                lx = self.player_x + 2
                ly = self.player_y_turret - 1
                self.lasers.append(Laser(lx, ly))
                self.sound_mgr.shoot()
                self.player_shoot_cooldown = 0.22

        # Resolve each cell crossed, including cells skipped during a slow frame.
        for laser in self.lasers[:]:
            for _ in range(projectile_steps(laser, dt, 25)):
                if self._advance_laser(laser):
                    return
                if laser not in self.lasers:
                    break

        # Update UFO
        if not self.ufo.active:
            self.ufo_spawn_timer -= dt
            if self.ufo_spawn_timer <= 0:
                self.ufo.spawn()
                self.ufo_spawn_timer = random.uniform(22.0, 35.0)
        else:
            self.ufo.update(dt, self.sound_mgr)

        # Update Alien Fleet March
        alive_aliens = [a for a in self.aliens if a.alive]
        alive_count = len(alive_aliens)
        if alive_count > 0:
            # Acceleration curve: speed increases as aliens die
            ratio = alive_count / self.total_wave_aliens
            step_interval = 0.05 + 0.45 * (ratio ** 1.3)

            self.fleet_move_timer += dt
            if self.fleet_move_timer >= step_interval:
                self.fleet_move_timer = 0.0
                self.fleet_frame = 1 - self.fleet_frame
                self.march_sound_idx += 1
                self.sound_mgr.march_step(self.march_sound_idx)

                # Check edge bounds
                min_col = min(a.col for a in alive_aliens)
                max_col = max(a.col for a in alive_aliens)
                left_edge = self.fleet_x + min_col * 6
                right_edge = self.fleet_x + max_col * 6 + 4

                if self.fleet_dx > 0 and right_edge >= self.CANVAS_WIDTH - 1:
                    self.fleet_dx = -1
                    self.fleet_y += 1
                elif self.fleet_dx < 0 and left_edge <= 1:
                    self.fleet_dx = 1
                    self.fleet_y += 1
                else:
                    self.fleet_x += self.fleet_dx

                self._update_alien_positions()

                # Check if invaders hit bunkers (crush bunker blocks)
                for a in alive_aliens:
                    for bunker in self.bunkers:
                        if bunker.y <= a.y < bunker.y + bunker.h:
                            for bx in range(a.x, a.x + 4):
                                lx_b = bx - bunker.x
                                ly_b = a.y - bunker.y
                                if 0 <= lx_b < bunker.w and 0 <= ly_b < bunker.h:
                                    bunker.grid[ly_b][lx_b] = 0

                # Check if invaders reached player line
                max_alien_y = max(a.y for a in alive_aliens)
                if max_alien_y >= self.player_y_turret:
                    # Invasion succeeded!
                    self._player_killed(instant_over=True)
                    return

        # Alien Bombs Drop Logic
        self.bomb_timer += dt
        max_bombs = min(3 + self.wave, 6)
        if self.bomb_timer >= self.bomb_interval and len(self.bombs) < max_bombs:
            self.bomb_timer = 0.0
            # Find bottom-most alien in active columns
            col_bottom_aliens = {}
            for a in alive_aliens:
                if a.col not in col_bottom_aliens or a.row > col_bottom_aliens[a.col].row:
                    col_bottom_aliens[a.col] = a

            if col_bottom_aliens:
                shooter = random.choice(list(col_bottom_aliens.values()))
                btype = random.choice([0, 1, 2])
                self.bombs.append(Bomb(shooter.x + 2, shooter.y + 1, btype))

        # Update Alien Bombs
        for bomb in self.bombs[:]:
            bomb.frame += 1
            speed = 13 if bomb.type == 0 else 9
            for _ in range(projectile_steps(bomb, dt, speed)):
                if self._advance_bomb(bomb):
                    return
                if bomb not in self.bombs:
                    break

        # Update particles & floating text
        self._update_particles(dt)
        self._update_floating_texts(dt)

    def _advance_laser(self, laser):
        """Move one cell upward; return True when the last alien is destroyed."""
        laser.y -= 1
        if laser.y < 0:
            self.lasers.remove(laser)
            return False

        for bunker in self.bunkers:
            if bunker.y <= laser.y < bunker.y + bunker.h and bunker.x <= laser.x < bunker.x + bunker.w:
                if bunker.hit(laser.x - bunker.x, laser.y - bunker.y):
                    self._spawn_debris(laser.x, laser.y, C_GREEN)
                    self.lasers.remove(laser)
                    return False

        for alien in self.aliens:
            if alien.alive and alien.y == laser.y and alien.x <= laser.x < alien.x + 4:
                alien.alive = False
                self.lasers.remove(laser)
                self._add_score(alien.points)
                self.sound_mgr.invader_hit()
                self._spawn_explosion(alien.x + 1, alien.y, alien.color)
                self.floating_texts.append(
                    FloatingText(alien.x, alien.y, f"+{alien.points}", C_YELLOW)
                )
                if not any(a.alive for a in self.aliens):
                    self._add_score(1000 * self.wave)
                    self.sound_mgr.wave_clear()
                    self.state = "WAVE_CLEAR"
                    self.state_timer = 2.0
                    return True
                return False

        if self.ufo.active and laser.y == self.ufo.y and self.ufo.x <= laser.x < self.ufo.x + 7:
            ufo_pts = random.choice([50, 100, 150, 200, 300])
            self._add_score(ufo_pts)
            self.ufo.active = False
            self.lasers.remove(laser)
            self.sound_mgr.invader_hit()
            self._spawn_explosion(self.ufo.x + 3, self.ufo.y, C_RED, count=10)
            self.floating_texts.append(
                FloatingText(self.ufo.x, self.ufo.y, f"+{ufo_pts}!", C_YELLOW, life=20)
            )
        return False

    def _advance_bomb(self, bomb):
        """Move one cell downward; return True when the player is hit."""
        bomb.y += 1
        if bomb.y >= self.CANVAS_HEIGHT:
            self.bombs.remove(bomb)
            return False

        for bunker in self.bunkers:
            if bunker.y <= bomb.y < bunker.y + bunker.h and bunker.x <= bomb.x < bunker.x + bunker.w:
                if bunker.hit(bomb.x - bunker.x, bomb.y - bunker.y):
                    self._spawn_debris(bomb.x, bomb.y, C_RED)
                    self.bombs.remove(bomb)
                    return False

        if self.player_invuln_timer <= 0 and bomb.y in (self.player_y_turret, self.player_y_base):
            if self.player_x <= bomb.x < self.player_x + 5:
                self.bombs.remove(bomb)
                self._player_killed(instant_over=False)
                return True
        return False

    def _player_killed(self, instant_over=False):
        self.sound_mgr.player_hit()
        self._spawn_explosion(self.player_x + 2, self.player_y_base, C_YELLOW, count=16)
        self._spawn_explosion(self.player_x + 2, self.player_y_turret, C_RED, count=12)
        self.lasers.clear()
        self.bombs.clear()
        if instant_over:
            self.lives = 0
        else:
            self.lives -= 1
        self.state = "PLAYER_HIT"
        self.state_timer = 1.3

    def _spawn_explosion(self, x, y, color, count=6):
        chars = ["*", "+", "×", "#", "·"]
        for _ in range(count):
            c = random.choice(chars)
            life = random.randint(5, 11)
            dx = random.choice([-1.2, -0.6, 0.0, 0.6, 1.2])
            dy = random.choice([-0.8, -0.4, 0.0, 0.4, 0.8])
            self.particles.append(Particle(x, y, c, color, life, dx, dy))

    def _spawn_debris(self, x, y, color):
        for _ in range(3):
            c = random.choice([".", "·", "°"])
            life = random.randint(4, 7)
            dx = random.choice([-0.5, 0.0, 0.5])
            dy = random.choice([-0.5, 0.5])
            self.particles.append(Particle(x, y, c, color, life, dx, dy))

    def _update_particles(self, dt):
        for p in self.particles[:]:
            p.x += p.dx
            p.y += p.dy
            p.life -= 1
            if p.life <= 0 or not (0 <= p.x < self.CANVAS_WIDTH and 0 <= p.y < self.CANVAS_HEIGHT):
                self.particles.remove(p)

    def _update_floating_texts(self, dt):
        for ft in self.floating_texts[:]:
            ft.life -= 1
            if ft.life <= 0:
                self.floating_texts.remove(ft)

    # -----------------------------------------------------------------------
    # Flicker-free Double-buffered Frame Rendering
    # -----------------------------------------------------------------------

    def render(self):
        # Buffer Dimensions: Width 72, Height 28
        total_w = self.CANVAS_WIDTH + 2
        total_h = self.CANVAS_HEIGHT + 4

        # Query Terminal Size for Centering
        term_cols, term_rows = 80, 28
        try:
            sz = os.get_terminal_size()
            term_cols, term_rows = sz.columns, sz.lines
        except Exception:
            pass

        pad_x = max(0, (term_cols - total_w) // 2)
        pad_y = max(0, (term_rows - total_h) // 2)
        left_pad = " " * pad_x

        # Create screen character & color matrix
        chars = [[" " for _ in range(total_w)] for _ in range(total_h)]
        colors = [["" for _ in range(total_w)] for _ in range(total_h)]

        # 1. Top HUD (Row 0)
        score_str = f"SCORE: {self.score:05d}"
        high_str = f"HIGH: {self.high_score:05d}"
        wave_str = f"WAVE: {self.wave}"
        sound_str = f"SOUND: {'ON' if self.sound_mgr.enabled else 'OFF'}"
        lives_icons = "▲ " * max(0, self.lives)
        lives_str = f"LIVES: {lives_icons.strip()}"

        hud_items = [
            (score_str, BOLD + C_YELLOW),
            (high_str, BOLD + (C_GREEN if self.new_high_score else C_WHITE)),
            (wave_str, BOLD + C_CYAN),
            (lives_str, BOLD + C_GREEN),
            (sound_str, DIM + C_WHITE),
        ]
        cursor_x = 2
        for text, col in hud_items:
            for ch in text:
                if cursor_x < total_w - 1:
                    chars[0][cursor_x] = ch
                    colors[0][cursor_x] = col
                    cursor_x += 1
            cursor_x += 3

        # 2. Outer Border (Rows 1 to 25)
        # Top border (Row 1)
        chars[1][0] = "╔"
        colors[1][0] = BOLD + C_BLUE
        for x in range(1, total_w - 1):
            chars[1][x] = "═"
            colors[1][x] = BOLD + C_BLUE
        chars[1][total_w - 1] = "╗"
        colors[1][total_w - 1] = BOLD + C_BLUE

        # Side borders (Rows 2 to 25)
        for y in range(2, total_h - 2):
            chars[y][0] = "║"
            colors[y][0] = BOLD + C_BLUE
            chars[y][total_w - 1] = "║"
            colors[y][total_w - 1] = BOLD + C_BLUE

        # Bottom border (Row 26)
        b_row = total_h - 2
        chars[b_row][0] = "╚"
        colors[b_row][0] = BOLD + C_BLUE
        for x in range(1, total_w - 1):
            chars[b_row][x] = "═"
            colors[b_row][x] = BOLD + C_BLUE
        chars[b_row][total_w - 1] = "╝"
        colors[b_row][total_w - 1] = BOLD + C_BLUE

        # Bottom Controls HUD (Row 27)
        ctrl_text = " [←/A] Left  [→/D] Right  [SPACE/W] Fire  [P] Pause  [M] Sound  [Q] Quit"
        for col_idx, ch in enumerate(ctrl_text[:total_w]):
            chars[total_h - 1][col_idx] = ch
            colors[total_h - 1][col_idx] = C_GRAY

        # 3. Canvas Content (Inside borders, offset: x + 1, y + 2)
        # Background Stars
        for sx, sy, sch in self.stars:
            if 0 <= sx < self.CANVAS_WIDTH and 0 <= sy < self.CANVAS_HEIGHT:
                chars[sy + 2][sx + 1] = sch
                colors[sy + 2][sx + 1] = C_GRAY

        # Defense Floor Line (Row 23)
        floor_y = 23 + 2
        for x in range(1, total_w - 1):
            chars[floor_y][x] = "╌"
            colors[floor_y][x] = C_GREEN

        # Mystery UFO (Row 0)
        if self.ufo.active:
            uy = self.ufo.y + 2
            for i, ch in enumerate(SPRITE_UFO):
                px = self.ufo.x + i + 1
                if 1 <= px < total_w - 1:
                    chars[uy][px] = ch
                    colors[uy][px] = BOLD + (C_RED if self.ufo.sound_step % 2 == 0 else C_YELLOW)

        # Alien Invaders
        for a in self.aliens:
            if a.alive:
                sprite = (
                    SPRITE_SQUID[self.fleet_frame] if a.kind == 0
                    else (SPRITE_CRAB[self.fleet_frame] if a.kind == 1 else SPRITE_OCTO[self.fleet_frame])
                )
                ay = a.y + 2
                if 2 <= ay < total_h - 2:
                    for i, ch in enumerate(sprite):
                        px = a.x + i + 1
                        if 1 <= px < total_w - 1:
                            chars[ay][px] = ch
                            colors[ay][px] = BOLD + a.color

        # Destructible Bunkers
        for bunker in self.bunkers:
            for r in range(bunker.h):
                by = bunker.y + r + 2
                if 2 <= by < total_h - 2:
                    for c in range(bunker.w):
                        hp = bunker.grid[r][c]
                        if hp > 0:
                            px = bunker.x + c + 1
                            if 1 <= px < total_w - 1:
                                chars[by][px] = "█" if hp == 2 else "▒"
                                colors[by][px] = BOLD + (C_GREEN if hp == 2 else C_YELLOW)

        # Player Cannon
        if self.state in ("PLAYING", "PLAYER_HIT", "WAVE_CLEAR"):
            # If invulnerable, flicker ship every 4 frames
            draw_player = True
            if self.player_invuln_timer > 0 and int(self.player_invuln_timer * 12) % 2 == 0:
                draw_player = False

            if draw_player and self.lives > 0:
                # Turret
                ty = self.player_y_turret + 2
                for i, ch in enumerate(CANNON_TURRET):
                    if ch != " ":
                        px = self.player_x + i + 1
                        if 1 <= px < total_w - 1:
                            chars[ty][px] = ch
                            colors[ty][px] = BOLD + C_YELLOW
                # Base
                by = self.player_y_base + 2
                for i, ch in enumerate(CANNON_BASE):
                    px = self.player_x + i + 1
                    if 1 <= px < total_w - 1:
                        chars[by][px] = ch
                        colors[by][px] = BOLD + C_CYAN

        # Player Lasers
        for laser in self.lasers:
            ly = laser.y + 2
            lx = laser.x + 1
            if 2 <= ly < total_h - 2 and 1 <= lx < total_w - 1:
                chars[ly][lx] = "║"
                colors[ly][lx] = BOLD + C_WHITE

        # Alien Bombs
        for bomb in self.bombs:
            by = bomb.y + 2
            bx = bomb.x + 1
            if 2 <= by < total_h - 2 and 1 <= bx < total_w - 1:
                if bomb.type == 0:
                    chars[by][bx] = "│"
                    colors[by][bx] = BOLD + C_MAGENTA
                elif bomb.type == 1:
                    chars[by][bx] = "v"
                    colors[by][bx] = BOLD + C_RED
                else:
                    chars[by][bx] = "§" if bomb.frame % 4 < 2 else "~"
                    colors[by][bx] = BOLD + C_YELLOW

        # Explosions & Particles
        for p in self.particles:
            py = int(p.y) + 2
            px = int(p.x) + 1
            if 2 <= py < total_h - 2 and 1 <= px < total_w - 1:
                chars[py][px] = p.char
                colors[py][px] = BOLD + p.color

        # Floating Score Text Popups
        for ft in self.floating_texts:
            fy = ft.y + 2
            if 2 <= fy < total_h - 2:
                for i, ch in enumerate(ft.text):
                    px = ft.x + i + 1
                    if 1 <= px < total_w - 1:
                        chars[fy][px] = ch
                        colors[fy][px] = BOLD + ft.color

        # 4. State Overlays (Title, Paused, Wave Clear, Game Over)
        if self.state == "TITLE":
            self._render_title_overlay(chars, colors, total_w, total_h)
        elif self.state == "PAUSED":
            self._render_box_overlay(
                chars, colors, total_w, total_h,
                title="[ GAME PAUSED ]",
                lines=[
                    "Press [P] or [SPACE] to Resume",
                    "Press [M] to Toggle Sound",
                    "Press [Q] to Return to Title",
                ],
                border_color=BOLD + C_CYAN
            )
        elif self.state == "WAVE_CLEAR":
            self._render_box_overlay(
                chars, colors, total_w, total_h,
                title=f"[ WAVE {self.wave} COMPLETED! ]",
                lines=[
                    f"Wave Bonus: +{1000 * self.wave} PTS",
                    "Preparing Next Alien Assault...",
                ],
                border_color=BOLD + C_GREEN
            )
        elif self.state == "GAME_OVER":
            high_msg = "★ NEW HIGH SCORE! ★" if self.new_high_score else f"High Score: {self.high_score:05d}"
            self._render_box_overlay(
                chars, colors, total_w, total_h,
                title="[ GAME OVER ]",
                lines=[
                    f"Final Score: {self.score:05d}",
                    high_msg,
                    "",
                    "Press [R] or [SPACE] to Play Again",
                    "Press [Q] to Return to Title",
                ],
                border_color=BOLD + C_RED
            )

        # 5. Flush Screen String to STDOUT
        out_lines = []
        if pad_y > 0:
            out_lines.append("\n" * pad_y)

        for y in range(total_h):
            line_parts = [left_pad]
            curr_color = ""
            for x in range(total_w):
                ch = chars[y][x]
                col = colors[y][x]
                if col != curr_color:
                    line_parts.append(col if col else RESET)
                    curr_color = col
                line_parts.append(ch)
            if curr_color:
                line_parts.append(RESET)
            out_lines.append("".join(line_parts))

        frame_data = CURSOR_HOME + "\n".join(out_lines)
        sys.stdout.write(frame_data)
        sys.stdout.flush()

    def _render_box_overlay(self, chars, colors, total_w, total_h, title, lines, border_color):
        box_w = max(len(title) + 4, max(len(l) for l in lines) + 6, 38)
        box_h = len(lines) + 4
        start_x = (total_w - box_w) // 2
        start_y = (total_h - box_h) // 2

        # Clear background inside dialog box
        for y in range(start_y, start_y + box_h):
            for x in range(start_x, start_x + box_w):
                chars[y][x] = " "
                colors[y][x] = RESET

        # Draw box border
        chars[start_y][start_x] = "┌"
        colors[start_y][start_x] = border_color
        for x in range(start_x + 1, start_x + box_w - 1):
            chars[start_y][x] = "─"
            colors[start_y][x] = border_color
        chars[start_y][start_x + box_w - 1] = "┐"
        colors[start_y][start_x + box_w - 1] = border_color

        for y in range(start_y + 1, start_y + box_h - 1):
            chars[y][start_x] = "│"
            colors[y][start_x] = border_color
            chars[y][start_x + box_w - 1] = "│"
            colors[y][start_x + box_w - 1] = border_color

        chars[start_y + box_h - 1][start_x] = "└"
        colors[start_y + box_h - 1][start_x] = border_color
        for x in range(start_x + 1, start_x + box_w - 1):
            chars[start_y + box_h - 1][x] = "─"
            colors[start_y + box_h - 1][x] = border_color
        chars[start_y + box_h - 1][start_x + box_w - 1] = "┘"
        colors[start_y + box_h - 1][start_x + box_w - 1] = border_color

        # Title
        t_x = start_x + (box_w - len(title)) // 2
        for i, ch in enumerate(title):
            chars[start_y + 1][t_x + i] = ch
            colors[start_y + 1][t_x + i] = border_color

        # Content Lines
        for idx, line in enumerate(lines):
            l_y = start_y + 2 + idx
            l_x = start_x + (box_w - len(line)) // 2
            for i, ch in enumerate(line):
                chars[l_y][l_x + i] = ch
                colors[l_y][l_x + i] = BOLD + C_WHITE if "★" in line or "Bonus" in line else C_WHITE

    def _render_title_overlay(self, chars, colors, total_w, total_h):
        # Clear play area for Title Screen
        for y in range(2, total_h - 2):
            for x in range(1, total_w - 1):
                chars[y][x] = " "
                colors[y][x] = RESET

        # Space Invaders Retro Logo (66 chars wide, fits inside total_w = 72)
        logo = [
            r"                        _               _             ",
            r" ___ ___ ___ ___ ___   |_|___ _ _ ___ _| |___ ___ ___ ",
            r"|_ -| . | .'|  _| -_|  | |   | | | .'| . | -_|  _|_ -|",
            r"|___|  _|__,|___|___|  |_|_|_|\_/|__,|___|___|_| |___|",
            r"     |_|                                               ",
            r" ",
        ]

        logo_start_y = 3
        for r_idx, line in enumerate(logo):
            start_x = max(1, (total_w - len(line)) // 2)
            for c_idx, ch in enumerate(line):
                pos_x = start_x + c_idx
                if 1 <= pos_x < total_w - 1 and ch != " ":
                    chars[logo_start_y + r_idx][pos_x] = ch
                    colors[logo_start_y + r_idx][pos_x] = BOLD + (C_CYAN if r_idx < 2 else C_MAGENTA)

        # Score Advance Table
        table_y = 8
        table_lines = [
            ("= * SCORE ADVANCE TABLE * =", BOLD + C_YELLOW),
            (" <(o-o)>  =  ?  MYSTERY UFO", BOLD + C_RED),
            ('/""\\    =  30 POINTS    ', BOLD + C_MAGENTA),
            (" {oo}    =  20 POINTS    ", BOLD + C_CYAN),
            (" [▼▼]    =  10 POINTS    ", BOLD + C_GREEN),
        ]

        for idx, (txt, col) in enumerate(table_lines):
            tx = max(1, (total_w - len(txt)) // 2)
            for c_idx, ch in enumerate(txt):
                pos_x = tx + c_idx
                if 1 <= pos_x < total_w - 1:
                    chars[table_y + idx][pos_x] = ch
                    colors[table_y + idx][pos_x] = col

        # Controls & High Score
        info_y = 14
        high_text = f"ALL-TIME HIGH SCORE: {self.high_score:05d}"
        hx = max(1, (total_w - len(high_text)) // 2)
        for c_idx, ch in enumerate(high_text):
            pos_x = hx + c_idx
            if 1 <= pos_x < total_w - 1:
                chars[info_y][pos_x] = ch
                colors[info_y][pos_x] = BOLD + C_YELLOW

        ctrl_info = [
            "Controls: [A / ←] Left   [D / →] Right   [SPACE / W] Fire",
            "          [P] Pause      [M] Sound       [Q] Quit Game",
        ]
        for idx, line in enumerate(ctrl_info):
            cx = max(1, (total_w - len(line)) // 2)
            for c_idx, ch in enumerate(line):
                pos_x = cx + c_idx
                if 1 <= pos_x < total_w - 1:
                    chars[info_y + 2 + idx][pos_x] = ch
                    colors[info_y + 2 + idx][pos_x] = C_GRAY

        # Pulsing Press Space To Start
        blink = int(self.title_pulse * 3) % 2 == 0
        prompt = ">> PRESS SPACE OR ENTER TO START <<" if blink else " " * 36
        px = max(1, (total_w - len(prompt)) // 2)
        for c_idx, ch in enumerate(prompt):
            pos_x = px + c_idx
            if 1 <= pos_x < total_w - 1:
                chars[19][pos_x] = ch
                colors[19][pos_x] = BOLD + C_GREEN


# ---------------------------------------------------------------------------
# Main Execution Entry Point
# ---------------------------------------------------------------------------

def main():
    game = SpaceInvaders()
    sys.stdout.write(CURSOR_HIDE + CLEAR_SCREEN)
    sys.stdout.flush()

    target_fps = 35.0
    frame_duration = 1.0 / target_fps
    last_time = time.perf_counter()

    try:
        while True:
            current_time = time.perf_counter()
            dt = current_time - last_time
            last_time = current_time

            # Cap dt to avoid large delta jumps if paused in debugger
            if dt > 0.1:
                dt = 0.1

            # Poll inputs
            actions = game.input_handler.poll_keys()

            # Update game logic
            running = game.update(dt, actions)
            if not running:
                break

            # Render frame
            game.render()

            # Precise frame rate sleep
            elapsed = time.perf_counter() - current_time
            sleep_time = frame_duration - elapsed
            if sleep_time > 0:
                time.sleep(sleep_time)

    except KeyboardInterrupt:
        pass
    finally:
        # Graceful cleanup
        game.input_handler.cleanup()
        game.sound_mgr.stop()
        sys.stdout.write(CURSOR_SHOW + RESET + "\033[H\033[2J")
        sys.stdout.write("Thanks for playing SPACE INVADERS!\n\n")
        sys.stdout.flush()


if __name__ == "__main__":
    main()
