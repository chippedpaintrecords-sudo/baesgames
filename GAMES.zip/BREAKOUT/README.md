# 🕹️ BREAKOUT - Classic Arcade Terminal Clone

A feature-packed, retro-authentic **Breakout / Arkanoid** arcade game designed specifically to play directly in your terminal.

```text
   ____  ____  _____    _    _  ______  _   _ _____ 
  | __ )|  _ \| ____|  / \  | |/ / __ \| | | |_   _|
  |  _ \| |_) |  _|   / _ \ | ' / |  | | | | | | |  
  | |_) |  _ <| |___ / ___ \| . \ |__| | |_| | | |  
  |____/|_| \_\_____/_/   \_\_|\_\______\___/  |_|  
```

---

## ✨ Features

- **Responsive Terminal Rendering**: Runs at 60 FPS and writes only changed rows, reducing terminal output and input delay.
- **Held-Key Paddle Control**: On Windows, A/D and arrow keys use physical key state for immediate, continuous movement.
- **Sub-Pixel Ball Physics & Continuous Collision**: Anti-tunneling physics with realistic paddle angle deflection, ball spin, and speed scaling.
- **9 Unique Power-Ups**: Classic Arkanoid-style falling capsules that upgrade your paddle and ball in real-time.
- **6 Diverse Brick Varieties**: From simple rainbow bricks to reinforced multi-hit stone, explosive chain reactions, and silver obstacles.
- **5 Handcrafted Campaign Levels + Endless Hyper Mode**: Custom challenges ranging from the Rainbow Wall to the Alien Crab tribute and Cyber Matrix.
- **Dynamic Combo Multiplier**: Rack up consecutive brick hits without paddle contact to earn up to 4x score multipliers.
- **Chiptune Audio Synthesizer**: Multi-threaded sound effects via Windows sound synthesis (mute anytime with `M`).
- **Persistent High-Score Tracking**: Automatically records your best score to `highscore.json`.
- **Cross-Platform**: Native support on Windows (`msvcrt`, Virtual Terminal) and Unix/Linux/macOS (`termios`/`select`).

---

## 🚀 Quick Start

Run the game directly with Python 3:

```bash
# Launch directly
python breakout.py

# Or via the launcher
python main.py
```

### Run Automated Unit Tests

```bash
python -m unittest test_breakout.py
```

---

## 🎮 Controls

| Action | Primary Key | Alternate Key |
| :--- | :--- | :--- |
| **Move Left** | `A` | `◄` (Left Arrow) |
| **Move Right** | `D` | `►` (Right Arrow) |
| **Launch Ball / Fire Lasers** | `SPACE` | `W` or `▲` (Up Arrow) |
| **Pause / Resume Game** | `P` | `SPACE` (on pause screen) |
| **Toggle Sound (Mute/Unmute)** | `M` | - |
| **Restart (Game Over / Victory)** | `R` | `SPACE` |
| **Quit to Title / Exit** | `Q` | `ESC` |

---

## ⚡ Power-Up Capsules

When bricks shatter, power-up capsules drift down toward your paddle:

| Capsule | Name | Duration | Description |
| :---: | :--- | :---: | :--- |
| `[E]` | **Wide Paddle** | 15s | Expands your paddle width to 12 characters for easier catches. |
| `[M]` | **Multi-Ball** | Instant | Multiplies active balls into a 3-ball barrage! |
| `[F]` | **Fireball** | 12s | Ignites the ball, smashing through all destructible bricks without bouncing! |
| `[L]` | **Twin Lasers** | 12s | Mounts laser blasters on paddle tips; press `SPACE` to blast bricks directly! |
| `[S]` | **Slow Motion** | 12s | Reduces ball velocity by ~30% for high-precision ball control. |
| `[C]` | **Sticky Catch** | 15s | Ball sticks to paddle on impact; reposition and press `SPACE` to aim and launch. |
| `[+]` | **Extra Life** | Instant | Awards +1 extra life (up to maximum 5). |
| `[B]` | **Mega Bomb** | Instant | Launches an explosive missile straight up, obliterating a 3x3 brick cluster! |
| `[X]` | **Energy Shield** | Single Hit | Deploys an emergency forcefield across the bottom floor to bounce falling balls! |

---

## 🧱 Brick Varieties

- **Normal Brick** (`[████]`): 1-hit standard colorful brick (20 to 120 points).
- **Multi-Hit Brick** (`[████]` ➔ `[▒▒▒▒]`): 2-hit reinforced brick (150 points).
- **Hard Armor Brick** (`[████]` ➔ `[▓▓▓▓]` ➔ `[░░░░]`): 3-hit heavy titanium brick (180 points).
- **Explosive Brick** (`[💥💥]`): Detonates on impact, clearing adjacent bricks in a fiery chain reaction (250 points).
- **Mystery Brick** (`[?★ ?]`): Guarantees a high-tier power-up drop when destroyed (200-500 points).
- **Silver Indestructible** (`▓████▓`): Impassable obstacle that deflects all regular and fireball shots.

---

## 🗺️ Campaign Levels

1. **Level 1: "Rainbow Gateway"** — Classic 6-tier retro wall introducing core mechanics and power-ups.
2. **Level 2: "Pyramid Fortress"** — Stepped layered fortress with multi-hit stone armor and explosive cores.
3. **Level 3: "Space Invader Tribute"** — Giant pixel-art alien invader built from bricks with glowing power-up eyes.
4. **Level 4: "Diamond Vault"** — Indestructible silver pillars guarding inner explosive treasury vaults.
5. **Level 5: "Cyber Matrix"** — Dense boss grid of titanium armor, chain bombs, and mystery capsules.
- **Victory & Loop Mode**: Defeating Level 5 unlocks the **Grand Champion** victory screen, followed by high-speed endless looping with escalating score bonuses!

---

## 📐 Terminal Recommendations

- **Minimum Size**: 80 columns x 28 rows.
- **Recommended**: Windows Terminal, PowerShell 7, VS Code integrated terminal, or any ANSI-compatible terminal.
- **Color Support**: UTF-8 and 256-color ANSI output enabled automatically.
