#!/usr/bin/env python3
"""
Unit and Integration Test Suite for BREAKOUT Terminal Game
==========================================================
Tests physics, brick collisions, power-ups, levels, paddle mechanics,
score calculations, and headless frame rendering.
"""

import unittest
import os
import tempfile
import json
import math
from unittest.mock import MagicMock, patch

import breakout

# Redirect SCORE_FILE to a temporary location for test runs
_TMP_SCORE_DIR = tempfile.mkdtemp()
breakout.SCORE_FILE = os.path.join(_TMP_SCORE_DIR, "test_highscore.json")

from breakout import (
    BreakoutGame,
    Ball,
    Paddle,
    Brick,
    BrickType,
    PowerUpItem,
    Laser,
    MissileBomb,
    LevelManager,
    SoundManager,
    InputHandler,
    load_high_score,
    save_high_score,
    BRICK_WIDTH,
)

class TestBreakoutPhysics(unittest.TestCase):
    def setUp(self):
        self.game = BreakoutGame()
        self.game.sound_mgr.enabled = False  # Keep headless tests silent

    def test_ball_wall_bounces(self):
        # Left wall
        ball = Ball(x=0.0, y=10.0, vx=-10.0, vy=-10.0)
        self.game._ball_sub_step(ball, 0.05)
        self.assertGreater(ball.vx, 0)
        self.assertEqual(ball.x, 0)

        # Right wall
        ball = Ball(x=self.game.FIELD_WIDTH - 1, y=10.0, vx=10.0, vy=-10.0)
        self.game._ball_sub_step(ball, 0.05)
        self.assertLess(ball.vx, 0)
        self.assertEqual(ball.x, self.game.FIELD_WIDTH - 1)

        # Top wall
        ball = Ball(x=20.0, y=0.0, vx=5.0, vy=-10.0)
        self.game._ball_sub_step(ball, 0.05)
        self.assertGreater(ball.vy, 0)
        self.assertEqual(ball.y, 0)

    def test_ball_paddle_deflection(self):
        # Center hit: should bounce straight or near-zero vx
        self.game.paddle.x = 20.0
        self.game.paddle.width = 8.0
        self.game.paddle.dir = 0
        ball = Ball(x=24.0, y=self.game.PADDLE_Y, vx=0.0, vy=12.0)
        self.game._ball_sub_step(ball, 0.05)
        self.assertLess(ball.vy, 0, "Ball must bounce upward from paddle")

        # Right hit: should bounce strongly to the right
        ball = Ball(x=27.5, y=self.game.PADDLE_Y, vx=-2.0, vy=12.0)
        self.game._ball_sub_step(ball, 0.05)
        self.assertGreater(ball.vx, 0, "Right paddle hit must deflect rightward")
        self.assertLess(ball.vy, 0, "Ball must bounce upward")

        # Left hit: should bounce strongly to the left
        ball = Ball(x=20.5, y=self.game.PADDLE_Y, vx=2.0, vy=12.0)
        self.game._ball_sub_step(ball, 0.05)
        self.assertLess(ball.vx, 0, "Left paddle hit must deflect leftward")
        self.assertLess(ball.vy, 0, "Ball must bounce upward")

    def test_sticky_paddle_catches_ball(self):
        self.game.catch_timer = 10.0
        self.game.paddle.x = 20.0
        self.game.paddle.width = 8.0
        ball = Ball(x=24.0, y=self.game.PADDLE_Y, vx=0.0, vy=12.0)
        self.game._ball_sub_step(ball, 0.05)
        self.assertTrue(ball.attached, "Ball should attach to paddle when sticky catch is active")
        self.assertAlmostEqual(ball.offset_x, 4.0, places=1)

    def test_sticky_catch_can_be_relaunched_while_playing(self):
        self.game.load_level(1)
        self.game.state = "PLAYING"
        self.game.catch_timer = 10.0
        ball = self.game.balls[0]
        ball.attached = False
        ball.x = self.game.paddle.x + self.game.paddle.width / 2
        ball.y = self.game.PADDLE_Y - 0.3
        ball.vx = 0.0
        ball.vy = 12.0
        actions = {key: False for key in ("left", "right", "fire", "pause", "mute", "quit", "restart", "start")}

        self.game.update(0.05, actions)
        self.assertEqual(self.game.state, "PLAYING")
        self.assertTrue(ball.attached)
        self.assertEqual(ball.y, self.game.PADDLE_Y - 1)

        actions["right"] = True
        self.game.update(0.05, actions)
        self.assertTrue(ball.attached)
        self.assertAlmostEqual(ball.x, self.game.paddle.x + ball.offset_x)

        self.game.catch_timer = 0.0  # A caught ball remains launchable after the power-up expires.
        actions["right"] = False
        actions["fire"] = True
        self.game.update(0.02, actions)
        self.assertEqual(self.game.state, "PLAYING")
        self.assertFalse(ball.attached)
        self.assertLess(ball.vy, 0)
        self.assertLess(ball.y, self.game.PADDLE_Y - 1)

    def test_shield_barrier_saves_ball(self):
        self.game.shield_active = True
        ball = Ball(x=30.0, y=self.game.FLOOR_Y, vx=0.0, vy=15.0)
        self.game._ball_sub_step(ball, 0.05)
        self.assertFalse(self.game.shield_active, "Shield should be consumed after saving ball")
        self.assertLess(ball.vy, 0, "Shield should bounce ball upward")


class TestBrickMechanics(unittest.TestCase):
    def setUp(self):
        self.game = BreakoutGame()
        self.game.sound_mgr.enabled = False

    def test_normal_brick_destruction(self):
        brick = Brick(col=2, row=1, kind=BrickType.NORMAL, points=100, max_hp=1)
        self.game.bricks = [brick]
        init_score = self.game.score

        ball = Ball(x=brick.x + 2, y=brick.y, vx=0, vy=10)
        self.game._handle_brick_hit(brick, ball)

        self.assertFalse(brick.alive)
        self.assertEqual(brick.hp, 0)
        self.assertEqual(self.game.score, init_score + 100)
        self.assertEqual(self.game.combo, 1)

    def test_multi_hit_brick(self):
        brick = Brick(col=3, row=2, kind=BrickType.MULTI, points=150, max_hp=2)
        self.game.bricks = [brick]

        # First hit damages it
        ball = Ball(x=brick.x + 2, y=brick.y, vx=0, vy=10)
        self.game._handle_brick_hit(brick, ball)
        self.assertTrue(brick.alive)
        self.assertEqual(brick.hp, 1)
        self.assertEqual(brick.get_sprite(), "▒▒▒▒▒▒")

        # Second hit shatters it
        self.game._handle_brick_hit(brick, ball)
        self.assertFalse(brick.alive)
        self.assertEqual(brick.hp, 0)

    def test_indestructible_brick(self):
        brick = Brick(col=1, row=1, kind=BrickType.INDESTRUCTIBLE, points=0, max_hp=999)
        self.game.bricks = [brick]

        ball = Ball(x=brick.x + 2, y=brick.y, vx=0, vy=10)
        self.game._handle_brick_hit(brick, ball)
        self.assertTrue(brick.alive)
        self.assertEqual(brick.hp, 999)

    def test_brick_sprites_fill_their_columns(self):
        for kind in (BrickType.NORMAL, BrickType.MULTI, BrickType.HARD,
                     BrickType.EXPLOSIVE, BrickType.POWERUP, BrickType.INDESTRUCTIBLE):
            brick = Brick(col=0, row=0, kind=kind, max_hp=3)
            for hp in (3, 2, 1):
                brick.hp = hp
                sprite = brick.get_sprite()
                self.assertEqual(len(sprite), BRICK_WIDTH)
                self.assertTrue(set(sprite) <= set("█▓▒░"))

    def test_explosive_brick_chain_reaction(self):
        # Create 3 adjacent bricks: center is explosive
        b_left = Brick(col=4, row=2, kind=BrickType.NORMAL, points=50)
        b_center = Brick(col=5, row=2, kind=BrickType.EXPLOSIVE, points=200)
        b_right = Brick(col=6, row=2, kind=BrickType.EXPLOSIVE, points=200)
        b_chain = Brick(col=7, row=2, kind=BrickType.NORMAL, points=50)

        self.game.bricks = [b_left, b_center, b_right, b_chain]
        ball = Ball(x=b_center.x + 2, y=b_center.y, vx=0, vy=10)

        self.game._handle_brick_hit(b_center, ball)

        # Both explosive bricks detonated and cleared neighbors in chain
        self.assertFalse(b_center.alive)
        self.assertFalse(b_left.alive)
        self.assertFalse(b_right.alive)
        self.assertFalse(b_chain.alive)

    def test_fireball_punches_through_bricks(self):
        brick1 = Brick(col=2, row=1, kind=BrickType.HARD, points=100, max_hp=3)
        self.game.bricks = [brick1]

        ball = Ball(x=brick1.x + 2, y=brick1.y, vx=0, vy=-10)
        ball.is_fireball = True

        # Ball hits brick: fireball should not bounce and deals massive damage
        hit_brick = self.game._check_brick_collision(ball, ball.x, ball.y + 1)
        self.assertIsNotNone(hit_brick)
        self.assertEqual(ball.vy, -10, "Fireball should not reverse vy on brick impact")

        self.game._handle_brick_hit(brick1, ball)
        self.assertFalse(brick1.alive, "Fireball should instantly destroy destructible brick")


class TestPowerUpsAndWeapons(unittest.TestCase):
    def setUp(self):
        self.game = BreakoutGame()
        self.game.sound_mgr.enabled = False

    def test_expand_paddle(self):
        self.game._activate_powerup("EXPAND")
        self.assertGreater(self.game.expand_timer, 0)
        self.assertEqual(self.game.paddle.width, 12)

    def test_multiball(self):
        self.assertEqual(len(self.game.balls), 0)
        # Create 1 active ball
        b = Ball(x=30, y=15, vx=10, vy=-10)
        self.game.balls.append(b)
        self.game._activate_powerup("MULTIBALL")
        self.assertGreaterEqual(len(self.game.balls), 3, "Multi-ball should expand to at least 3 balls")

    def test_laser_blasters(self):
        self.game._activate_powerup("LASER")
        self.assertGreater(self.game.laser_timer, 0)

        # Press fire action
        actions = {"fire": True, "left": False, "right": False, "pause": False, "mute": False, "quit": False, "restart": False, "start": False}
        self.game.state = "PLAYING"
        self.game.paddle.laser_cooldown = 0
        self.game.update(0.02, actions)

        self.assertGreaterEqual(len(self.game.lasers), 2, "Laser power-up should fire twin lasers")

    def test_laser_destroys_brick(self):
        brick = Brick(col=4, row=1, kind=BrickType.NORMAL, max_hp=1)
        self.game.bricks = [brick]
        laser = Laser(x=brick.x + 2, y=brick.y + 0.5)
        self.game.lasers = [laser]

        self.game._update_lasers(0.01)
        self.assertFalse(brick.alive, "Laser hit should destroy 1-hit brick")
        self.assertEqual(len(self.game.lasers), 0, "Laser should be consumed on impact")

    def test_mega_bomb_missile(self):
        self.game._activate_powerup("BOMB")
        self.assertEqual(len(self.game.bombs), 1)

        brick = Brick(col=5, row=2, kind=BrickType.NORMAL, max_hp=1)
        self.game.bricks = [brick]
        self.game.bombs[0].x = brick.x + 2
        self.game.bombs[0].y = brick.y + 0.5

        self.game._update_bombs(0.01)
        self.assertFalse(brick.alive, "Mega bomb should detonate and destroy brick")
        self.assertEqual(len(self.game.bombs), 0)

    def test_extra_life(self):
        self.game.lives = 2
        self.game._activate_powerup("LIFE")
        self.assertEqual(self.game.lives, 3)


class TestLevelManagerAndProgression(unittest.TestCase):
    def test_levels_generate_bricks(self):
        for lvl in range(1, 6):
            bricks = LevelManager.get_level(lvl, total_cols=11)
            self.assertGreater(len(bricks), 10, f"Level {lvl} must have bricks")
            destructible = [b for b in bricks if b.kind != BrickType.INDESTRUCTIBLE]
            self.assertGreater(len(destructible), 5, f"Level {lvl} must have destructible bricks")

    def test_load_level(self):
        game = BreakoutGame()
        game.sound_mgr.enabled = False
        game.load_level(1)
        self.assertEqual(game.level, 1)
        self.assertEqual(game.state, "SERVE")
        self.assertEqual(len(game.balls), 1)
        self.assertTrue(game.balls[0].attached)


class TestHighScorePersistence(unittest.TestCase):
    def test_save_and_load(self):
        with tempfile.NamedTemporaryFile(delete=False) as tmp:
            tmp_path = tmp.name
        try:
            with patch("breakout.SCORE_FILE", tmp_path):
                test_val = 98760
                save_high_score(test_val)
                loaded = load_high_score()
                self.assertEqual(loaded, test_val)
        finally:
            if os.path.exists(tmp_path):
                os.remove(tmp_path)


class TestRenderFrameHeadless(unittest.TestCase):
    def test_render_does_not_crash(self):
        game = BreakoutGame()
        game.sound_mgr.enabled = False
        game.start_new_game()

        # Render in various states
        states = ["TITLE", "SERVE", "PLAYING", "PAUSED", "LEVEL_CLEAR", "GAME_OVER", "VICTORY"]
        for st in states:
            game.state = st
            with patch("sys.stdout.write") as mock_write, patch("sys.stdout.flush"):
                game.render()
                self.assertTrue(mock_write.called, f"Render must write output in state {st}")

    def test_unchanged_frame_is_not_written(self):
        game = BreakoutGame()
        game.sound_mgr.enabled = False
        game.start_new_game()
        with patch("sys.stdout.write") as mock_write, patch("sys.stdout.flush"):
            game.render()
            full_frame_size = len(mock_write.call_args.args[0])
            mock_write.reset_mock()
            game.render()
            mock_write.assert_not_called()

            game.paddle.x += 1
            game.render()
            changed_frame = mock_write.call_args.args[0]
            self.assertIn("\033[", changed_frame)
            self.assertLess(len(changed_frame), full_frame_size)


@unittest.skipUnless(breakout.IS_WINDOWS, "Windows held-key polling")
class TestWindowsInput(unittest.TestCase):
    def test_movement_tracks_key_down_and_release_without_repeats(self):
        handler = InputHandler()
        held = {0x41}
        handler._get_async_key_state = lambda key: 0x8000 if key in held else 0
        with patch.object(breakout.msvcrt, "kbhit", return_value=False):
            self.assertTrue(handler.poll_keys()["left"])
            held.clear()
            self.assertFalse(handler.poll_keys()["left"])

    def test_pause_is_one_action_per_press(self):
        handler = InputHandler()
        held = {0x50}
        handler._get_async_key_state = lambda key: 0x8000 if key in held else 0
        with patch.object(breakout.msvcrt, "kbhit", return_value=False):
            self.assertTrue(handler.poll_keys()["pause"])
            self.assertFalse(handler.poll_keys()["pause"])
            held.clear()
            self.assertFalse(handler.poll_keys()["pause"])
            held.add(0x50)
            self.assertTrue(handler.poll_keys()["pause"])


class TestGameFlowAndTransitions(unittest.TestCase):
    def setUp(self):
        self.game = BreakoutGame()
        self.game.sound_mgr.enabled = False

    def test_ball_loss_decrements_life(self):
        self.game.lives = 3
        ball = Ball(x=30, y=self.game.FIELD_HEIGHT + 2, vx=0, vy=10)
        self.game.balls = [ball]
        self.game._update_balls(0.05)
        self.assertEqual(self.game.lives, 2)
        self.assertEqual(self.game.state, "SERVE")
        self.assertEqual(len(self.game.balls), 1)

    def test_ball_loss_causes_game_over_when_zero_lives(self):
        self.game.lives = 1
        ball = Ball(x=30, y=self.game.FIELD_HEIGHT + 2, vx=0, vy=10)
        self.game.balls = [ball]
        self.game._update_balls(0.05)
        self.assertEqual(self.game.lives, 0)
        self.assertEqual(self.game.state, "GAME_OVER")

    def test_powerup_falling_and_paddle_collection(self):
        self.game.paddle.x = 20
        self.game.paddle.width = 8
        item = PowerUpItem(x=22, y=self.game.PADDLE_Y, kind="EXPAND")
        self.game.powerup_items = [item]

        self.game._update_powerup_items(0.01)
        self.assertEqual(len(self.game.powerup_items), 0, "Item should be collected")
        self.assertGreater(self.game.expand_timer, 0)
        self.assertEqual(self.game.paddle.width, 12)

    def test_paddle_clamping(self):
        actions_left = {"left": True, "right": False, "fire": False, "pause": False, "mute": False, "quit": False, "restart": False, "start": False}
        self.game.state = "PLAYING"
        self.game.paddle.x = 2.0
        # Move hard left for several frames
        for _ in range(10):
            self.game.update(0.05, actions_left)
        self.assertGreaterEqual(self.game.paddle.x, 0.0)

        actions_right = {"left": False, "right": True, "fire": False, "pause": False, "mute": False, "quit": False, "restart": False, "start": False}
        for _ in range(50):
            self.game.update(0.05, actions_right)
        max_x = self.game.FIELD_WIDTH - self.game.paddle.width
        self.assertLessEqual(self.game.paddle.x, max_x)

    def test_sound_manager_mute_and_stop(self):
        sm = SoundManager()
        self.assertTrue(sm.enabled)
        toggled = sm.toggle()
        self.assertFalse(toggled)
        sm.paddle_hit()
        sm.stop()
        self.assertFalse(sm.running)


if __name__ == "__main__":
    unittest.main()
