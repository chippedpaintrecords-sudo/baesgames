#!/usr/bin/env python3
"""
BREAKOUT - Classic Arcade Terminal Clone
=========================================
A complete, retro-authentic Breakout / Arkanoid arcade clone for the terminal.
Features:
  - 100% Flicker-free ANSI double-buffered rendering
  - Sub-pixel floating-point ball physics with anti-tunneling continuous collision
  - Interactive paddle angle deflection & spin mechanics
  - 9 Unique Power-Ups: Expand, Multi-Ball, Fireball, Lasers, Slow-Mo, Sticky Catch, Extra Life, Mega Bomb, Energy Shield
  - 6 Brick Varieties: Normal, Multi-Hit, Reinforced Hard, Explosive Chain-Reaction, Mystery Power-Up, Indestructible Silver
  - 5 Handcrafted Level Layouts + Endless Procedural Mode
  - Dynamic Combo Multiplier system with floating score popups
  - Particle explosion physics, sparks, and ball trails
  - Multi-threaded retro chiptune audio synthesizer (mute toggle with 'M')
  - Persistent high-score tracking across sessions
  - Cross-platform support (Windows msvcrt + Unix termios/select fallback)
"""

import sys
import os
import time
import json
import math
import random
import queue
import threading
from collections import deque

# ---------------------------------------------------------------------------
# Platform and Terminal Configuration
# ---------------------------------------------------------------------------

IS_WINDOWS = sys.platform == "win32"

if IS_WINDOWS:
    import msvcrt
    import ctypes
    # Enable Virtual Terminal Processing for ANSI colors & UTF-8 output
    try:
        sys.stdout.reconfigure(encoding="utf-8")
    except Exception:
        pass
    try:
        kernel32 = ctypes.windll.kernel32
        kernel32.SetConsoleOutputCP(65001)
        kernel32.SetConsoleCP(65001)
        h_stdout = kernel32.GetStdHandle(-11)  # STD_OUTPUT_HANDLE
        mode = ctypes.c_ulong()
        if kernel32.GetConsoleMode(h_stdout, ctypes.byref(mode)):
            mode.value |= 0x0004  # ENABLE_VIRTUAL_TERMINAL_PROCESSING
            kernel32.SetConsoleMode(h_stdout, mode)
    except Exception:
        pass
else:
    import select
    import tty
    import termios


# ---------------------------------------------------------------------------
# ANSI Color Codes & Styles
# ---------------------------------------------------------------------------

RESET = "\033[0m"
BOLD = "\033[1m"
DIM = "\033[2m"

# Foreground Colors
C_RED = "\033[91m"
C_GREEN = "\033[92m"
C_YELLOW = "\033[93m"
C_BLUE = "\033[94m"
C_MAGENTA = "\033[95m"
C_CYAN = "\033[96m"
C_WHITE = "\033[97m"
C_GRAY = "\033[90m"
C_ORANGE = "\033[38;5;208m"
C_PURPLE = "\033[38;5;135m"
C_GOLD = "\033[38;5;220m"
C_NEON_PINK = "\033[38;5;201m"

# Cursor Controls
CURSOR_HIDE = "\033[?25l"
CURSOR_SHOW = "\033[?25h"
CURSOR_HOME = "\033[H"
CLEAR_SCREEN = "\033[2J"


# ---------------------------------------------------------------------------
# Non-blocking Keyboard Input Handler
# ---------------------------------------------------------------------------

class InputHandler:
    """Handles cross-platform non-blocking keyboard input."""
    def __init__(self):
        self.old_term_settings = None
        self._movement_until = {"left": 0.0, "right": 0.0}
        self._escape_sequence = ""
        self._escape_time = 0.0
        self._get_async_key_state = None
        self._command_down = {"pause": False, "mute": False, "quit": False}
        self._command_ready_at = {"pause": 0.0, "mute": 0.0, "quit": 0.0}
        if IS_WINDOWS:
            try:
                self._get_async_key_state = ctypes.windll.user32.GetAsyncKeyState
            except (AttributeError, OSError):
                pass
        if not IS_WINDOWS:
            try:
                self.old_term_settings = termios.tcgetattr(sys.stdin)
                tty.setcbreak(sys.stdin.fileno())
            except Exception:
                pass

    def cleanup(self):
        if not IS_WINDOWS and self.old_term_settings:
            try:
                termios.tcsetattr(sys.stdin, termios.TCSADRAIN, self.old_term_settings)
            except Exception:
                pass

    def poll_keys(self):
        """Read queued events and report continuous paddle movement."""
        actions = {
            "left": False,
            "right": False,
            "fire": False,
            "pause": False,
            "mute": False,
            "quit": False,
            "restart": False,
            "start": False,
        }

        movement_events = {"left": False, "right": False}
        if IS_WINDOWS:
            while msvcrt.kbhit():
                try:
                    ch = msvcrt.getch()
                except Exception:
                    break
                if ch in (b"\x00", b"\xe0"):
                    try:
                        ch2 = msvcrt.getch()
                    except Exception:
                        break
                    if ch2 == b"K":  # Left Arrow
                        movement_events["left"] = True
                    elif ch2 == b"M":  # Right Arrow
                        movement_events["right"] = True
                    elif ch2 == b"H":  # Up Arrow
                        actions["fire"] = True
                        actions["start"] = True
                else:
                    c = ch.decode("latin1", errors="ignore").lower()
                    if c in ("a",):
                        movement_events["left"] = True
                    elif c in ("d",):
                        movement_events["right"] = True
                    elif c in (" ", "w"):
                        actions["fire"] = True
                        actions["start"] = True
                    elif c in ("p",):
                        actions["pause"] = True
                    elif c in ("m",):
                        actions["mute"] = True
                    elif c in ("q", "\x1b"):
                        actions["quit"] = True
                    elif c in ("r",):
                        actions["restart"] = True
                    elif c in ("\r", "\n"):
                        actions["start"] = True
                        actions["fire"] = True
        else:
            # Read raw bytes: TextIOWrapper can buffer extra keypresses beyond
            # what select() sees, delaying them until another key arrives.
            while True:
                rlist, _, _ = select.select([sys.stdin.fileno()], [], [], 0)
                if not rlist:
                    break
                try:
                    chunk = os.read(sys.stdin.fileno(), 4096)
                except (OSError, ValueError):
                    break
                if not chunk:
                    break
                for ch in chunk.decode("utf-8", errors="ignore"):
                    if self._escape_sequence:
                        if self._escape_sequence == "\033" and ch == "[":
                            self._escape_sequence = "\033["
                            continue
                        if self._escape_sequence == "\033[":
                            if ch == "D":
                                movement_events["left"] = True
                            elif ch == "C":
                                movement_events["right"] = True
                            elif ch == "A":
                                actions["fire"] = actions["start"] = True
                            self._escape_sequence = ""
                            continue
                        self._escape_sequence = ""
                        actions["quit"] = True
                    if ch == "\033":
                        self._escape_sequence = "\033"
                        self._escape_time = time.perf_counter()
                        continue
                    c = ch.lower()
                    if c in ("a",):
                        movement_events["left"] = True
                    elif c in ("d",):
                        movement_events["right"] = True
                    elif c in (" ", "w"):
                        actions["fire"] = True
                        actions["start"] = True
                    elif c in ("p",):
                        actions["pause"] = True
                    elif c in ("m",):
                        actions["mute"] = True
                    elif c in ("q",):
                        actions["quit"] = True
                    elif c in ("r",):
                        actions["restart"] = True
                    elif c in ("\r", "\n"):
                        actions["start"] = True
                        actions["fire"] = True

            # A standalone Escape must wait briefly for a possible arrow code.
            if self._escape_sequence and time.perf_counter() - self._escape_time > 0.04:
                if self._escape_sequence == "\033":
                    actions["quit"] = True
                self._escape_sequence = ""

        now = time.perf_counter()
        if movement_events["left"] != movement_events["right"]:
            opposite = "right" if movement_events["left"] else "left"
            self._movement_until[opposite] = 0.0
        for direction in ("left", "right"):
            if movement_events[direction]:
                # Terminal key repeat has an initial delay. Bridge that gap on
                # terminals that do not expose key release events.
                self._movement_until[direction] = now + 0.32
            actions[direction] = now < self._movement_until[direction]

        if self._get_async_key_state is not None:
            try:
                actions["left"] = bool(movement_events["left"] or
                                       self._get_async_key_state(0x41) & 0x8000 or
                                       self._get_async_key_state(0x25) & 0x8000)
                actions["right"] = bool(movement_events["right"] or
                                        self._get_async_key_state(0x44) & 0x8000 or
                                        self._get_async_key_state(0x27) & 0x8000)
            except (OSError, ValueError):
                self._get_async_key_state = None

        for command, virtual_keys in (("pause", (0x50,)), ("mute", (0x4D,)),
                                      ("quit", (0x51, 0x1B))):
            event = actions[command]
            if self._get_async_key_state is not None:
                try:
                    down = any(self._get_async_key_state(key) & 0x8000 for key in virtual_keys)
                    actions[command] = bool((down or event) and not self._command_down[command])
                    self._command_down[command] = bool(down)
                    continue
                except (OSError, ValueError):
                    self._get_async_key_state = None
            actions[command] = bool(event and now >= self._command_ready_at[command])
            if actions[command]:
                self._command_ready_at[command] = now + 0.5

        return actions


# ---------------------------------------------------------------------------
# Retro Chiptune Audio Synthesizer (Background Worker)
# ---------------------------------------------------------------------------

class SoundManager:
    """Threaded sound synthesizer producing retro arcade effects via winsound."""
    def __init__(self):
        self.enabled = True
        self.queue = queue.Queue(maxsize=16)
        self.running = True
        self.thread = threading.Thread(target=self._worker, daemon=True)
        self.thread.start()

    def _worker(self):
        while self.running:
            try:
                item = self.queue.get(timeout=0.1)
            except queue.Empty:
                continue
            if item is None:
                break
            freq, dur = item
            if self.enabled and IS_WINDOWS:
                try:
                    import winsound
                    winsound.Beep(freq, dur)
                except Exception:
                    pass
            self.queue.task_done()

    def play(self, freq, dur=30):
        if not self.enabled or not IS_WINDOWS:
            return
        if not self.queue.full():
            try:
                self.queue.put_nowait((freq, dur))
            except queue.Full:
                pass

    def paddle_hit(self):
        self.play(440, 25)

    def wall_bounce(self):
        self.play(310, 20)

    def brick_hit(self):
        self.play(620, 30)

    def brick_shatter(self):
        self.play(840, 35)

    def explosion(self):
        self.play(150, 60)

    def powerup_drop(self):
        self.play(540, 25)

    def powerup_collect(self):
        for f in (587, 740, 880):
            self.play(f, 35)

    def laser_shoot(self):
        self.play(980, 20)

    def ball_lost(self):
        self.play(130, 80)

    def shield_bounce(self):
        self.play(720, 40)

    def level_clear(self):
        for f in (523, 659, 784, 1046):
            self.play(f, 60)

    def game_over(self):
        for f in (392, 330, 262, 196):
            self.play(f, 80)

    def toggle(self):
        self.enabled = not self.enabled
        return self.enabled

    def stop(self):
        self.running = False
        try:
            self.queue.put_nowait(None)
        except Exception:
            pass


# ---------------------------------------------------------------------------
# High Score Manager
# ---------------------------------------------------------------------------

SCORE_FILE = os.path.join(os.path.dirname(os.path.abspath(__file__)), "highscore.json")

def load_high_score():
    try:
        if os.path.exists(SCORE_FILE):
            with open(SCORE_FILE, "r", encoding="utf-8") as f:
                data = json.load(f)
                return int(data.get("high_score", 0))
    except Exception:
        pass
    return 0

def save_high_score(score):
    try:
        data = {"high_score": score}
        with open(SCORE_FILE, "w", encoding="utf-8") as f:
            json.dump(data, f)
    except Exception:
        pass


# ---------------------------------------------------------------------------
# Visual Particles and Popups
# ---------------------------------------------------------------------------

class Particle:
    def __init__(self, x, y, char, color, life, vx, vy, gravity=18.0):
        self.x = float(x)
        self.y = float(y)
        self.char = char
        self.color = color
        self.life = float(life)
        self.max_life = float(life)
        self.vx = float(vx)
        self.vy = float(vy)
        self.gravity = float(gravity)

    def update(self, dt):
        self.x += self.vx * dt
        self.y += self.vy * dt
        self.vy += self.gravity * dt
        self.life -= dt
        return self.life > 0


class FloatingText:
    def __init__(self, x, y, text, color, life=1.0):
        self.x = float(x)
        self.y = float(y)
        self.text = text
        self.color = color
        self.life = float(life)

    def update(self, dt):
        self.y -= 1.8 * dt
        self.life -= dt
        return self.life > 0


# ---------------------------------------------------------------------------
# Power-Up Items & Projectiles
# ---------------------------------------------------------------------------

# Types: EXPAND (E), MULTIBALL (M), FIREBALL (F), LASER (L), SLOW (S), CATCH (C), LIFE (+), BOMB (B), SHIELD (X)
POWERUP_CONFIGS = {
    "EXPAND":    {"code": "E", "name": "WIDE PADDLE",   "color": C_GREEN,     "dur": 15.0},
    "MULTIBALL": {"code": "M", "name": "MULTI-BALL",    "color": C_CYAN,      "dur": 0.0},
    "FIREBALL":  {"code": "F", "name": "FIREBALL",      "color": C_ORANGE,    "dur": 12.0},
    "LASER":     {"code": "L", "name": "LASER ARMED",   "color": C_GOLD,      "dur": 12.0},
    "SLOW":      {"code": "S", "name": "SLOW-MO BALL",  "color": C_BLUE,      "dur": 12.0},
    "CATCH":     {"code": "C", "name": "STICKY CATCH",  "color": C_PURPLE,    "dur": 15.0},
    "LIFE":      {"code": "+", "name": "EXTRA LIFE",    "color": C_NEON_PINK, "dur": 0.0},
    "BOMB":      {"code": "B", "name": "MEGA BOMB",     "color": C_RED,       "dur": 0.0},
    "SHIELD":    {"code": "X", "name": "ENERGY SHIELD", "color": C_WHITE,     "dur": 0.0},
}

class PowerUpItem:
    def __init__(self, x, y, kind):
        self.x = float(x)
        self.y = float(y)
        self.kind = kind
        self.cfg = POWERUP_CONFIGS.get(kind, POWERUP_CONFIGS["EXPAND"])
        self.vy = 8.5  # Fall speed rows/sec
        self.active = True

    def update(self, dt):
        self.y += self.vy * dt


class Laser:
    def __init__(self, x, y):
        self.x = float(x)
        self.y = float(y)
        self.vy = -32.0  # Ascend speed rows/sec
        self.active = True

    def update(self, dt):
        self.y += self.vy * dt


class MissileBomb:
    """Rocket fired from paddle when Mega Bomb is collected or triggered."""
    def __init__(self, x, y):
        self.x = float(x)
        self.y = float(y)
        self.vy = -26.0
        self.active = True

    def update(self, dt):
        self.y += self.vy * dt


# ---------------------------------------------------------------------------
# Bricks
# ---------------------------------------------------------------------------

BRICK_WIDTH = 6

class BrickType:
    NORMAL = 0
    MULTI = 1
    HARD = 2
    EXPLOSIVE = 3
    POWERUP = 4
    INDESTRUCTIBLE = 5

class Brick:
    def __init__(self, col, row, kind=BrickType.NORMAL, color=C_RED, points=100, max_hp=1, powerup_type=None):
        self.col = col
        self.row = row
        self.kind = kind
        self.color = color
        self.points = points
        self.max_hp = max_hp
        self.hp = max_hp
        self.powerup_type = powerup_type
        self.alive = True

    @property
    def x(self):
        return self.col * BRICK_WIDTH

    @property
    def y(self):
        return self.row + 3  # Offset from top wall

    def get_sprite(self):
        """Returns 6-character representation based on state."""
        if self.kind == BrickType.INDESTRUCTIBLE:
            return "▓████▓"
        elif self.kind == BrickType.EXPLOSIVE:
            return "█▓▓▓▓█"
        elif self.kind == BrickType.POWERUP:
            return "█▒▒▒▒█"
        elif self.kind == BrickType.HARD:
            if self.hp == 3:
                return "██████"
            elif self.hp == 2:
                return "▓▓▓▓▓▓"
            else:
                return "░░░░░░"
        elif self.kind == BrickType.MULTI:
            if self.hp == 2:
                return "██████"
            else:
                return "▒▒▒▒▒▒"
        else:
            return "██████"

    def get_color(self):
        if self.kind == BrickType.INDESTRUCTIBLE:
            return BOLD + C_GRAY
        elif self.kind == BrickType.EXPLOSIVE:
            return BOLD + C_RED
        elif self.kind == BrickType.POWERUP:
            return BOLD + C_GOLD
        elif self.kind == BrickType.HARD:
            if self.hp == 3:
                return BOLD + C_PURPLE
            elif self.hp == 2:
                return C_PURPLE
            else:
                return DIM + C_PURPLE
        elif self.kind == BrickType.MULTI:
            if self.hp == 2:
                return BOLD + self.color
            else:
                return self.color
        return BOLD + self.color


# ---------------------------------------------------------------------------
# Ball and Paddle Entities
# ---------------------------------------------------------------------------

class Ball:
    DEFAULT_SPEED = 18.0

    def __init__(self, x=33.0, y=20.0, vx=12.0, vy=-14.0):
        self.x = float(x)
        self.y = float(y)
        self.vx = float(vx)
        self.vy = float(vy)
        self.base_speed = self.DEFAULT_SPEED
        self.is_fireball = False
        self.attached = False
        self.offset_x = 0.0  # When stuck to paddle
        self.trail = deque(maxlen=4)
        self.active = True

    def speed(self):
        return math.hypot(self.vx, self.vy)

    def normalize_to_speed(self, target_speed):
        curr = self.speed()
        if curr < 0.001:
            self.vx = 0.0
            self.vy = -target_speed
        else:
            scale = target_speed / curr
            self.vx *= scale
            self.vy *= scale


class Paddle:
    DEFAULT_WIDTH = 8

    def __init__(self, x=29, y=21):
        self.x = float(x)
        self.y = float(y)
        self.width = self.DEFAULT_WIDTH
        self.target_x = float(x)
        self.dir = 0
        self.speed = 46.0  # Columns per sec
        self.laser_cooldown = 0.0

    @property
    def int_x(self):
        return int(round(self.x))

    def get_sprite(self, has_laser=False, is_sticky=False):
        w = int(self.width)
        if has_laser:
            inner = "═" * (w - 2)
            return f"▲{inner}▲"
        elif is_sticky:
            inner = "▒" * (w - 2)
            return f"({inner})"
        else:
            inner = "█" * (w - 2)
            return f"◄{inner}►"


# ---------------------------------------------------------------------------
# Level Layout Generator
# ---------------------------------------------------------------------------

class LevelManager:
    """Provides handcrafted level layouts with varied gameplay."""
    @staticmethod
    def get_level(level_num, total_cols=11):
        bricks = []
        l_idx = (level_num - 1) % 5 + 1

        # Power-up pool
        pu_pool = ["EXPAND", "MULTIBALL", "FIREBALL", "LASER", "SLOW", "CATCH", "LIFE", "BOMB", "SHIELD"]

        if l_idx == 1:
            # LEVEL 1: Rainbow Rows (Classic Breakout)
            row_colors = [
                (C_RED, 120, BrickType.NORMAL, 1),
                (C_ORANGE, 100, BrickType.NORMAL, 1),
                (C_YELLOW, 80, BrickType.NORMAL, 1),
                (C_GREEN, 60, BrickType.NORMAL, 1),
                (C_CYAN, 40, BrickType.NORMAL, 1),
                (C_BLUE, 20, BrickType.NORMAL, 1),
            ]
            for r_idx, (color, pts, btype, hp) in enumerate(row_colors):
                for col in range(total_cols):
                    # Random 2 mystery bricks per level
                    is_pu = (r_idx in (1, 3) and col in (3, 7))
                    bkind = BrickType.POWERUP if is_pu else btype
                    pu_type = random.choice(pu_pool) if is_pu else None
                    bricks.append(Brick(col, r_idx, kind=bkind, color=color, points=pts, max_hp=hp, powerup_type=pu_type))

        elif l_idx == 2:
            # LEVEL 2: Pyramid Fortress (Stepped layers with multi-hit armor and explosive core)
            for r in range(6):
                margin = r
                for col in range(margin, total_cols - margin):
                    if r == 5 and col in (4, 5, 6):
                        # Explosive core!
                        bricks.append(Brick(col, r, kind=BrickType.EXPLOSIVE, color=C_RED, points=250))
                    elif r % 2 == 0:
                        # Multi-hit reinforced brick
                        is_pu = (col == margin or col == total_cols - margin - 1)
                        bkind = BrickType.POWERUP if is_pu else BrickType.MULTI
                        pu_type = random.choice(pu_pool) if is_pu else None
                        bricks.append(Brick(col, r, kind=bkind, color=C_GOLD, points=150, max_hp=2, powerup_type=pu_type))
                    else:
                        bricks.append(Brick(col, r, kind=BrickType.NORMAL, color=C_CYAN, points=90, max_hp=1))

        elif l_idx == 3:
            # LEVEL 3: Space Invader Tribute (Crab pixel art made of bricks)
            # 11 columns, 7 rows
            crab_grid = [
                "..X.....X..",
                "...X...X...",
                "..XXXXXXX..",
                ".XX.XXX.XX.",
                "XXXXXXXXXXX",
                ".X.X...X.X.",
                "..X.X.X.X..",
            ]
            for r, line in enumerate(crab_grid):
                for col, ch in enumerate(line):
                    if ch == "X":
                        if r == 4 and col in (2, 8):
                            # Glowing eye power-ups
                            bricks.append(Brick(col, r, kind=BrickType.POWERUP, color=C_GOLD, points=200, powerup_type=random.choice(pu_pool)))
                        elif r in (2, 3) and col in (0, 1, 9, 10):
                            # Claws - Reinforced
                            bricks.append(Brick(col, r, kind=BrickType.MULTI, color=C_MAGENTA, points=160, max_hp=2))
                        elif r == 4 and col == 5:
                            # Center heart explosive
                            bricks.append(Brick(col, r, kind=BrickType.EXPLOSIVE, color=C_RED, points=300))
                        else:
                            bricks.append(Brick(col, r, kind=BrickType.NORMAL, color=C_GREEN, points=100, max_hp=1))

        elif l_idx == 4:
            # LEVEL 4: The Diamond Vault (Silver Indestructible pillars guarding secret treasury)
            for r in range(7):
                for col in range(total_cols):
                    # Outer silver pillars
                    if col in (0, total_cols - 1) and r in (1, 2, 3, 4):
                        bricks.append(Brick(col, r, kind=BrickType.INDESTRUCTIBLE, color=C_GRAY, points=0))
                    elif col in (3, 7) and r in (2, 3):
                        bricks.append(Brick(col, r, kind=BrickType.INDESTRUCTIBLE, color=C_GRAY, points=0))
                    elif 4 <= col <= 6 and 2 <= r <= 4:
                        # Inside the vault
                        if col == 5 and r == 3:
                            bricks.append(Brick(col, r, kind=BrickType.POWERUP, color=C_GOLD, points=500, powerup_type="FIREBALL"))
                        else:
                            bricks.append(Brick(col, r, kind=BrickType.EXPLOSIVE, color=C_RED, points=250))
                    elif (col + r) % 2 == 0:
                        bricks.append(Brick(col, r, kind=BrickType.HARD, color=C_PURPLE, points=180, max_hp=3))
                    else:
                        bricks.append(Brick(col, r, kind=BrickType.NORMAL, color=C_YELLOW, points=80, max_hp=1))

        elif l_idx == 5:
            # LEVEL 5: Cyber Matrix (High intensity boss level with Hard 3-hit, Explosive chains, and multi-powerups)
            for r in range(7):
                for col in range(total_cols):
                    if (r == 0 or r == 6) and (col in (2, 5, 8)):
                        bricks.append(Brick(col, r, kind=BrickType.EXPLOSIVE, color=C_RED, points=300))
                    elif (col == 1 or col == 9) and r in (2, 4):
                        bricks.append(Brick(col, r, kind=BrickType.POWERUP, color=C_GOLD, points=250, powerup_type=random.choice(pu_pool)))
                    elif r % 2 == 0:
                        bricks.append(Brick(col, r, kind=BrickType.HARD, color=C_BLUE, points=220, max_hp=3))
                    else:
                        bricks.append(Brick(col, r, kind=BrickType.MULTI, color=C_ORANGE, points=140, max_hp=2))

        # Level scaling for looping beyond level 5: increase HP or point multipliers
        loop_mult = (level_num - 1) // 5
        if loop_mult > 0:
            for b in bricks:
                b.points = int(b.points * (1.0 + loop_mult * 0.5))

        return bricks


# ---------------------------------------------------------------------------
# Main Breakout Game Engine
# ---------------------------------------------------------------------------

class BreakoutGame:
    TOTAL_COLS = 11
    FIELD_WIDTH = TOTAL_COLS * BRICK_WIDTH  # 66 characters
    FIELD_HEIGHT = 22                        # 22 rows of playfield
    PADDLE_Y = 20
    FLOOR_Y = 21

    def __init__(self):
        self.sound_mgr = SoundManager()
        self.input_handler = InputHandler()
        self.high_score = load_high_score()
        self.state = "TITLE"  # TITLE, SERVE, PLAYING, PAUSED, LEVEL_CLEAR, GAME_OVER, VICTORY

        # Session Stats
        self.score = 0
        self.lives = 3
        self.level = 1
        self.new_high_score = False

        # Combo system
        self.combo = 0
        self.combo_multiplier = 1

        # Entities
        self.paddle = Paddle(x=(self.FIELD_WIDTH - Paddle.DEFAULT_WIDTH) // 2, y=self.PADDLE_Y)
        self.balls = []
        self.bricks = []
        self.powerup_items = []
        self.lasers = []
        self.bombs = []

        # Power-Up Timers & Status
        self.expand_timer = 0.0
        self.fireball_timer = 0.0
        self.laser_timer = 0.0
        self.slow_timer = 0.0
        self.catch_timer = 0.0
        self.shield_active = False

        # Visual Effects
        self.particles = []
        self.floating_texts = []
        self.screen_shake = 0.0

        # State transition timers
        self.state_timer = 0.0
        self.title_pulse = 0.0
        self._previous_frame = None
        self._previous_terminal_size = None

    def start_new_game(self):
        """Initializes game session from level 1."""
        self.score = 0
        self.lives = 3
        self.level = 1
        self.combo = 0
        self.combo_multiplier = 1
        self.new_high_score = False
        self._clear_powerups()
        self.load_level(self.level)

    def load_level(self, level_num):
        """Loads brick layout for the specified level."""
        self.level = level_num
        self.bricks = LevelManager.get_level(self.level, self.TOTAL_COLS)
        self.powerup_items.clear()
        self.lasers.clear()
        self.bombs.clear()
        self.particles.clear()
        self.floating_texts.clear()
        self._clear_powerups()
        self._reset_ball_on_paddle()
        self.state = "SERVE"
        self.state_timer = 0.0

    def _clear_powerups(self):
        self.expand_timer = 0.0
        self.fireball_timer = 0.0
        self.laser_timer = 0.0
        self.slow_timer = 0.0
        self.catch_timer = 0.0
        self.shield_active = False
        self.paddle.width = Paddle.DEFAULT_WIDTH

    def _reset_ball_on_paddle(self):
        """Creates a single ball stuck to paddle ready for serving."""
        self.balls.clear()
        ball = Ball(
            x=self.paddle.x + self.paddle.width / 2.0,
            y=self.PADDLE_Y - 1,
            vx=10.0,
            vy=-14.0
        )
        ball.attached = True
        ball.offset_x = self.paddle.width / 2.0
        self.balls.append(ball)

    def _launch_attached_balls(self, move_dir):
        """Release any balls held on the paddle, including sticky catches."""
        launched = False
        for ball in self.balls:
            if not ball.attached:
                continue
            ball.x = self.paddle.x + ball.offset_x
            ball.y = self.PADDLE_Y - 1
            ball.attached = False
            rel = (ball.offset_x / max(1.0, self.paddle.width)) - 0.5
            ball.vx = rel * 20.0 + (move_dir * 4.0)
            ball.vy = -15.0
            ball.normalize_to_speed(ball.base_speed)
            ball.trail.clear()
            launched = True
        if launched:
            self.sound_mgr.paddle_hit()
        return launched

    def _add_score(self, base_points):
        pts = base_points * self.combo_multiplier
        self.score += pts
        if self.score > self.high_score:
            self.high_score = self.score
            self.new_high_score = True
            save_high_score(self.high_score)
        return pts

    # -----------------------------------------------------------------------
    # Main Game Loop
    # -----------------------------------------------------------------------
    def run(self):
        try:
            self._previous_frame = None
            self._previous_terminal_size = None
            sys.stdout.write(CURSOR_HIDE + CLEAR_SCREEN)
            sys.stdout.flush()

            last_time = time.perf_counter()
            target_fps = 60.0
            frame_duration = 1.0 / target_fps

            while True:
                current_time = time.perf_counter()
                dt = current_time - last_time
                last_time = current_time

                # Cap max dt to avoid spiral of death on lag spikes
                dt = min(dt, 0.08)

                # 1. Process Input
                actions = self.input_handler.poll_keys()
                if actions["quit"]:
                    if self.state == "TITLE":
                        break
                    else:
                        self.state = "TITLE"
                        continue

                if actions["mute"]:
                    self.sound_mgr.toggle()

                # 2. Update Engine
                self.update(dt, actions)

                # 3. Render Frame
                self.render()

                # 4. Regulate Frame Rate
                elapsed = time.perf_counter() - current_time
                sleep_time = frame_duration - elapsed
                if sleep_time > 0.001:
                    time.sleep(sleep_time)

        finally:
            self.sound_mgr.stop()
            self.input_handler.cleanup()
            sys.stdout.write(CURSOR_SHOW + RESET + "\n")
            sys.stdout.flush()

    # -----------------------------------------------------------------------
    # Update Cycle
    # -----------------------------------------------------------------------
    def update(self, dt, actions):
        # Update Title Screen
        if self.state == "TITLE":
            self.title_pulse += dt * 3.0
            if actions["start"] or actions["fire"]:
                self.start_new_game()
            return

        # Update Paused
        if self.state == "PAUSED":
            if actions["pause"] or actions["start"] or actions["fire"]:
                self.state = "PLAYING"
            return

        if actions["pause"]:
            self.state = "PAUSED"
            return

        # Update Game Over
        if self.state == "GAME_OVER":
            if actions["restart"] or actions["start"] or actions["fire"]:
                self.start_new_game()
            return

        # Update Level Clear
        if self.state == "LEVEL_CLEAR":
            self.state_timer -= dt
            self._update_particles(dt)
            self._update_floating_texts(dt)
            if self.state_timer <= 0:
                if self.level >= 5:
                    self.state = "VICTORY"
                else:
                    self.load_level(self.level + 1)
            return

        # Update Victory
        if self.state == "VICTORY":
            if actions["restart"] or actions["start"] or actions["fire"]:
                self.start_new_game()
            return

        # Handle Paddle Movement
        move_dir = 0
        if actions["left"]:
            move_dir -= 1
        if actions["right"]:
            move_dir += 1
        self.paddle.dir = move_dir

        self.paddle.x += move_dir * self.paddle.speed * dt
        # Clamp paddle within field walls
        max_x = self.FIELD_WIDTH - self.paddle.width
        if self.paddle.x < 0:
            self.paddle.x = 0
        elif self.paddle.x > max_x:
            self.paddle.x = max_x

        # Handle Power-up timers
        self._update_powerup_timers(dt)

        # Handle Laser Firing
        if self.laser_timer > 0:
            self.paddle.laser_cooldown -= dt
            if (actions["fire"] or actions["start"]) and self.paddle.laser_cooldown <= 0:
                self.paddle.laser_cooldown = 0.28
                self.sound_mgr.laser_shoot()
                # Twin lasers from paddle tips
                lx1 = self.paddle.x + 0.5
                lx2 = self.paddle.x + self.paddle.width - 1.5
                self.lasers.append(Laser(lx1, self.PADDLE_Y - 0.5))
                self.lasers.append(Laser(lx2, self.PADDLE_Y - 0.5))

        # State: SERVE (Waiting for player to launch ball)
        if self.state == "SERVE":
            for b in self.balls:
                if b.attached:
                    b.x = self.paddle.x + b.offset_x
                    b.y = self.PADDLE_Y - 1
            if actions["fire"] or actions["start"]:
                self._launch_attached_balls(move_dir)
                self.state = "PLAYING"
            return

        # State: PLAYING
        if self.state == "PLAYING":
            if actions["fire"] or actions["start"]:
                self._launch_attached_balls(move_dir)

            # Fireball visual state sync
            for b in self.balls:
                b.is_fireball = (self.fireball_timer > 0)

            # Update Laser projectiles
            self._update_lasers(dt)

            # Update Mega Bomb missiles
            self._update_bombs(dt)

            # Update Falling Power-Up Items
            self._update_powerup_items(dt)

            # Update Ball physics & collisions
            self._update_balls(dt)

            # Update Particles & Floating Texts
            self._update_particles(dt)
            self._update_floating_texts(dt)

            if self.screen_shake > 0:
                self.screen_shake -= dt * 5.0
                if self.screen_shake < 0:
                    self.screen_shake = 0

            # Check Level Cleared (all destructible bricks dead)
            destructible_alive = any(b.alive and b.kind != BrickType.INDESTRUCTIBLE for b in self.bricks)
            if not destructible_alive:
                self.sound_mgr.level_clear()
                bonus = 1000 * self.level
                self._add_score(bonus)
                self.floating_texts.append(
                    FloatingText(self.FIELD_WIDTH // 2 - 8, 12, f"LEVEL CLEAR BONUS +{bonus}!", C_GOLD, life=2.5)
                )
                self.state = "LEVEL_CLEAR"
                self.state_timer = 2.4

    # -----------------------------------------------------------------------
    # Power-Up Timers & Modifiers
    # -----------------------------------------------------------------------
    def _update_powerup_timers(self, dt):
        # Expand Paddle
        if self.expand_timer > 0:
            self.expand_timer -= dt
            self.paddle.width = 12
            if self.expand_timer <= 0:
                self.paddle.width = Paddle.DEFAULT_WIDTH
                # Re-clamp paddle position
                self.paddle.x = min(self.paddle.x, self.FIELD_WIDTH - self.paddle.width)

        # Fireball
        if self.fireball_timer > 0:
            self.fireball_timer -= dt

        # Laser
        if self.laser_timer > 0:
            self.laser_timer -= dt

        # Slow-Mo
        if self.slow_timer > 0:
            self.slow_timer -= dt
            for b in self.balls:
                b.base_speed = Ball.DEFAULT_SPEED * 0.72
        else:
            for b in self.balls:
                b.base_speed = Ball.DEFAULT_SPEED

        # Sticky Catch
        if self.catch_timer > 0:
            self.catch_timer -= dt

    def _activate_powerup(self, kind):
        self.sound_mgr.powerup_collect()
        cfg = POWERUP_CONFIGS.get(kind, POWERUP_CONFIGS["EXPAND"])
        pts = self._add_score(150)
        self.floating_texts.append(
            FloatingText(self.paddle.x + self.paddle.width / 2.0 - 4, self.PADDLE_Y - 2, f"{cfg['name']}! +{pts}", cfg["color"], life=1.6)
        )

        if kind == "EXPAND":
            self.expand_timer = cfg["dur"]
            self.paddle.width = 12
        elif kind == "MULTIBALL":
            # Spawn duplicate balls from existing balls
            new_balls = []
            for b in self.balls:
                if not b.attached:
                    for angle_offset in (-0.5, 0.5):
                        nb = Ball(x=b.x, y=b.y, vx=b.vx, vy=b.vy)
                        nb.base_speed = b.base_speed
                        # Rotate velocity vector slightly
                        cos_a = math.cos(angle_offset)
                        sin_a = math.sin(angle_offset)
                        nb.vx = b.vx * cos_a - b.vy * sin_a
                        nb.vy = b.vx * sin_a + b.vy * cos_a
                        nb.normalize_to_speed(b.base_speed)
                        new_balls.append(nb)
            if not new_balls and self.balls:
                # If only 1 attached ball
                b = self.balls[0]
                new_balls.append(Ball(b.x, b.y, vx=-12.0, vy=-14.0))
                new_balls.append(Ball(b.x, b.y, vx=12.0, vy=-14.0))
            self.balls.extend(new_balls)
        elif kind == "FIREBALL":
            self.fireball_timer = cfg["dur"]
        elif kind == "LASER":
            self.laser_timer = cfg["dur"]
        elif kind == "SLOW":
            self.slow_timer = cfg["dur"]
        elif kind == "CATCH":
            self.catch_timer = cfg["dur"]
        elif kind == "LIFE":
            if self.lives < 5:
                self.lives += 1
        elif kind == "BOMB":
            # Launch Mega Bomb rocket from paddle
            bx = self.paddle.x + self.paddle.width / 2.0
            self.bombs.append(MissileBomb(bx, self.PADDLE_Y - 1))
        elif kind == "SHIELD":
            self.shield_active = True

    # -----------------------------------------------------------------------
    # Sub-Pixel Ball Physics & Continuous Collision Detection
    # -----------------------------------------------------------------------
    def _update_balls(self, dt):
        # We sub-step physics to avoid high-speed ball tunneling
        for ball in self.balls[:]:
            if not ball.active:
                continue

            if ball.attached:
                ball.x = self.paddle.x + ball.offset_x
                ball.y = self.PADDLE_Y - 1
                continue

            # Record trail
            ball.trail.append((ball.x, ball.y))

            spd = ball.speed()
            steps = max(1, int(math.ceil(spd * dt / 0.45)))
            sub_dt = dt / steps

            for _ in range(steps):
                if not ball.active or ball.attached:
                    break
                self._ball_sub_step(ball, sub_dt)

        # Remove dead balls
        self.balls = [b for b in self.balls if b.active]

        # Check if all balls were lost
        if not self.balls:
            self.lives -= 1
            self.sound_mgr.ball_lost()
            self._clear_powerups()
            self.combo = 0
            self.combo_multiplier = 1

            if self.lives <= 0:
                self.sound_mgr.game_over()
                self.state = "GAME_OVER"
            else:
                self._reset_ball_on_paddle()
                self.state = "SERVE"

    def _ball_sub_step(self, ball, dt):
        prev_x = ball.x
        prev_y = ball.y

        ball.x += ball.vx * dt
        ball.y += ball.vy * dt

        # 1. Left Wall Collision
        if ball.x <= 0:
            ball.x = 0
            ball.vx = abs(ball.vx)
            self.sound_mgr.wall_bounce()
            self._spawn_sparks(ball.x, ball.y, C_CYAN)

        # 2. Right Wall Collision
        elif ball.x >= self.FIELD_WIDTH - 1:
            ball.x = self.FIELD_WIDTH - 1
            ball.vx = -abs(ball.vx)
            self.sound_mgr.wall_bounce()
            self._spawn_sparks(ball.x, ball.y, C_CYAN)

        # 3. Top Wall Collision
        if ball.y <= 0:
            ball.y = 0
            ball.vy = abs(ball.vy)
            self.sound_mgr.wall_bounce()
            self._spawn_sparks(ball.x, ball.y, C_CYAN)

        # 4. Paddle Collision
        if ball.vy > 0 and prev_y <= self.PADDLE_Y <= ball.y:
            px1 = self.paddle.x
            px2 = self.paddle.x + self.paddle.width
            if px1 - 0.75 <= ball.x <= px2 + 0.75:
                ball.y = self.PADDLE_Y - 1

                # If Sticky Catch is active, attach ball to paddle
                if self.catch_timer > 0:
                    ball.attached = True
                    ball.offset_x = max(0.5, min(self.paddle.width - 0.5, ball.x - self.paddle.x))
                    self.sound_mgr.paddle_hit()
                    return

                # Calculate deflection angle based on hit position
                rel = (ball.x - px1) / max(1.0, self.paddle.width)  # [0.0, 1.0]
                offset = (rel - 0.5) * 2.0                         # [-1.0, 1.0]

                # Blend offset with paddle moving momentum
                spin = self.paddle.dir * 4.0
                ball.vx = offset * (ball.base_speed * 1.25) + spin

                # Recompute vy ensuring strong upward flight
                ball.vy = -math.sqrt(max(40.0, ball.base_speed**2 - (ball.vx * 0.75)**2))
                ball.normalize_to_speed(ball.base_speed)

                self.combo = 0
                self.combo_multiplier = 1
                self.sound_mgr.paddle_hit()
                self._spawn_sparks(ball.x, ball.y, C_YELLOW)
                return

        # 5. Energy Shield Floor Barrier Collision
        if self.shield_active and ball.y >= self.FLOOR_Y:
            ball.y = self.FLOOR_Y - 1
            ball.vy = -abs(ball.vy)
            self.shield_active = False  # Consumed
            self.sound_mgr.shield_bounce()
            self._spawn_sparks(ball.x, self.FLOOR_Y, C_WHITE, count=14)
            self.floating_texts.append(FloatingText(ball.x - 4, self.FLOOR_Y - 1, "SHIELD SAVED!", C_CYAN, life=1.2))
            return

        # 6. Bottom Floor (Ball Out of Play)
        if ball.y > self.FIELD_HEIGHT:
            ball.active = False
            return

        # 7. Brick Collisions
        hit_brick = self._check_brick_collision(ball, prev_x, prev_y)
        if hit_brick:
            self._handle_brick_hit(hit_brick, ball)

    def _check_brick_collision(self, ball, prev_x, prev_y):
        """Returns the brick struck by the ball, if any, and handles bounce reflection."""
        for brick in self.bricks:
            if not brick.alive:
                continue

            bx1 = brick.x
            bx2 = brick.x + BRICK_WIDTH
            by1 = brick.y
            by2 = brick.y + 1

            if bx1 <= ball.x < bx2 and by1 <= ball.y < by2:
                # Collision detected!
                if not ball.is_fireball and brick.kind != BrickType.INDESTRUCTIBLE:
                    # Determine hit side
                    if prev_y < by1:
                        ball.vy = -abs(ball.vy)
                        ball.y = by1 - 0.1
                    elif prev_y >= by2:
                        ball.vy = abs(ball.vy)
                        ball.y = by2 + 0.1
                    elif prev_x < bx1:
                        ball.vx = -abs(ball.vx)
                        ball.x = bx1 - 0.1
                    elif prev_x >= bx2:
                        ball.vx = abs(ball.vx)
                        ball.x = bx2 + 0.1
                    else:
                        ball.vy = -ball.vy
                elif brick.kind == BrickType.INDESTRUCTIBLE:
                    # Indestructible always reflects ball even if fireball
                    if prev_y < by1:
                        ball.vy = -abs(ball.vy)
                    elif prev_y >= by2:
                        ball.vy = abs(ball.vy)
                    else:
                        ball.vx = -ball.vx

                return brick
        return None

    def _handle_brick_hit(self, brick, source_ball=None):
        if brick.kind == BrickType.INDESTRUCTIBLE:
            self.sound_mgr.wall_bounce()
            self._spawn_sparks(brick.x + 3, brick.y, C_GRAY)
            return

        # Damage brick
        damage = 99 if (source_ball and source_ball.is_fireball) else 1
        brick.hp -= damage

        if brick.hp <= 0:
            # Brick Destroyed
            brick.alive = False
            self.combo += 1
            if self.combo >= 8:
                self.combo_multiplier = 4
            elif self.combo >= 5:
                self.combo_multiplier = 3
            elif self.combo >= 3:
                self.combo_multiplier = 2
            else:
                self.combo_multiplier = 1

            pts = self._add_score(brick.points)
            self.sound_mgr.brick_shatter()
            self._spawn_brick_debris(brick.x + 3, brick.y, brick.color)

            # Floating score text with combo
            combo_tag = f" (x{self.combo_multiplier})" if self.combo_multiplier > 1 else ""
            self.floating_texts.append(
                FloatingText(brick.x, brick.y, f"+{pts}{combo_tag}", brick.color, life=1.0)
            )

            # Power-up drop logic
            if brick.kind == BrickType.POWERUP or brick.powerup_type:
                pu_type = brick.powerup_type or random.choice(list(POWERUP_CONFIGS.keys()))
                self.powerup_items.append(PowerUpItem(brick.x + 2, brick.y, pu_type))
                self.sound_mgr.powerup_drop()
            elif random.random() < 0.18:
                # Random drop chance from normal bricks
                pu_type = random.choice(list(POWERUP_CONFIGS.keys()))
                self.powerup_items.append(PowerUpItem(brick.x + 2, brick.y, pu_type))
                self.sound_mgr.powerup_drop()

            # Explosive brick chain detonation
            if brick.kind == BrickType.EXPLOSIVE:
                self._trigger_explosion(brick.col, brick.row)

        else:
            # Brick Damaged
            self.sound_mgr.brick_hit()
            self._spawn_sparks(brick.x + 3, brick.y, brick.color)

    def _trigger_explosion(self, center_col, center_row):
        """Detonates a 3x3 brick radius with particle explosion and chain reactions."""
        self.sound_mgr.explosion()
        self.screen_shake = 0.35
        ex_x = center_col * BRICK_WIDTH + 3
        ex_y = center_row + 3
        self._spawn_explosion_particles(ex_x, ex_y, C_RED, count=22)
        self.floating_texts.append(FloatingText(ex_x - 4, ex_y, "KABOOM!", C_ORANGE, life=1.4))

        for b in self.bricks:
            if b.alive and b.kind != BrickType.INDESTRUCTIBLE:
                if abs(b.col - center_col) <= 1 and abs(b.row - center_row) <= 1:
                    # Destroy adjacent bricks in blast
                    b.hp = 0
                    b.alive = False
                    pts = self._add_score(b.points)
                    self._spawn_brick_debris(b.x + 3, b.y, b.color, count=5)
                    if b.kind == BrickType.EXPLOSIVE and (b.col != center_col or b.row != center_row):
                        # Chain reaction!
                        self._trigger_explosion(b.col, b.row)

    # -----------------------------------------------------------------------
    # Lasers & Missiles
    # -----------------------------------------------------------------------
    def _update_lasers(self, dt):
        for laser in self.lasers[:]:
            laser.update(dt)
            if laser.y < 0:
                self.lasers.remove(laser)
                continue

            # Check collision with bricks
            hit = False
            for brick in self.bricks:
                if brick.alive:
                    if brick.x <= laser.x < brick.x + BRICK_WIDTH and brick.y <= laser.y < brick.y + 1:
                        self._handle_brick_hit(brick)
                        hit = True
                        break
            if hit:
                self.lasers.remove(laser)

    def _update_bombs(self, dt):
        for bomb in self.bombs[:]:
            bomb.update(dt)
            if bomb.y < 0:
                self.bombs.remove(bomb)
                continue

            # Check collision with any brick
            hit = False
            for brick in self.bricks:
                if brick.alive:
                    if brick.x <= bomb.x < brick.x + BRICK_WIDTH and brick.y <= bomb.y < brick.y + 1:
                        self._trigger_explosion(brick.col, brick.row)
                        hit = True
                        break
            if hit:
                self.bombs.remove(bomb)

    def _update_powerup_items(self, dt):
        for item in self.powerup_items[:]:
            item.update(dt)
            # Check catch by paddle
            if self.PADDLE_Y <= item.y <= self.PADDLE_Y + 1.2:
                px1 = self.paddle.x
                px2 = self.paddle.x + self.paddle.width
                if px1 <= item.x <= px2:
                    self._activate_powerup(item.kind)
                    self.powerup_items.remove(item)
                    continue

            # Fallen out of screen
            if item.y > self.FIELD_HEIGHT:
                self.powerup_items.remove(item)

    # -----------------------------------------------------------------------
    # Particles and Effects
    # -----------------------------------------------------------------------
    def _spawn_sparks(self, x, y, color, count=5):
        chars = ["*", "·", "+", "."]
        for _ in range(count):
            vx = random.uniform(-14.0, 14.0)
            vy = random.uniform(-12.0, 4.0)
            life = random.uniform(0.15, 0.35)
            self.particles.append(Particle(x, y, random.choice(chars), color, life, vx, vy, gravity=25.0))

    def _spawn_brick_debris(self, x, y, color, count=8):
        chars = ["█", "▓", "▒", "*", "■"]
        for _ in range(count):
            vx = random.uniform(-18.0, 18.0)
            vy = random.uniform(-14.0, 8.0)
            life = random.uniform(0.3, 0.6)
            self.particles.append(Particle(x, y, random.choice(chars), color, life, vx, vy, gravity=30.0))

    def _spawn_explosion_particles(self, x, y, color, count=20):
        chars = ["*", "▲", "O", "!", "■", "░"]
        for _ in range(count):
            angle = random.uniform(0, 2 * math.pi)
            spd = random.uniform(10.0, 28.0)
            vx = math.cos(angle) * spd
            vy = math.sin(angle) * spd
            life = random.uniform(0.4, 0.8)
            p_col = random.choice([C_RED, C_ORANGE, C_YELLOW, C_WHITE])
            self.particles.append(Particle(x, y, random.choice(chars), p_col, life, vx, vy, gravity=18.0))

    def _update_particles(self, dt):
        self.particles = [p for p in self.particles if p.update(dt)]

    def _update_floating_texts(self, dt):
        self.floating_texts = [ft for ft in self.floating_texts if ft.update(dt)]

    # -----------------------------------------------------------------------
    # Double-Buffered ANSI Screen Rendering
    # -----------------------------------------------------------------------
    def render(self):
        # Determine terminal size
        try:
            term_cols, term_lines = os.get_terminal_size()
        except Exception:
            term_cols, term_lines = 80, 28

        # Playfield inner canvas: FIELD_WIDTH x FIELD_HEIGHT
        # With border and HUD:
        total_w = self.FIELD_WIDTH + 2   # 68 chars
        total_h = self.FIELD_HEIGHT + 5  # 27 rows (1 Top HUD, 1 Top Border, 22 Field, 1 Bottom Border, 2 Bottom HUD)

        chars = [[" " for _ in range(total_w)] for _ in range(total_h)]
        colors = [["" for _ in range(total_w)] for _ in range(total_h)]

        pad_x = max(0, (term_cols - total_w) // 2)
        pad_y = max(0, (term_lines - total_h) // 2)
        left_pad = " " * pad_x

        # 1. Top HUD (Row 0)
        hud_score = f"SCORE: {self.score:06d}"
        hud_high  = f"HIGH: {self.high_score:06d}"
        hud_level = f"LVL: {self.level}/5"
        lives_icons = "♥ " * self.lives
        hud_lives = f"LIVES: {lives_icons.strip()}"

        combo_str = f"COMBO: x{self.combo_multiplier}" if self.combo_multiplier > 1 else ""

        hud_line = f" {hud_score}   {hud_high}   {hud_level}   {hud_lives}   {combo_str}"
        for i, ch in enumerate(hud_line):
            if i < total_w:
                chars[0][i] = ch
                if "SCORE" in hud_line[max(0, i-6):i+1]:
                    colors[0][i] = BOLD + C_YELLOW
                elif "HIGH" in hud_line[max(0, i-5):i+1]:
                    colors[0][i] = BOLD + C_CYAN
                elif "♥" in ch:
                    colors[0][i] = BOLD + C_RED
                elif "COMBO" in hud_line[max(0, i-6):i+1]:
                    colors[0][i] = BOLD + C_GOLD
                else:
                    colors[0][i] = C_WHITE

        # 2. Borders (Row 1 is top, Row total_h - 3 is bottom)
        top_b_y = 1
        bot_b_y = total_h - 3

        # Border color changes if screen shake active
        border_col = BOLD + (C_RED if self.screen_shake > 0 else C_BLUE)

        chars[top_b_y][0] = "╔"
        colors[top_b_y][0] = border_col
        for x in range(1, total_w - 1):
            chars[top_b_y][x] = "═"
            colors[top_b_y][x] = border_col
        chars[top_b_y][total_w - 1] = "╗"
        colors[top_b_y][total_w - 1] = border_col

        for y in range(top_b_y + 1, bot_b_y):
            chars[y][0] = "║"
            colors[y][0] = border_col
            chars[y][total_w - 1] = "║"
            colors[y][total_w - 1] = border_col

        chars[bot_b_y][0] = "╚"
        colors[bot_b_y][0] = border_col
        for x in range(1, total_w - 1):
            chars[bot_b_y][x] = "═"
            colors[bot_b_y][x] = border_col
        chars[bot_b_y][total_w - 1] = "╝"
        colors[bot_b_y][total_w - 1] = border_col

        # 3. Energy Shield (if active) at floor
        if self.shield_active:
            sy = self.FLOOR_Y + top_b_y + 1
            if top_b_y < sy < bot_b_y:
                for x in range(1, total_w - 1):
                    chars[sy][x] = "╍"
                    colors[sy][x] = BOLD + C_CYAN

        # 4. Bricks
        for b in self.bricks:
            if b.alive:
                by = b.y + top_b_y + 1
                if top_b_y < by < bot_b_y:
                    sprite = b.get_sprite()
                    b_col = b.get_color()
                    for i, ch in enumerate(sprite):
                        px = b.x + i + 1
                        if 1 <= px < total_w - 1:
                            chars[by][px] = ch
                            colors[by][px] = b_col

        # 5. Falling Power-Up Items
        for item in self.powerup_items:
            iy = int(round(item.y)) + top_b_y + 1
            ix = int(round(item.x)) + 1
            if top_b_y < iy < bot_b_y and 1 <= ix < total_w - 3:
                pill = f"[{item.cfg['code']}]"
                for i, ch in enumerate(pill):
                    chars[iy][ix + i] = ch
                    colors[iy][ix + i] = BOLD + item.cfg["color"]

        # 6. Lasers & Bombs
        for laser in self.lasers:
            ly = int(round(laser.y)) + top_b_y + 1
            lx = int(round(laser.x)) + 1
            if top_b_y < ly < bot_b_y and 1 <= lx < total_w - 1:
                chars[ly][lx] = "║"
                colors[ly][lx] = BOLD + C_GOLD

        for bomb in self.bombs:
            by = int(round(bomb.y)) + top_b_y + 1
            bx = int(round(bomb.x)) + 1
            if top_b_y < by < bot_b_y and 1 <= bx < total_w - 1:
                chars[by][bx] = "▲"
                colors[by][bx] = BOLD + C_RED

        # 7. Ball Trails & Balls
        for ball in self.balls:
            if ball.active:
                # Faint trail
                for tx, ty in ball.trail:
                    t_iy = int(round(ty)) + top_b_y + 1
                    t_ix = int(round(tx)) + 1
                    if top_b_y < t_iy < bot_b_y and 1 <= t_ix < total_w - 1:
                        if chars[t_iy][t_ix] == " ":
                            chars[t_iy][t_ix] = "·"
                            colors[t_iy][t_ix] = DIM + (C_ORANGE if ball.is_fireball else C_CYAN)

                # Ball itself
                by = int(round(ball.y)) + top_b_y + 1
                bx = int(round(ball.x)) + 1
                if top_b_y < by < bot_b_y and 1 <= bx < total_w - 1:
                    chars[by][bx] = "●"
                    colors[by][bx] = BOLD + (C_ORANGE if ball.is_fireball else C_WHITE)

        # 8. Player Paddle
        py = self.PADDLE_Y + top_b_y + 1
        px = self.paddle.int_x + 1
        has_laser = (self.laser_timer > 0)
        is_sticky = (self.catch_timer > 0)
        p_sprite = self.paddle.get_sprite(has_laser=has_laser, is_sticky=is_sticky)
        p_color = BOLD + (C_GOLD if has_laser else (C_PURPLE if is_sticky else (C_GREEN if self.expand_timer > 0 else C_CYAN)))

        for i, ch in enumerate(p_sprite):
            cur_x = px + i
            if 1 <= cur_x < total_w - 1:
                chars[py][cur_x] = ch
                colors[py][cur_x] = p_color

        # 9. Explosions & Particles
        for p in self.particles:
            iy = int(round(p.y)) + top_b_y + 1
            ix = int(round(p.x)) + 1
            if top_b_y < iy < bot_b_y and 1 <= ix < total_w - 1:
                chars[iy][ix] = p.char
                colors[iy][ix] = BOLD + p.color

        # 10. Floating Texts
        for ft in self.floating_texts:
            fy = int(round(ft.y)) + top_b_y + 1
            if top_b_y < fy < bot_b_y:
                fx = int(round(ft.x)) + 1
                for i, ch in enumerate(ft.text):
                    cur_x = fx + i
                    if 1 <= cur_x < total_w - 1:
                        chars[fy][cur_x] = ch
                        colors[fy][cur_x] = BOLD + ft.color

        # 11. Bottom Controls & Power-Up HUD (Rows total_h - 2 and total_h - 1)
        # Power-ups status bar
        pu_active = []
        if self.expand_timer > 0:
            pu_active.append(f"[WIDE:{int(self.expand_timer)}s]")
        if self.fireball_timer > 0:
            pu_active.append(f"[FIRE:{int(self.fireball_timer)}s]")
        if self.laser_timer > 0:
            pu_active.append(f"[LASER:{int(self.laser_timer)}s]")
        if self.slow_timer > 0:
            pu_active.append(f"[SLOW:{int(self.slow_timer)}s]")
        if self.catch_timer > 0:
            pu_active.append(f"[CATCH:{int(self.catch_timer)}s]")
        if self.shield_active:
            pu_active.append("[SHIELD:OK]")

        pu_str = "PWR: " + (" ".join(pu_active) if pu_active else "NONE")
        for i, ch in enumerate(pu_str):
            if i < total_w:
                chars[total_h - 2][i] = ch
                colors[total_h - 2][i] = BOLD + C_GOLD if "PWR:" in pu_str[:i+1] else C_CYAN

        controls_str = "[A/D] Move   [SPACE] Launch/Fire   [P] Pause   [M] Mute   [Q] Title/Quit"
        for i, ch in enumerate(controls_str):
            if i < total_w:
                chars[total_h - 1][i] = ch
                colors[total_h - 1][i] = DIM + C_WHITE

        # 12. State Overlays
        if self.state == "TITLE":
            self._render_title_overlay(chars, colors, total_w, total_h)
        elif self.state == "SERVE" or (self.state == "PLAYING" and any(b.attached for b in self.balls)):
            msg = ("[ PRESS SPACE OR W TO LAUNCH BALL ]" if self.state == "SERVE"
                   else "[ BALL CAUGHT - PRESS SPACE OR W TO LAUNCH ]")
            sx = (total_w - len(msg)) // 2
            sy = self.PADDLE_Y - 3 + top_b_y + 1
            for i, ch in enumerate(msg):
                chars[sy][sx + i] = ch
                colors[sy][sx + i] = BOLD + C_YELLOW
        elif self.state == "PAUSED":
            self._render_box_overlay(
                chars, colors, total_w, total_h,
                title="[ GAME PAUSED ]",
                lines=[
                    "Press [P] or [SPACE] to Resume",
                    "Press [M] to Toggle Sound",
                    "Press [Q] to Return to Title",
                ],
                border_color=BOLD + C_CYAN
            )
        elif self.state == "LEVEL_CLEAR":
            self._render_box_overlay(
                chars, colors, total_w, total_h,
                title=f"[ LEVEL {self.level} COMPLETED! ]",
                lines=[
                    f"Level Clear Bonus: +{1000 * self.level} PTS",
                    f"Current Score: {self.score:06d}",
                    "Preparing Next Level Challenge...",
                ],
                border_color=BOLD + C_GREEN
            )
        elif self.state == "GAME_OVER":
            high_msg = "★ NEW HIGH SCORE! ★" if self.new_high_score else f"High Score: {self.high_score:06d}"
            self._render_box_overlay(
                chars, colors, total_w, total_h,
                title="[ GAME OVER ]",
                lines=[
                    f"Final Score: {self.score:06d}",
                    high_msg,
                    "",
                    "Press [R] or [SPACE] to Play Again",
                    "Press [Q] to Return to Title",
                ],
                border_color=BOLD + C_RED
            )
        elif self.state == "VICTORY":
            self._render_box_overlay(
                chars, colors, total_w, total_h,
                title="★ VICTORY! GRAND CHAMPION ★",
                lines=[
                    "CONGRATULATIONS!",
                    "You smashed all 5 Matrix Sectors!",
                    f"Grand Master Score: {self.score:06d}",
                    "",
                    "Press [R] or [SPACE] to Play Again",
                    "Press [Q] to Return to Title",
                ],
                border_color=BOLD + C_GOLD
            )

        # 13. Only send changed rows. Full color frames can fill a terminal's
        # output pipe and delay the next input poll, especially on Windows.
        out_lines = []
        for y in range(total_h):
            line_parts = [left_pad]
            curr_color = ""
            for x in range(total_w):
                ch = chars[y][x]
                col = colors[y][x]
                if col != curr_color:
                    line_parts.append(col if col else RESET)
                    curr_color = col
                line_parts.append(ch)
            if curr_color:
                line_parts.append(RESET)
            out_lines.append("".join(line_parts))

        size = (term_cols, term_lines)
        if self._previous_frame is None or size != self._previous_terminal_size:
            frame_data = CLEAR_SCREEN + CURSOR_HOME + ("\n" * pad_y) + "\n".join(out_lines)
        else:
            frame_data = "".join(
                f"\033[{pad_y + y + 1};1H{line}"
                for y, line in enumerate(out_lines)
                if line != self._previous_frame[y]
            )
        self._previous_frame = out_lines
        self._previous_terminal_size = size
        if frame_data:
            sys.stdout.write(frame_data)
            sys.stdout.flush()

    def _render_box_overlay(self, chars, colors, total_w, total_h, title, lines, border_color):
        box_w = max(len(title) + 4, max(len(l) for l in lines) + 6, 38)
        box_h = len(lines) + 4
        start_x = (total_w - box_w) // 2
        start_y = (total_h - box_h) // 2

        # Clear background inside dialog box
        for y in range(start_y, start_y + box_h):
            for x in range(start_x, start_x + box_w):
                chars[y][x] = " "
                colors[y][x] = RESET

        # Draw box border
        chars[start_y][start_x] = "┌"
        colors[start_y][start_x] = border_color
        for x in range(start_x + 1, start_x + box_w - 1):
            chars[start_y][x] = "─"
            colors[start_y][x] = border_color
        chars[start_y][start_x + box_w - 1] = "┐"
        colors[start_y][start_x + box_w - 1] = border_color

        for y in range(start_y + 1, start_y + box_h - 1):
            chars[y][start_x] = "│"
            colors[y][start_x] = border_color
            chars[y][start_x + box_w - 1] = "│"
            colors[y][start_x + box_w - 1] = border_color

        chars[start_y + box_h - 1][start_x] = "└"
        colors[start_y + box_h - 1][start_x] = border_color
        for x in range(start_x + 1, start_x + box_w - 1):
            chars[start_y + box_h - 1][x] = "─"
            colors[start_y + box_h - 1][x] = border_color
        chars[start_y + box_h - 1][start_x + box_w - 1] = "┘"
        colors[start_y + box_h - 1][start_x + box_w - 1] = border_color

        # Title
        t_x = start_x + (box_w - len(title)) // 2
        for i, ch in enumerate(title):
            chars[start_y + 1][t_x + i] = ch
            colors[start_y + 1][t_x + i] = border_color

        # Content Lines
        for idx, line in enumerate(lines):
            l_y = start_y + 2 + idx
            l_x = start_x + (box_w - len(line)) // 2
            for i, ch in enumerate(line):
                chars[l_y][l_x + i] = ch
                colors[l_y][l_x + i] = BOLD + C_WHITE if ("★" in line or "Bonus" in line or "CONGRATULATIONS" in line) else C_WHITE

    def _render_title_overlay(self, chars, colors, total_w, total_h):
        # Clear play area for Title Screen
        for y in range(2, total_h - 3):
            for x in range(1, total_w - 1):
                chars[y][x] = " "
                colors[y][x] = RESET

        banner = [
            r"                                                         ",
            r"█████▄ █████▄  ██████ ▄████▄ ██ ▄█▀ ▄████▄ ██  ██ ██████ ",
            r"██▄▄██ ██▄▄██▄ ██▄▄   ██▄▄██ ████   ██  ██ ██  ██   ██   ",
            r"██▄▄█▀ ██   ██ ██▄▄▄▄ ██  ██ ██ ▀█▄ ▀████▀ ▀████▀   ██   ",
            r" ",
        ]
        start_y = 4
        logo_colors = [C_RED, C_ORANGE, C_YELLOW, C_GREEN, C_CYAN]

        for idx, line in enumerate(banner):
            bx = (total_w - len(line)) // 2
            for i, ch in enumerate(line):
                chars[start_y + idx][bx + i] = ch
                colors[start_y + idx][bx + i] = BOLD + logo_colors[idx % len(logo_colors)]

        sub_msg = "(c) 1982 ATARI - PROGRAMMED BY BAES INC."
        sx = max(1, (total_w - len(sub_msg)) // 2)
        if start_y + 6 < total_h:
            for i, ch in enumerate(sub_msg):
                if 1 <= sx + i < total_w - 1:
                    chars[start_y + 6][sx + i] = ch
                    colors[start_y + 6][sx + i] = BOLD + C_WHITE

        # Features & Power-ups legend
        legend_lines = [
            "[E] Wide Paddle    [M] Multi-Ball     [F] Fireball",
            "[L] Twin Lasers    [S] Slow Motion    [C] Sticky Catch",
            "[+] Extra Life     [B] Mega Bomb      [X] Shield Net",
        ]
        for idx, line in enumerate(legend_lines):
            ly = start_y + 8 + idx
            if ly < total_h:
                lx = max(1, (total_w - len(line)) // 2)
                for i, ch in enumerate(line):
                    if 1 <= lx + i < total_w - 1:
                        chars[ly][lx + i] = ch
                        colors[ly][lx + i] = C_CYAN if "[" in line[max(0, i-2):i+1] else C_WHITE

        high_msg = f"★ ALL-TIME HIGH SCORE: {self.high_score:06d} ★"
        hx = max(1, (total_w - len(high_msg)) // 2)
        if start_y + 12 < total_h:
            for i, ch in enumerate(high_msg):
                if 1 <= hx + i < total_w - 1:
                    chars[start_y + 12][hx + i] = ch
                    colors[start_y + 12][hx + i] = BOLD + C_GOLD

        # Flashing Start Prompt
        blink = int(self.title_pulse) % 2 == 0
        prompt = "PRESS [SPACE] OR [ENTER] TO START"
        px = max(1, (total_w - len(prompt)) // 2)
        if start_y + 14 < total_h:
            for i, ch in enumerate(prompt):
                if 1 <= px + i < total_w - 1:
                    chars[start_y + 14][px + i] = ch
                    colors[start_y + 14][px + i] = BOLD + (C_YELLOW if blink else DIM + C_YELLOW)

        credits_str = "Controls: [A/D] Move  [SPACE] Launch/Laser  [M] Mute  [P] Pause"
        cx = max(1, (total_w - len(credits_str)) // 2)
        if start_y + 16 < total_h:
            for i, ch in enumerate(credits_str):
                if 1 <= cx + i < total_w - 1:
                    chars[start_y + 16][cx + i] = ch
                    colors[start_y + 16][cx + i] = DIM + C_WHITE


# ---------------------------------------------------------------------------
# Entry Point
# ---------------------------------------------------------------------------

def main():
    game = BreakoutGame()
    game.run()

if __name__ == "__main__":
    main()
