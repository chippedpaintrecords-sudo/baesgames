#!/usr/bin/env python3
"""
BREAKOUT - Arcade Terminal Clone
================================
Launch script for the Breakout arcade terminal game.
"""

from breakout import main

if __name__ == "__main__":
    main()
