"""Wave choreographer, stage management, and enemy dive logic."""

import random
from typing import List, Tuple, Optional
from .config import PLAYFIELD_WIDTH, PLAYFIELD_HEIGHT, DIVE_COOLDOWN_BASE
from .entities import Enemy, EnemyType, EnemyState
from .formations import (
    generate_entry_path_top_right, generate_entry_path_top_left,
    generate_entry_path_bottom_left, generate_entry_path_bottom_right,
    generate_dive_path, generate_tractor_dive_path,
    generate_challenging_wave_path
)


class WaveManager:
    """Manages enemy formation creation, entry waves, diving behavior, and challenging stages."""

    def __init__(self, playfield_w: int = PLAYFIELD_WIDTH, playfield_h: int = PLAYFIELD_HEIGHT):
        self.playfield_w = playfield_w
        self.playfield_h = playfield_h
        self.stage = 1
        self.is_challenging = False
        self.enemies: List[Enemy] = []

        # Entry choreography
        self.entry_queue: List[Tuple[Enemy, List[Tuple[float, float]], int]] = []
        self.entry_tick = 0
        self.dive_timer = 0
        self.dive_interval = DIVE_COOLDOWN_BASE

        # Challenging stage tracking
        self.challenging_hits = 0
        self.challenging_total = 40
        self.challenging_wave_idx = 0
        self.challenging_timer = 0
        self.challenging_finished = False

    def is_stage_challenging(self, stage: int) -> bool:
        """Stages 3, 7, 11, 15... are bonus Challenging Stages."""
        return stage % 4 == 3

    def setup_stage(self, stage: int):
        self.stage = stage
        self.is_challenging = self.is_stage_challenging(stage)
        self.enemies.clear()
        self.entry_queue.clear()
        self.entry_tick = 0
        self.dive_timer = 0
        self.dive_interval = max(35, DIVE_COOLDOWN_BASE - (stage * 3))
        self.challenging_hits = 0
        self.challenging_wave_idx = 0
        self.challenging_timer = 0
        self.challenging_finished = False

        if self.is_challenging:
            self._setup_challenging_stage()
        else:
            self._setup_standard_stage()

    def _setup_standard_stage(self):
        """Construct the classic 40-enemy Galaga formation grid and entry paths."""
        # Grid layout:
        # Row 0: 4 Boss Galagas (Cols 3, 4, 5, 6)
        # Row 1: 8 Red Butterflies (Cols 1 to 8)
        # Row 2: 8 Red Butterflies (Cols 1 to 8)
        # Row 3: 10 Blue Bees (Cols 0 to 9)
        # Row 4: 10 Blue Bees (Cols 0 to 9)
        spacing_x = 4.4
        spacing_y = 2.2
        start_x = (self.playfield_w - (9 * spacing_x)) / 2.0
        start_y = 3.5

        def get_pos(r: int, c: int) -> Tuple[float, float]:
            return (start_x + c * spacing_x, start_y + r * spacing_y)

        # 1. Row 0: 4 Bosses
        bosses = [Enemy(EnemyType.BOSS, 0, c, *get_pos(0, c)) for c in [3, 4, 5, 6]]
        # 2. Row 1: 8 Butterflies
        butterflies_r1 = [Enemy(EnemyType.BUTTERFLY, 1, c, *get_pos(1, c)) for c in range(1, 9)]
        # 3. Row 2: 8 Butterflies
        butterflies_r2 = [Enemy(EnemyType.BUTTERFLY, 2, c, *get_pos(2, c)) for c in range(1, 9)]
        # 4. Row 3: 10 Bees
        bees_r3 = [Enemy(EnemyType.BEE, 3, c, *get_pos(3, c)) for c in range(10)]
        # 5. Row 4: 10 Bees
        bees_r4 = [Enemy(EnemyType.BEE, 4, c, *get_pos(4, c)) for c in range(10)]

        all_grid_enemies = bosses + butterflies_r1 + butterflies_r2 + bees_r3 + bees_r4
        self.enemies = all_grid_enemies

        # Form entry waves (5 waves of 8 enemies each)
        # Wave 0: 4 Butterflies (r1[0:4]) + 4 Butterflies (r2[0:4]) -> Top Right
        wave0 = butterflies_r1[0:4] + butterflies_r2[0:4]
        # Wave 1: 4 Bosses + 4 Bees (r3[0:4]) -> Top Left
        wave1 = bosses + bees_r3[0:4]
        # Wave 2: 8 Bees (r4[0:8]) -> Bottom Left
        wave2 = bees_r4[0:8]
        # Wave 3: 8 Butterflies (r1[4:8] + r2[4:8]) -> Bottom Right
        wave3 = butterflies_r1[4:8] + butterflies_r2[4:8]
        # Wave 4: 8 Bees (r3[4:10] + r4[8:10]) -> Top Right
        wave4 = bees_r3[4:10] + bees_r4[8:10]

        wave_specs = [
            (wave0, generate_entry_path_top_right, 0),
            (wave1, generate_entry_path_top_left, 60),
            (wave2, generate_entry_path_bottom_left, 120),
            (wave3, generate_entry_path_bottom_right, 180),
            (wave4, generate_entry_path_top_right, 240)
        ]

        for wave_enemies, path_gen, start_delay in wave_specs:
            for idx, e in enumerate(wave_enemies):
                delay = start_delay + idx * 7  # 7 frames between each enemy in the swoop
                path = path_gen((e.grid_x, e.grid_y), self.playfield_w, self.playfield_h)
                # Queued enemies stay outside the playfield until their entrance.
                e.x, e.y = -10.0, -10.0
                self.entry_queue.append((e, path, delay))

    def _setup_challenging_stage(self):
        """Challenging stage: enemies fly in 5 waves of 8 without grid docking."""
        self.enemies.clear()
        self.challenging_wave_idx = 0
        self.challenging_timer = 30  # Initial delay
        self._spawn_challenging_wave(0)

    def _spawn_challenging_wave(self, wave_idx: int):
        if wave_idx >= 5:
            self.challenging_finished = True
            return

        etype = EnemyType.BOSS if wave_idx == 2 else (EnemyType.BUTTERFLY if wave_idx % 2 == 1 else EnemyType.BEE)
        path = generate_challenging_wave_path(wave_idx, self.playfield_w, self.playfield_h)

        for i in range(8):
            e = Enemy(etype, 0, i, -10.0, -10.0)
            e.state = EnemyState.CHALLENGING_FLIGHT
            e.is_challenging = True
            e.path = path
            e.path_t = -i * 0.05  # Stagger along curve
            e.path_speed = 0.016 + (self.stage * 0.001)
            self.enemies.append(e)

    def update(self, player_x: float, has_dual_fighter: bool):
        """Update wave entry and enemy dives."""
        if self.is_challenging:
            self._update_challenging()
            return

        self.entry_tick += 1

        # Process entry queue
        for enemy, path, delay in self.entry_queue:
            if enemy.state == EnemyState.ENTERING and self.entry_tick >= delay and not enemy.path:
                enemy.start_path(path, speed=0.024, state=EnemyState.ENTERING)

        # Trigger dive-bombs from formation
        in_formation_enemies = [e for e in self.enemies if e.state == EnemyState.IN_FORMATION]
        if not in_formation_enemies:
            return

        self.dive_timer += 1
        if self.dive_timer >= self.dive_interval:
            self.dive_timer = 0
            self._trigger_enemy_dive(in_formation_enemies, player_x, has_dual_fighter)

    def _update_challenging(self):
        """Update challenging stage waves."""
        # Check if all enemies in current wave have exited or died
        wave_alive = [e for e in self.enemies if e.state == EnemyState.CHALLENGING_FLIGHT]
        if not wave_alive:
            self.challenging_timer += 1
            if self.challenging_timer >= 45:  # Pause between acrobatic waves
                self.challenging_timer = 0
                self.challenging_wave_idx += 1
                if self.challenging_wave_idx < 5:
                    self._spawn_challenging_wave(self.challenging_wave_idx)
                else:
                    self.challenging_finished = True

    def _trigger_enemy_dive(self, formation_enemies: List[Enemy], player_x: float, has_dual: bool):
        """Pick enemy or enemy formation to execute a dive bomb."""
        # 1. Can we do a Boss Tractor Beam run?
        bosses = [e for e in formation_enemies if e.enemy_type == EnemyType.BOSS and not e.has_captured_ship]
        if bosses and random.random() < 0.35:
            boss = random.choice(bosses)
            hover_y = random.uniform(9.0, 12.0)
            t_path = generate_tractor_dive_path((boss.x, boss.y), self.playfield_w, hover_y)
            boss.start_path(t_path, speed=0.026, state=EnemyState.TRACTOR_DESCENDING)
            return

        # 2. Boss with Escort run
        all_bosses = [e for e in formation_enemies if e.enemy_type == EnemyType.BOSS]
        butterflies = [e for e in formation_enemies if e.enemy_type == EnemyType.BUTTERFLY]
        if all_bosses and butterflies and random.random() < 0.40:
            boss = random.choice(all_bosses)
            escort_count = min(len(butterflies), random.choice([1, 2]))
            escorts = random.sample(butterflies, escort_count)

            boss_path = generate_dive_path((boss.x, boss.y), player_x, self.playfield_w, self.playfield_h)
            boss.start_path(boss_path, speed=0.025, state=EnemyState.DIVING)

            for idx, escort in enumerate(escorts):
                offset_x = -3.5 if idx == 0 else 3.5
                escort.is_escort = True
                escort.boss_leader = boss
                escort.escort_offset = (offset_x, 1.2)
                escort.state = EnemyState.DIVING
            return

        # 3. Solo Bee or Butterfly dive
        dive_candidates = [e for e in formation_enemies if e.enemy_type in (EnemyType.BEE, EnemyType.BUTTERFLY)]
        if dive_candidates:
            enemy = random.choice(dive_candidates)
            path = generate_dive_path((enemy.x, enemy.y), player_x, self.playfield_w, self.playfield_h)
            speed = 0.028 if enemy.enemy_type == EnemyType.BEE else 0.024
            enemy.start_path(path, speed=speed, state=EnemyState.DIVING)

    def is_cleared(self) -> bool:
        """Returns True when all enemies are destroyed or challenging stage is done."""
        if self.is_challenging:
            return self.challenging_finished
        return all(e.state == EnemyState.DEAD for e in self.enemies)
