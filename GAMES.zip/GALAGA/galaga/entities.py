"""Game entities: Player, Enemies, Projectiles, Tractor Beam, Particles."""

import math
import random
from enum import Enum, auto
from typing import List, Tuple, Optional
from .config import (
    PLAYFIELD_WIDTH, PLAYFIELD_HEIGHT, PLAYER_SPEED,
    PLAYER_MISSILE_SPEED, ENEMY_BULLET_SPEED_BASE,
    SCORE_BEE_FORMATION, SCORE_BEE_DIVING,
    SCORE_BUTTERFLY_FORMATION, SCORE_BUTTERFLY_DIVING,
    SCORE_BOSS_FORMATION, SCORE_BOSS_DIVING, SCORE_RESCUE_BONUS,
    TRACTOR_BEAM_HOLD_FRAMES, TRACTOR_BEAM_MAX_WIDTH
)
from .colors import (
    COLOR_PLAYER_WHITE, COLOR_PLAYER_RED, COLOR_PLAYER_CYAN,
    COLOR_PLAYER_MISSILE, COLOR_ENEMY_BULLET,
    COLOR_BEAM_CYAN, COLOR_BEAM_BLUE, COLOR_BEAM_WHITE,
    COLOR_EXP_YELLOW, COLOR_EXP_ORANGE, COLOR_BANNER, RESET
)
from .sprites import (
    PLAYER_SINGLE_FRAMES, PLAYER_DUAL_FRAMES,
    CAPTURED_SPIN_FRAMES, CAPTURED_DOCKED_FRAME,
    BOSS_HEALTHY_FRAMES, BOSS_DAMAGED_FRAMES,
    BUTTERFLY_FRAMES, BEE_FRAMES,
    EXP_SMALL_FRAMES, EXP_BIG_FRAMES
)
from .formations import (
    multi_segment_path, cubic_bezier,
    generate_dive_path, generate_tractor_dive_path
)


class PlayerState(Enum):
    ALIVE = auto()
    CAPTURED_BEAM = auto()  # Being pulled upward into tractor beam
    RESPAWNING = auto()     # Grace period respawning after loss
    DEAD = auto()           # Out of lives


class Player:
    def __init__(self, start_x: float = PLAYFIELD_WIDTH // 2 - 1, start_y: float = PLAYFIELD_HEIGHT - 3):
        self.x = float(start_x)
        self.y = float(start_y)
        self.is_dual = False
        self.lives = 3
        self.state = PlayerState.ALIVE
        self.respawn_timer = 0
        self.capture_t = 0.0
        self.capture_start_pos = (self.x, self.y)
        self.capture_target_pos = (self.x, self.y)
        self.capture_angle = 0
        self.score = 0
        self.shots_fired = 0
        self.hits = 0
        self.extra_lives_awarded = 0

    @property
    def width(self) -> int:
        return 7 if self.is_dual else 3

    @property
    def height(self) -> int:
        return 2

    def move(self, dx: float, min_x: float = 2.0, max_x: float = PLAYFIELD_WIDTH - 2.0):
        if self.state != PlayerState.ALIVE:
            return
        self.x = max(min_x, min(max_x - self.width, self.x + dx))

    def get_fire_positions(self) -> List[Tuple[float, float]]:
        """Return bullet spawn points based on single or dual fighter."""
        if not self.is_dual:
            return [(self.x + 1.0, self.y - 0.5)]
        else:
            return [(self.x + 1.0, self.y - 0.5), (self.x + 5.0, self.y - 0.5)]

    def hit(self, bullet_x: Optional[float] = None) -> bool:
        """
        Handle taking damage.
        If dual fighter: if hit on left/right side, downgrade to single fighter!
        Returns True if a life is lost, False if absorbed by dual split.
        """
        if self.state != PlayerState.ALIVE:
            return False

        if self.is_dual and bullet_x is not None:
            # Check which side was hit
            center = self.x + 3.5
            if bullet_x < center:
                # Left destroyed, shift right ship to be single fighter
                self.is_dual = False
                self.x = min(PLAYFIELD_WIDTH - 5.0, self.x + 4.0)
                return False
            else:
                # Right destroyed, keep left ship
                self.is_dual = False
                return False

        # Single ship hit or center hit
        self.lives -= 1
        self.is_dual = False
        if self.lives > 0:
            self.state = PlayerState.RESPAWNING
            self.respawn_timer = 45
            self.x = float(PLAYFIELD_WIDTH // 2 - 1)
        else:
            self.state = PlayerState.DEAD
        return True

    def update(self):
        if self.state == PlayerState.RESPAWNING:
            self.respawn_timer -= 1
            if self.respawn_timer <= 0:
                self.state = PlayerState.ALIVE
        elif self.state == PlayerState.CAPTURED_BEAM:
            self.capture_t += 0.03
            self.capture_angle = (self.capture_angle + 1) % 4
            self.x = (1.0 - self.capture_t) * self.capture_start_pos[0] + self.capture_t * self.capture_target_pos[0]
            self.y = (1.0 - self.capture_t) * self.capture_start_pos[1] + self.capture_t * self.capture_target_pos[1]

    def draw(self, buffer: List[List[Tuple[str, str]]]):
        if self.state == PlayerState.DEAD:
            return
        if self.state == PlayerState.RESPAWNING and (self.respawn_timer // 4) % 2 == 1:
            # Flicker during respawn grace
            return

        if self.state == PlayerState.CAPTURED_BEAM:
            frame = CAPTURED_SPIN_FRAMES[self.capture_angle]
        elif self.is_dual:
            frame = PLAYER_DUAL_FRAMES[0]
        else:
            frame = PLAYER_SINGLE_FRAMES[0]

        ix = int(round(self.x))
        iy = int(round(self.y))
        for r_idx, row in enumerate(frame):
            for c_idx, (ch, col) in enumerate(row):
                by = iy + r_idx
                bx = ix + c_idx
                if 0 <= by < len(buffer) and 0 <= bx < len(buffer[0]):
                    if ch != ' ':
                        buffer[by][bx] = (ch, col)


class Missile:
    """Player laser projectile."""
    def __init__(self, x: float, y: float, speed: float = PLAYER_MISSILE_SPEED):
        self.x = x
        self.y = y
        self.speed = speed
        self.active = True

    def update(self):
        self.y -= self.speed
        if self.y < 0:
            self.active = False

    def draw(self, buffer: List[List[Tuple[str, str]]]):
        ix = int(round(self.x))
        iy = int(round(self.y))
        if 0 <= iy < len(buffer) and 0 <= ix < len(buffer[0]):
            buffer[iy][ix] = ('|', COLOR_PLAYER_MISSILE)


class EnemyBullet:
    """Enemy plasma projectile."""
    def __init__(self, x: float, y: float, vx: float = 0.0, vy: float = ENEMY_BULLET_SPEED_BASE):
        self.x = x
        self.y = y
        self.vx = vx
        self.vy = vy
        self.active = True

    def update(self):
        self.x += self.vx
        self.y += self.vy
        if self.y >= PLAYFIELD_HEIGHT or self.x < 0 or self.x >= PLAYFIELD_WIDTH:
            self.active = False

    def draw(self, buffer: List[List[Tuple[str, str]]]):
        ix = int(round(self.x))
        iy = int(round(self.y))
        if 0 <= iy < len(buffer) and 0 <= ix < len(buffer[0]):
            buffer[iy][ix] = ('*', COLOR_ENEMY_BULLET)


class EnemyType(Enum):
    BOSS = auto()
    BUTTERFLY = auto()
    BEE = auto()


class EnemyState(Enum):
    ENTERING = auto()
    IN_FORMATION = auto()
    DIVING = auto()
    TRACTOR_DESCENDING = auto()
    TRACTOR_BEAM = auto()
    CAPTURING_PULL = auto()
    TRACTOR_ASCENDING = auto()
    RETURNING_TO_FORMATION = auto()
    CHALLENGING_FLIGHT = auto()
    DEAD = auto()


class Enemy:
    def __init__(self, enemy_type: EnemyType, grid_row: int, grid_col: int,
                 grid_x: float, grid_y: float):
        self.enemy_type = enemy_type
        self.grid_row = grid_row
        self.grid_col = grid_col
        self.grid_x = grid_x
        self.grid_y = grid_y

        self.x = grid_x
        self.y = grid_y
        self.max_hp = 2 if enemy_type == EnemyType.BOSS else 1
        self.hp = self.max_hp
        self.state = EnemyState.ENTERING

        self.path: List[Tuple[float, float]] = []
        self.path_t = 0.0
        self.path_speed = 0.02
        self.anim_tick = random.randint(0, 10)

        # Tractor beam & capture mechanics
        self.has_captured_ship = False
        self.tractor_timer = 0
        self.tractor_beam_width = 3.0
        self.is_flashing = 0

        # Escort connections
        self.escorts: List['Enemy'] = []
        self.is_escort = False
        self.boss_leader: Optional['Enemy'] = None
        self.escort_offset = (0.0, 0.0)

    @property
    def width(self) -> int:
        return 3

    @property
    def height(self) -> int:
        return 2

    def score_value(self) -> int:
        is_diving = self.state in (
            EnemyState.DIVING, EnemyState.TRACTOR_DESCENDING,
            EnemyState.TRACTOR_BEAM, EnemyState.CHALLENGING_FLIGHT
        )
        if self.enemy_type == EnemyType.BOSS:
            return SCORE_BOSS_DIVING if is_diving else SCORE_BOSS_FORMATION
        elif self.enemy_type == EnemyType.BUTTERFLY:
            return SCORE_BUTTERFLY_DIVING if is_diving else SCORE_BUTTERFLY_FORMATION
        else:
            return SCORE_BEE_DIVING if is_diving else SCORE_BEE_FORMATION

    def take_damage(self) -> bool:
        """Returns True if destroyed, False if damaged."""
        self.hp -= 1
        if self.hp <= 0:
            self.state = EnemyState.DEAD
            return True
        else:
            self.is_flashing = 12
            return False

    def start_path(self, path: List[Tuple[float, float]], speed: float = 0.02, state: EnemyState = EnemyState.DIVING):
        self.path = path
        self.path_t = 0.0
        self.path_speed = speed
        self.state = state

    def update(self, sway_x: float, pulse_y: float, player_x: float) -> Optional[EnemyBullet]:
        self.anim_tick += 1
        if self.is_flashing > 0:
            self.is_flashing -= 1

        bullet: Optional[EnemyBullet] = None

        if self.state == EnemyState.IN_FORMATION:
            self.x = self.grid_x + sway_x
            self.y = self.grid_y + pulse_y

        elif self.state in (EnemyState.ENTERING, EnemyState.DIVING, EnemyState.CHALLENGING_FLIGHT):
            if self.is_escort and self.boss_leader:
                if self.boss_leader.state == EnemyState.DIVING:
                    self.x = self.boss_leader.x + self.escort_offset[0]
                    self.y = self.boss_leader.y + self.escort_offset[1]
                else:
                    # The boss died or finished its dive; the escort must return.
                    self.is_escort = False
                    self.boss_leader = None
                    p_dock = (self.grid_x, self.grid_y)
                    self.start_path([
                        (self.x, self.y), (self.x, self.y - 4.0),
                        (p_dock[0], p_dock[1] - 4.0), p_dock
                    ], speed=0.035, state=EnemyState.RETURNING_TO_FORMATION)
            elif self.path:
                self.path_t += self.path_speed
                if self.path_t >= 1.0:
                    if self.state == EnemyState.ENTERING:
                        self.state = EnemyState.IN_FORMATION
                    elif self.state == EnemyState.CHALLENGING_FLIGHT:
                        self.state = EnemyState.DEAD  # Exited screen safely in bonus stage
                    elif self.state == EnemyState.DIVING:
                        # Exited bottom, start returning from top
                        p_top = (self.x, -2.0)
                        p_dock = (self.grid_x, self.grid_y)
                        return_path = [
                            p_top, (p_top[0], 5.0),
                            (p_dock[0], p_dock[1] - 4.0), p_dock
                        ]
                        self.start_path(return_path, speed=0.035, state=EnemyState.RETURNING_TO_FORMATION)
                else:
                    self.x, self.y = multi_segment_path(self.path, self.path_t)

                # Opportunity to shoot during dive
                if self.state == EnemyState.DIVING and 0.25 < self.path_t < 0.65 and random.random() < 0.035:
                    # Shoot bullet toward player
                    dx = (player_x - self.x)
                    dy = (PLAYFIELD_HEIGHT - self.y)
                    dist = max(1.0, math.hypot(dx, dy))
                    speed = ENEMY_BULLET_SPEED_BASE
                    bullet = EnemyBullet(self.x + 1.0, self.y + 2.0, vx=(dx / dist) * speed * 0.5, vy=(dy / dist) * speed)

        elif self.state == EnemyState.RETURNING_TO_FORMATION:
            if self.path:
                self.path_t += self.path_speed
                if self.path_t >= 1.0:
                    self.state = EnemyState.IN_FORMATION
                else:
                    self.x, self.y = multi_segment_path(self.path, self.path_t)

        elif self.state == EnemyState.TRACTOR_DESCENDING:
            if self.path:
                self.path_t += self.path_speed
                if self.path_t >= 1.0:
                    self.state = EnemyState.TRACTOR_BEAM
                    self.tractor_timer = TRACTOR_BEAM_HOLD_FRAMES
                    self.tractor_beam_width = 3.0
                else:
                    self.x, self.y = multi_segment_path(self.path, self.path_t)

        elif self.state == EnemyState.TRACTOR_BEAM:
            self.tractor_timer -= 1
            if self.tractor_beam_width < TRACTOR_BEAM_MAX_WIDTH:
                self.tractor_beam_width += 0.35
            if self.tractor_timer <= 0:
                # Finished beam without capture, ascend back
                p_cur = (self.x, self.y)
                p_dock = (self.grid_x, self.grid_y)
                ascend_path = [p_cur, (p_cur[0] + 8.0, p_cur[1] - 4.0), (p_dock[0], p_dock[1] - 3.0), p_dock]
                self.start_path(ascend_path, speed=0.03, state=EnemyState.RETURNING_TO_FORMATION)

        elif self.state == EnemyState.TRACTOR_ASCENDING:
            if self.path:
                self.path_t += self.path_speed
                if self.path_t >= 1.0:
                    self.state = EnemyState.IN_FORMATION
                else:
                    self.x, self.y = multi_segment_path(self.path, self.path_t)

        return bullet

    def draw(self, buffer: List[List[Tuple[str, str]]]):
        if self.state == EnemyState.DEAD:
            return

        frame_idx = (self.anim_tick // 8) % 2

        if self.enemy_type == EnemyType.BOSS:
            if self.hp < self.max_hp or self.is_flashing > 0:
                frames = BOSS_DAMAGED_FRAMES
            else:
                frames = BOSS_HEALTHY_FRAMES
        elif self.enemy_type == EnemyType.BUTTERFLY:
            frames = BUTTERFLY_FRAMES
        else:
            frames = BEE_FRAMES

        frame = frames[frame_idx]
        ix = int(round(self.x))
        iy = int(round(self.y))

        # If Boss has captured fighter, draw captive docked above it!
        if self.has_captured_ship and self.enemy_type == EnemyType.BOSS:
            dock_y = iy - 2
            dock_x = ix
            for r_idx, row in enumerate(CAPTURED_DOCKED_FRAME):
                for c_idx, (ch, col) in enumerate(row):
                    by = dock_y + r_idx
                    bx = dock_x + c_idx
                    if 0 <= by < len(buffer) and 0 <= bx < len(buffer[0]):
                        if ch != ' ':
                            buffer[by][bx] = (ch, col)

        for r_idx, row in enumerate(frame):
            for c_idx, (ch, col) in enumerate(row):
                by = iy + r_idx
                bx = ix + c_idx
                if 0 <= by < len(buffer) and 0 <= bx < len(buffer[0]):
                    if ch != ' ':
                        buffer[by][bx] = (ch, col)


class TractorBeam:
    """Pulsing downward energy tractor beam emitted by Boss Galaga."""
    def __init__(self, boss: Enemy):
        self.boss = boss
        self.cycle = 0

    def get_beam_bounds(self) -> List[Tuple[int, int, int]]:
        """Return list of (row_y, left_x, right_x) for each beam level."""
        rows = []
        top_y = int(round(self.boss.y + 2))
        max_bottom_y = PLAYFIELD_HEIGHT - 2
        beam_w = self.boss.tractor_beam_width
        center_x = self.boss.x + 1.5

        for y in range(top_y, max_bottom_y):
            progress = (y - top_y) / max(1.0, (max_bottom_y - top_y))
            curr_half_w = 1.0 + (beam_w / 2.0) * progress
            lx = int(round(center_x - curr_half_w))
            rx = int(round(center_x + curr_half_w))
            rows.append((y, lx, rx))
        return rows

    def check_capture(self, player: Player) -> bool:
        """Check if player's fighter is inside the active tractor beam cone."""
        if self.boss.state != EnemyState.TRACTOR_BEAM:
            return False
        bounds = self.get_beam_bounds()
        py = int(round(player.y))
        for y, lx, rx in bounds:
            if abs(y - py) <= 1:
                # Player overlaps beam horizontally
                if lx <= player.x + (player.width / 2.0) <= rx:
                    return True
        return False

    def draw(self, buffer: List[List[Tuple[str, str]]]):
        if self.boss.state != EnemyState.TRACTOR_BEAM:
            return

        self.cycle = (self.cycle + 1) % 4
        shimmer_chars = ['~', '≈', '·', '*', '=']
        bounds = self.get_beam_bounds()

        for idx, (y, lx, rx) in enumerate(bounds):
            if not (0 <= y < len(buffer)):
                continue

            color = COLOR_BEAM_CYAN if (idx + self.cycle) % 2 == 0 else COLOR_BEAM_BLUE
            # Draw left boundary beam
            if 0 <= lx < len(buffer[0]):
                buffer[y][lx] = ('\\', COLOR_BEAM_WHITE)
            # Draw right boundary beam
            if 0 <= rx < len(buffer[0]):
                buffer[y][rx] = ('/', COLOR_BEAM_WHITE)

            # Draw interior shimmer
            step = 3
            for x in range(lx + 1, rx, step):
                if 0 <= x < len(buffer[0]):
                    ch = shimmer_chars[(x + idx + self.cycle) % len(shimmer_chars)]
                    buffer[y][x] = (ch, color)


class Explosion:
    """Multi-frame particle explosion effect."""
    def __init__(self, x: float, y: float, is_big: bool = False):
        self.x = x
        self.y = y
        self.frames = EXP_BIG_FRAMES if is_big else EXP_SMALL_FRAMES
        self.frame_idx = 0.0
        self.anim_speed = 0.28
        self.active = True

    def update(self):
        self.frame_idx += self.anim_speed
        if self.frame_idx >= len(self.frames):
            self.active = False

    def draw(self, buffer: List[List[Tuple[str, str]]]):
        if not self.active:
            return
        idx = min(len(self.frames) - 1, int(self.frame_idx))
        frame = self.frames[idx]
        ix = int(round(self.x))
        iy = int(round(self.y))

        for r_idx, row in enumerate(frame):
            for c_idx, (ch, col) in enumerate(row):
                by = iy + r_idx
                bx = ix + c_idx
                if 0 <= by < len(buffer) and 0 <= bx < len(buffer[0]):
                    if ch != ' ':
                        buffer[by][bx] = (ch, col)


class ScorePopup:
    """Floating score / text banner."""
    def __init__(self, x: float, y: float, text: str, color: str = COLOR_EXP_YELLOW, lifespan: int = 24):
        self.x = x
        self.y = y
        self.text = text
        self.color = color
        self.lifespan = lifespan
        self.active = True

    def update(self):
        self.y -= 0.08
        self.lifespan -= 1
        if self.lifespan <= 0:
            self.active = False

    def draw(self, buffer: List[List[Tuple[str, str]]]):
        if not self.active:
            return
        ix = int(round(self.x))
        iy = int(round(self.y))
        if 0 <= iy < len(buffer):
            for c_idx, ch in enumerate(self.text):
                bx = ix + c_idx
                if 0 <= bx < len(buffer[0]):
                    buffer[iy][bx] = (ch, self.color)


class RescuedShip:
    """Captured fighter floating downward to link up as Dual Fighter!"""
    def __init__(self, x: float, y: float):
        self.x = x
        self.y = y
        self.speed = 0.35
        self.active = True
        self.anim_tick = 0

    def update(self, player_y: float) -> bool:
        """Returns True when reached player to trigger Dual Fighter docking!"""
        self.anim_tick += 1
        self.y += self.speed
        if self.y >= player_y:
            self.active = False
            return True
        return False

    def draw(self, buffer: List[List[Tuple[str, str]]]):
        if not self.active:
            return
        ix = int(round(self.x))
        iy = int(round(self.y))
        frame = PLAYER_SINGLE_FRAMES[0]
        for r_idx, row in enumerate(frame):
            for c_idx, (ch, col) in enumerate(row):
                by = iy + r_idx
                bx = ix + c_idx
                if 0 <= by < len(buffer) and 0 <= bx < len(buffer[0]):
                    if ch != ' ':
                        # Rescued ship flashes celebratory cyan/white
                        col = COLOR_PLAYER_CYAN if (self.anim_tick // 4) % 2 == 0 else COLOR_PLAYER_WHITE
                        buffer[by][bx] = (ch, col)
