"""ASCII sprite frames, dimensions, and color mappings for Galaga."""

from typing import List, Tuple
from .colors import (
    COLOR_PLAYER_WHITE, COLOR_PLAYER_RED, COLOR_PLAYER_CYAN,
    COLOR_BOSS_GREEN, COLOR_BOSS_YELLOW, COLOR_BOSS_DAMAGED,
    COLOR_BUTTERFLY_RED, COLOR_BUTTERFLY_AMBER,
    COLOR_BEE_CYAN, COLOR_BEE_YELLOW,
    COLOR_EXP_WHITE, COLOR_EXP_YELLOW, COLOR_EXP_ORANGE, COLOR_EXP_RED,
    RESET
)

# Sprite structure: List of lines, each line is List of (char, color)

def make_colored_sprite(lines: List[str], color_map: dict) -> List[List[Tuple[str, str]]]:
    """Helper to convert ASCII text and character color map into colored sprite cells."""
    result = []
    for line in lines:
        row = []
        for ch in line:
            color = color_map.get(ch, None)
            row.append((ch, color))
        result.append(row)
    return result


# Player Fighter (Single)
PLAYER_SINGLE_FRAMES = [
    [
        [(' ', None), ('^', COLOR_PLAYER_WHITE), (' ', None)],
        [('/', COLOR_PLAYER_RED), ('█', COLOR_PLAYER_WHITE), ('\\', COLOR_PLAYER_RED)]
    ]
]

# Player Fighter (Dual)
PLAYER_DUAL_FRAMES = [
    [
        [(' ', None), ('^', COLOR_PLAYER_WHITE), (' ', None), (' ', None), (' ', None), ('^', COLOR_PLAYER_WHITE), (' ', None)],
        [('/', COLOR_PLAYER_RED), ('█', COLOR_PLAYER_RED), ('\\', COLOR_PLAYER_WHITE), ('=', COLOR_PLAYER_CYAN), ('/', COLOR_PLAYER_WHITE), ('█', COLOR_PLAYER_RED), ('\\', COLOR_PLAYER_RED)]
    ]
]

# Captured Fighter Spinning (during tractor beam pull)
CAPTURED_SPIN_FRAMES = [
    [  # 0 deg
        [(' ', None), ('^', COLOR_PLAYER_CYAN), (' ', None)],
        [('/', COLOR_PLAYER_RED), ('█', COLOR_PLAYER_CYAN), ('\\', COLOR_PLAYER_RED)]
    ],
    [  # 90 deg
        [(' ', None), ('>', COLOR_PLAYER_CYAN), (' ', None)],
        [('-', COLOR_PLAYER_RED), ('█', COLOR_PLAYER_CYAN), ('>', COLOR_PLAYER_RED)]
    ],
    [  # 180 deg
        [('\\', COLOR_PLAYER_RED), ('█', COLOR_PLAYER_CYAN), ('/', COLOR_PLAYER_RED)],
        [(' ', None), ('v', COLOR_PLAYER_CYAN), (' ', None)]
    ],
    [  # 270 deg
        [(' ', None), ('<', COLOR_PLAYER_CYAN), (' ', None)],
        [('<', COLOR_PLAYER_RED), ('█', COLOR_PLAYER_CYAN), ('-', COLOR_PLAYER_RED)]
    ]
]

# Captured Fighter Docked atop Boss
CAPTURED_DOCKED_FRAME = [
    [(' ', None), ('v', COLOR_PLAYER_CYAN), (' ', None)],
    [('\\', COLOR_PLAYER_RED), ('█', COLOR_PLAYER_CYAN), ('/', COLOR_PLAYER_RED)]
]

# Boss Galaga (Green / Healthy)
BOSS_HEALTHY_FRAMES = [
    [
        [('(', COLOR_BOSS_GREEN), ('O', COLOR_BOSS_YELLOW), (')', COLOR_BOSS_GREEN)],
        [('/', COLOR_BOSS_GREEN), ('W', COLOR_BOSS_YELLOW), ('\\', COLOR_BOSS_GREEN)]
    ],
    [
        [('<', COLOR_BOSS_GREEN), ('O', COLOR_BOSS_YELLOW), ('>', COLOR_BOSS_GREEN)],
        [('\\', COLOR_BOSS_GREEN), ('M', COLOR_BOSS_YELLOW), ('/', COLOR_BOSS_GREEN)]
    ]
]

# Boss Galaga (Damaged / Flashing Blue)
BOSS_DAMAGED_FRAMES = [
    [
        [('(', COLOR_BOSS_DAMAGED), ('O', COLOR_PLAYER_CYAN), (')', COLOR_BOSS_DAMAGED)],
        [('/', COLOR_BOSS_DAMAGED), ('W', COLOR_PLAYER_CYAN), ('\\', COLOR_BOSS_DAMAGED)]
    ],
    [
        [('<', COLOR_BOSS_DAMAGED), ('O', COLOR_PLAYER_CYAN), ('>', COLOR_BOSS_DAMAGED)],
        [('\\', COLOR_BOSS_DAMAGED), ('M', COLOR_PLAYER_CYAN), ('/', COLOR_BOSS_DAMAGED)]
    ]
]

# Red Butterfly (Goei)
BUTTERFLY_FRAMES = [
    [
        [('\\', COLOR_BUTTERFLY_RED), ('w', COLOR_BUTTERFLY_AMBER), ('/', COLOR_BUTTERFLY_RED)],
        [(' ', None), ('V', COLOR_BUTTERFLY_RED), (' ', None)]
    ],
    [
        [('/', COLOR_BUTTERFLY_RED), ('w', COLOR_BUTTERFLY_AMBER), ('\\', COLOR_BUTTERFLY_RED)],
        [(' ', None), ('v', COLOR_BUTTERFLY_RED), (' ', None)]
    ]
]

# Blue Bee (Zako)
BEE_FRAMES = [
    [
        [('/', COLOR_BEE_CYAN), ('o', COLOR_BEE_YELLOW), ('\\', COLOR_BEE_CYAN)],
        [(' ', None), ('v', COLOR_BEE_YELLOW), (' ', None)]
    ],
    [
        [('|', COLOR_BEE_CYAN), ('o', COLOR_BEE_YELLOW), ('|', COLOR_BEE_CYAN)],
        [(' ', None), ('V', COLOR_BEE_YELLOW), (' ', None)]
    ]
]

# Small Explosion (Bees & Butterflies)
EXP_SMALL_FRAMES = [
    [
        [('\\', COLOR_EXP_WHITE), (' ', None), ('/', COLOR_EXP_WHITE)],
        [(' ', None), ('*', COLOR_EXP_YELLOW), (' ', None)],
        [('/', COLOR_EXP_WHITE), (' ', None), ('\\', COLOR_EXP_WHITE)]
    ],
    [
        [('.', COLOR_EXP_YELLOW), (' ', None), ('.', COLOR_EXP_YELLOW)],
        [(' ', None), ('#', COLOR_EXP_ORANGE), (' ', None)],
        [('.', COLOR_EXP_YELLOW), (' ', None), ('.', COLOR_EXP_YELLOW)]
    ],
    [
        [(' ', None), ('.', COLOR_EXP_RED), (' ', None)],
        [('.', COLOR_EXP_RED), (' ', None), ('.', COLOR_EXP_RED)],
        [(' ', None), ('.', COLOR_EXP_RED), (' ', None)]
    ]
]

# Big Explosion (Boss Galaga & Player)
EXP_BIG_FRAMES = [
    [
        [('\\', COLOR_EXP_WHITE), ('|', COLOR_EXP_WHITE), ('/', COLOR_EXP_WHITE)],
        [('*', COLOR_EXP_YELLOW), ('#', COLOR_EXP_WHITE), ('*', COLOR_EXP_YELLOW)],
        [('/', COLOR_EXP_WHITE), ('|', COLOR_EXP_WHITE), ('\\', COLOR_EXP_WHITE)]
    ],
    [
        [('.', COLOR_EXP_YELLOW), ('*', COLOR_EXP_ORANGE), ('.', COLOR_EXP_YELLOW)],
        [('*', COLOR_EXP_ORANGE), ('#', COLOR_EXP_RED), ('*', COLOR_EXP_ORANGE)],
        [('.', COLOR_EXP_YELLOW), ('*', COLOR_EXP_ORANGE), ('.', COLOR_EXP_YELLOW)]
    ],
    [
        [('\\', COLOR_EXP_ORANGE), (' ', None), ('/', COLOR_EXP_ORANGE)],
        [(' ', None), ('.', COLOR_EXP_RED), (' ', None)],
        [('/', COLOR_EXP_ORANGE), (' ', None), ('\\', COLOR_EXP_ORANGE)]
    ],
    [
        [('·', COLOR_EXP_RED), (' ', None), ('·', COLOR_EXP_RED)],
        [(' ', None), ('·', COLOR_EXP_RED), (' ', None)],
        [('·', COLOR_EXP_RED), (' ', None), ('·', COLOR_EXP_RED)]
    ]
]
