"""Galaga Terminal Arcade Game."""

__version__ = "1.0.0"
