"""Flight paths, Bezier curves, and formation grid geometry."""

import math
from typing import List, Tuple, Optional


def cubic_bezier(p0: Tuple[float, float], p1: Tuple[float, float],
                 p2: Tuple[float, float], p3: Tuple[float, float], t: float) -> Tuple[float, float]:
    """Calculate point along cubic Bezier curve at parametric time t in [0, 1]."""
    t = max(0.0, min(1.0, t))
    u = 1.0 - t
    tt = t * t
    uu = u * u
    uuu = uu * u
    ttt = tt * t

    x = uuu * p0[0] + 3 * uu * t * p1[0] + 3 * u * tt * p2[0] + ttt * p3[0]
    y = uuu * p0[1] + 3 * uu * t * p1[1] + 3 * u * tt * p2[1] + ttt * p3[1]
    return (x, y)


def multi_segment_path(points: List[Tuple[float, float]], t: float) -> Tuple[float, float]:
    """
    Interpolate along multiple cubic Bezier segments.
    Points length must be 3*N + 1 (e.g. 4 points for 1 segment, 7 points for 2 segments).
    """
    if len(points) < 4:
        return points[0] if points else (0.0, 0.0)

    num_segments = (len(points) - 1) // 3
    t = max(0.0, min(0.999999, t))
    seg_idx = int(t * num_segments)
    seg_t = (t * num_segments) - seg_idx

    p0 = points[seg_idx * 3]
    p1 = points[seg_idx * 3 + 1]
    p2 = points[seg_idx * 3 + 2]
    p3 = points[seg_idx * 3 + 3]
    return cubic_bezier(p0, p1, p2, p3, seg_t)


# Flight Path Generators for Galaga Waves

def generate_entry_path_top_right(target: Tuple[float, float], playfield_w: int, playfield_h: int) -> List[Tuple[float, float]]:
    """Enters from top-right, dives toward lower-left, loops up to target slot."""
    p0 = (playfield_w - 4.0, -2.0)
    p1 = (playfield_w - 10.0, playfield_h * 0.45)
    p2 = (8.0, playfield_h * 0.70)
    p3 = (playfield_w * 0.35, playfield_h * 0.85)

    p4 = (playfield_w * 0.65, playfield_h * 0.60)
    p5 = (target[0] + 10.0, target[1] + 6.0)
    p6 = target

    return [p0, p1, p2, p3, p4, p5, p6]


def generate_entry_path_top_left(target: Tuple[float, float], playfield_w: int, playfield_h: int) -> List[Tuple[float, float]]:
    """Enters from top-left, dives toward lower-right, loops up to target slot."""
    p0 = (4.0, -2.0)
    p1 = (10.0, playfield_h * 0.45)
    p2 = (playfield_w - 8.0, playfield_h * 0.70)
    p3 = (playfield_w * 0.65, playfield_h * 0.85)

    p4 = (playfield_w * 0.35, playfield_h * 0.60)
    p5 = (target[0] - 10.0, target[1] + 6.0)
    p6 = target

    return [p0, p1, p2, p3, p4, p5, p6]


def generate_entry_path_bottom_left(target: Tuple[float, float], playfield_w: int, playfield_h: int) -> List[Tuple[float, float]]:
    """Enters from mid-left, sweeps across bottom, loops up into formation."""
    p0 = (-2.0, playfield_h * 0.65)
    p1 = (playfield_w * 0.4, playfield_h * 0.85)
    p2 = (playfield_w - 6.0, playfield_h * 0.60)
    p3 = (playfield_w * 0.6, playfield_h * 0.35)

    p4 = (playfield_w * 0.2, playfield_h * 0.30)
    p5 = (target[0] - 5.0, target[1] + 4.0)
    p6 = target

    return [p0, p1, p2, p3, p4, p5, p6]


def generate_entry_path_bottom_right(target: Tuple[float, float], playfield_w: int, playfield_h: int) -> List[Tuple[float, float]]:
    """Enters from mid-right, sweeps across bottom, loops up into formation."""
    p0 = (playfield_w + 2.0, playfield_h * 0.65)
    p1 = (playfield_w * 0.6, playfield_h * 0.85)
    p2 = (6.0, playfield_h * 0.60)
    p3 = (playfield_w * 0.4, playfield_h * 0.35)

    p4 = (playfield_w * 0.8, playfield_h * 0.30)
    p5 = (target[0] + 5.0, target[1] + 4.0)
    p6 = target

    return [p0, p1, p2, p3, p4, p5, p6]


def generate_dive_path(start: Tuple[float, float], player_x: float, playfield_w: int, playfield_h: int) -> List[Tuple[float, float]]:
    """Dive-bomb path: breaks away, loops down towards player, exits bottom to re-enter top."""
    # Breakaway direction based on screen side
    side_dir = 1.0 if start[0] < playfield_w / 2.0 else -1.0
    
    p0 = start
    p1 = (start[0] + side_dir * 10.0, start[1] - 3.0)  # brief upward loop
    p2 = (start[0] + side_dir * 18.0, start[1] + 6.0)
    p3 = (player_x, playfield_h * 0.55)               # aim at player

    # Sweep across lower playfield and exit bottom
    target_exit_x = player_x + side_dir * 12.0
    p4 = (player_x - side_dir * 8.0, playfield_h * 0.85)
    p5 = (target_exit_x, playfield_h + 1.0)
    p6 = (target_exit_x, playfield_h + 4.0)

    return [p0, p1, p2, p3, p4, p5, p6]


def generate_tractor_dive_path(start: Tuple[float, float], playfield_w: int, hover_y: float = 10.0) -> List[Tuple[float, float]]:
    """Boss Galaga path down to tractor beam hovering position."""
    center_x = playfield_w / 2.0
    p0 = start
    p1 = (start[0] + (center_x - start[0]) * 0.5, start[1] + 3.0)
    p2 = (center_x + (5.0 if start[0] < center_x else -5.0), hover_y - 2.0)
    p3 = (center_x, hover_y)
    return [p0, p1, p2, p3]


# Challenging Stage Acrobatic Curves
def generate_challenging_wave_path(wave_idx: int, playfield_w: int, playfield_h: int) -> List[Tuple[float, float]]:
    """5 distinctive acrobatic display curves for bonus stage waves."""
    mid_x = playfield_w / 2.0

    if wave_idx == 0:
        # Figure 8 entrance from top left
        return [
            (2.0, -2.0), (10.0, playfield_h * 0.4), (mid_x + 12.0, playfield_h * 0.6), (mid_x, playfield_h * 0.8),
            (mid_x - 12.0, playfield_h * 0.6), (playfield_w - 6.0, playfield_h * 0.3), (playfield_w + 4.0, -2.0)
        ]
    elif wave_idx == 1:
        # High loop from top right
        return [
            (playfield_w - 2.0, -2.0), (playfield_w - 12.0, playfield_h * 0.5), (mid_x - 10.0, playfield_h * 0.65), (10.0, playfield_h * 0.75),
            (6.0, playfield_h * 0.35), (mid_x, playfield_h * 0.2), (-4.0, playfield_h * 0.1)
        ]
    elif wave_idx == 2:
        # Deep swoop down center then outward climb
        return [
            (mid_x - 8.0, -2.0), (mid_x - 15.0, playfield_h * 0.4), (mid_x, playfield_h * 0.85), (mid_x + 15.0, playfield_h * 0.6),
            (playfield_w - 5.0, playfield_h * 0.3), (mid_x, -4.0), (-4.0, -4.0)
        ]
    elif wave_idx == 3:
        # Spiral circular sweep
        return [
            (-2.0, playfield_h * 0.4), (mid_x, playfield_h * 0.2), (playfield_w - 4.0, playfield_h * 0.5), (mid_x, playfield_h * 0.8),
            (6.0, playfield_h * 0.6), (mid_x, playfield_h * 0.4), (playfield_w + 4.0, playfield_h * 0.3)
        ]
    else:
        # Double wave snake across bottom
        return [
            (playfield_w + 2.0, playfield_h * 0.2), (mid_x, playfield_h * 0.5), (6.0, playfield_h * 0.7), (mid_x, playfield_h * 0.85),
            (playfield_w - 8.0, playfield_h * 0.65), (mid_x, playfield_h * 0.35), (-4.0, playfield_h * 0.2)
        ]
