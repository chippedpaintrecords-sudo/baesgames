"""Central Galaga Game Engine with authentic arcade state machine."""

import time
import math
import random
from enum import Enum, auto
from typing import List, Optional

from .config import (
    FPS, PLAYFIELD_WIDTH, PLAYFIELD_HEIGHT,
    PLAYER_SPEED, PLAYER_MAX_MISSILES_SINGLE, PLAYER_MAX_MISSILES_DUAL,
    SCORE_RESCUE_BONUS, SCORE_CHALLENGING_HIT, SCORE_CHALLENGING_PERFECT,
    EXTRA_LIFE_FIRST, EXTRA_LIFE_INTERVAL
)
from .colors import (
    COLOR_BANNER, COLOR_HUD_LABEL, COLOR_HUD_VAL, COLOR_HUD_STAGE,
    COLOR_PLAYER_WHITE, COLOR_PLAYER_CYAN, COLOR_PLAYER_RED,
    COLOR_BOSS_GREEN, COLOR_BUTTERFLY_RED, COLOR_BEE_CYAN,
    COLOR_EXP_YELLOW, COLOR_EXP_ORANGE, COLOR_GRAY, RESET, BOLD
)
from .sound import sound_engine
from .input_handler import InputHandler, Action
from .renderer import Renderer
from .starfield import Starfield
from .entities import (
    Player, PlayerState, Missile, EnemyBullet,
    Enemy, EnemyType, EnemyState,
    TractorBeam, Explosion, ScorePopup, RescuedShip
)
from .waves import WaveManager
from .highscores import (
    load_highscores, save_highscores,
    get_top_score, is_high_score, add_high_score
)


class GameState(Enum):
    TITLE = auto()
    STAGE_INTRO = auto()
    PLAYING = auto()
    CAPTURING = auto()
    STAGE_CLEAR = auto()
    CHALLENGING_RESULTS = auto()
    PAUSED = auto()
    GAME_OVER = auto()


class GalagaGame:
    """Core game engine managing state transitions, entities, and arcade physics."""

    def __init__(self, fps: int = FPS):
        if fps <= 0:
            raise ValueError("fps must be positive")
        self.frame_time = 1.0 / fps
        self.renderer = Renderer(PLAYFIELD_WIDTH, PLAYFIELD_HEIGHT)
        self.inputs = InputHandler()
        self.starfield = Starfield(PLAYFIELD_WIDTH, PLAYFIELD_HEIGHT)
        self.wave_mgr = WaveManager(PLAYFIELD_WIDTH, PLAYFIELD_HEIGHT)

        self.state = GameState.TITLE
        self.running = True
        self.tick_counter = 0

        # Entities
        self.player = Player()
        self.missiles: List[Missile] = []
        self.enemy_bullets: List[EnemyBullet] = []
        self.explosions: List[Explosion] = []
        self.score_popups: List[ScorePopup] = []
        self.rescued_ships: List[RescuedShip] = []
        self.active_tractor_beam: Optional[TractorBeam] = None

        # State Timers
        self.state_timer = 0
        self.stage = 1
        self.high_score = get_top_score()
        self.all_highscores = load_highscores()
        self.extra_life_target = EXTRA_LIFE_FIRST

        # Results tracking
        self.banner_text: Optional[str] = None
        self.results_timer = 0

    def start_new_game(self):
        """Reset player and start stage 1."""
        self.player = Player()
        self.stage = 1
        self.extra_life_target = EXTRA_LIFE_FIRST
        self.missiles.clear()
        self.enemy_bullets.clear()
        self.explosions.clear()
        self.score_popups.clear()
        self.rescued_ships.clear()
        self.active_tractor_beam = None

        self._start_stage(1)

    def _start_stage(self, stage: int):
        self.stage = stage
        self.missiles.clear()
        self.enemy_bullets.clear()
        self.active_tractor_beam = None
        self.rescued_ships.clear()

        self.wave_mgr.setup_stage(stage)
        self.state = GameState.STAGE_INTRO
        self.state_timer = 65  # approx 1.8 seconds intro
        self.starfield.set_warp(True)

        if self.wave_mgr.is_challenging:
            sound_engine.play_challenging_stage()
        else:
            sound_engine.play_stage_start()

    def handle_input(self, actions: set):
        """Dispatch user input actions."""
        if Action.QUIT in actions:
            if self.state == GameState.TITLE:
                self.running = False
            else:
                self.state = GameState.TITLE
            return

        if Action.MUTE in actions:
            sound_engine.toggle_mute()

        if self.state == GameState.TITLE:
            if Action.START in actions or Action.FIRE in actions or Action.ANY_KEY in actions:
                self.start_new_game()

        elif self.state == GameState.PLAYING:
            if Action.PAUSE in actions:
                self.state = GameState.PAUSED
                return

            # Player horizontal movement
            if Action.LEFT in actions:
                self.player.move(-PLAYER_SPEED)
            if Action.RIGHT in actions:
                self.player.move(PLAYER_SPEED)

            # Player firing
            if Action.FIRE in actions:
                max_missiles = PLAYER_MAX_MISSILES_DUAL if self.player.is_dual else PLAYER_MAX_MISSILES_SINGLE
                if self.player.state == PlayerState.ALIVE:
                    spawn_points = self.player.get_fire_positions()
                    if sum(m.active for m in self.missiles) + len(spawn_points) <= max_missiles:
                        for sp_x, sp_y in spawn_points:
                            self.missiles.append(Missile(sp_x, sp_y))
                            self.player.shots_fired += 1
                        sound_engine.play_shoot()

        elif self.state == GameState.PAUSED:
            if Action.PAUSE in actions or Action.START in actions:
                self.state = GameState.PLAYING

        elif self.state == GameState.GAME_OVER:
            if self.state_timer <= 0 and (Action.START in actions or Action.FIRE in actions or Action.ANY_KEY in actions):
                self.state = GameState.TITLE

    def update(self):
        """Update game physics and state logic."""
        self.tick_counter += 1
        self.starfield.update()

        # Update high score display
        if self.player.score > self.high_score:
            self.high_score = self.player.score

        # Check for extra life award
        while self.player.score >= self.extra_life_target:
            self.player.lives += 1
            sound_engine.play_bonus()
            self.score_popups.append(ScorePopup(self.player.x, self.player.y - 2, "1UP EXTRA SHIP!", COLOR_BANNER, 40))
            self.extra_life_target += EXTRA_LIFE_INTERVAL

        # State updates
        if self.state == GameState.TITLE:
            pass

        elif self.state == GameState.STAGE_INTRO:
            self.state_timer -= 1
            if self.state_timer <= 0:
                self.starfield.set_warp(False)
                self.state = GameState.PLAYING

        elif self.state == GameState.PLAYING:
            self._update_playing()

        elif self.state == GameState.CAPTURING:
            self._update_capturing()

        elif self.state == GameState.STAGE_CLEAR:
            self.state_timer -= 1
            if self.state_timer <= 0:
                self._start_stage(self.stage + 1)

        elif self.state == GameState.CHALLENGING_RESULTS:
            self.state_timer -= 1
            if self.state_timer <= 0:
                self._start_stage(self.stage + 1)

        elif self.state == GameState.GAME_OVER:
            if self.state_timer > 0:
                self.state_timer -= 1

    def _update_playing(self):
        # 1. Update Player
        self.player.update()

        # 2. Formation sway calculations
        sway_x = math.sin(self.tick_counter * 0.04) * 3.5
        pulse_y = math.sin(self.tick_counter * 0.08) * 0.35

        # 3. Wave manager
        self.wave_mgr.update(self.player.x, self.player.is_dual)

        # 4. Update Enemies
        for enemy in self.wave_mgr.enemies:
            if enemy.state == EnemyState.DEAD:
                continue

            bullet = enemy.update(sway_x, pulse_y, self.player.x)
            if bullet is not None and not self.wave_mgr.is_challenging:
                self.enemy_bullets.append(bullet)

            # Check if this enemy is firing tractor beam
            if enemy.state == EnemyState.TRACTOR_BEAM:
                if self.active_tractor_beam is None or self.active_tractor_beam.boss != enemy:
                    self.active_tractor_beam = TractorBeam(enemy)
                    sound_engine.play_tractor()
            elif enemy.state in (EnemyState.RETURNING_TO_FORMATION, EnemyState.DEAD):
                if self.active_tractor_beam and self.active_tractor_beam.boss == enemy:
                    self.active_tractor_beam = None

        # Check tractor beam capture of player
        if self.active_tractor_beam and self.player.state == PlayerState.ALIVE:
            if self.active_tractor_beam.check_capture(self.player):
                # Player captured!
                self._trigger_player_capture(self.active_tractor_beam.boss)

        # 5. Update Missiles
        for missile in self.missiles:
            missile.update()
        self.missiles = [m for m in self.missiles if m.active]

        # 6. Update Enemy Bullets
        for bullet in self.enemy_bullets:
            bullet.update()
        self.enemy_bullets = [b for b in self.enemy_bullets if b.active]

        # 7. Collisions: Player Missiles vs Enemies
        self._check_missile_enemy_collisions()

        # 8. Collisions: Enemy Bullets & Diving Enemies vs Player
        self._check_player_collisions()

        # 9. Update Rescued Ships
        for r_ship in self.rescued_ships:
            reached = r_ship.update(self.player.y)
            if reached and self.player.state == PlayerState.ALIVE:
                # Dock dual fighter!
                self.player.is_dual = True
                self.player.score += SCORE_RESCUE_BONUS
                sound_engine.play_rescue()
                self.score_popups.append(ScorePopup(self.player.x, self.player.y - 1, "DUAL FIGHTER 1000", COLOR_PLAYER_CYAN, 35))
        self.rescued_ships = [r for r in self.rescued_ships if r.active]

        # 10. Update Particles & Popups
        for exp in self.explosions:
            exp.update()
        self.explosions = [e for e in self.explosions if e.active]

        for sp in self.score_popups:
            sp.update()
        self.score_popups = [s for s in self.score_popups if s.active]

        # 11. Check Stage Clear
        if self.wave_mgr.is_cleared():
            if self.wave_mgr.is_challenging:
                self._finish_challenging_stage()
            else:
                self.state = GameState.STAGE_CLEAR
                self.state_timer = 50

    def _trigger_player_capture(self, boss: Enemy):
        """Transition to player capture sequence."""
        self.state = GameState.CAPTURING
        self.player.state = PlayerState.CAPTURED_BEAM
        self.player.capture_t = 0.0
        self.player.capture_start_pos = (self.player.x, self.player.y)
        self.player.capture_target_pos = (boss.x, boss.y - 2.0)
        self.capturing_boss = boss
        sound_engine.play_tractor()

    def _update_capturing(self):
        """Animate player being pulled upwards by tractor beam."""
        self.player.update()
        boss = self.capturing_boss

        if self.player.capture_t >= 1.0:
            # Capture completed!
            boss.has_captured_ship = True
            boss.state = EnemyState.TRACTOR_ASCENDING
            # Path back to formation
            dock_path = [(boss.x, boss.y), (boss.x, boss.y - 4.0), (boss.grid_x, boss.grid_y)]
            boss.start_path(dock_path, speed=0.03, state=EnemyState.RETURNING_TO_FORMATION)

            self.active_tractor_beam = None
            self.player.lives -= 1

            if self.player.lives > 0:
                self.player.state = PlayerState.RESPAWNING
                self.player.respawn_timer = 50
                self.player.x = float(PLAYFIELD_WIDTH // 2 - 1)
                self.player.y = float(PLAYFIELD_HEIGHT - 3)
                self.player.is_dual = False
                self.state = GameState.PLAYING
            else:
                self._trigger_game_over()

    def _check_missile_enemy_collisions(self):
        for missile in self.missiles:
            if not missile.active:
                continue

            for enemy in self.wave_mgr.enemies:
                if enemy.state == EnemyState.DEAD:
                    continue

                # Bounding box overlap
                if (abs(missile.x - (enemy.x + 1.0)) <= 1.4 and
                        abs(missile.y - (enemy.y + 0.8)) <= 1.2):
                    missile.active = False
                    self.player.hits += 1

                    if self.wave_mgr.is_challenging:
                        self.wave_mgr.challenging_hits += 1
                        self.player.score += SCORE_CHALLENGING_HIT
                        enemy.state = EnemyState.DEAD
                        self.explosions.append(Explosion(enemy.x, enemy.y, False))
                        sound_engine.play_hit()
                        break

                    # Regular stage damage
                    was_diving = enemy.state in (EnemyState.DIVING, EnemyState.TRACTOR_DESCENDING, EnemyState.TRACTOR_BEAM)
                    pts = enemy.score_value()
                    killed = enemy.take_damage()
                    if killed:
                        if self.active_tractor_beam and self.active_tractor_beam.boss is enemy:
                            self.active_tractor_beam = None
                        self.player.score += pts
                        self.explosions.append(Explosion(enemy.x, enemy.y, enemy.enemy_type == EnemyType.BOSS))
                        self.score_popups.append(ScorePopup(enemy.x, enemy.y, str(pts)))
                        sound_engine.play_explosion()

                        # If Boss held a captured ship:
                        if enemy.has_captured_ship and enemy.enemy_type == EnemyType.BOSS:
                            if was_diving:
                                # Rescue fighter!
                                self.rescued_ships.append(RescuedShip(enemy.x, enemy.y))
                                self.score_popups.append(ScorePopup(enemy.x, enemy.y - 1, "RESCUE!", COLOR_PLAYER_CYAN, 30))
                            else:
                                # Destroyed in formation: fighter lost
                                self.score_popups.append(ScorePopup(enemy.x, enemy.y - 1, "FIGHTER LOST", COLOR_EXP_ORANGE, 30))
                    else:
                        sound_engine.play_hit()
                    break

    def _check_player_collisions(self):
        if self.player.state != PlayerState.ALIVE:
            return

        px = self.player.x
        py = self.player.y
        pw = self.player.width

        # 1. Enemy Bullets vs Player
        for bullet in self.enemy_bullets:
            if not bullet.active:
                continue
            if px <= bullet.x <= px + pw and abs(bullet.y - py) <= 1.2:
                bullet.active = False
                self._player_hit(bullet.x)
                return

        # 2. Diving Enemy Ram vs Player
        for enemy in self.wave_mgr.enemies:
            if enemy.state in (EnemyState.DIVING, EnemyState.TRACTOR_DESCENDING):
                if (abs((enemy.x + 1.0) - (px + pw / 2.0)) <= (pw / 2.0 + 1.2) and
                        abs(enemy.y - py) <= 1.4):
                    enemy.state = EnemyState.DEAD
                    self.explosions.append(Explosion(enemy.x, enemy.y, enemy.enemy_type == EnemyType.BOSS))
                    self._player_hit(enemy.x + 1.0)
                    return

    def _player_hit(self, hit_x: float):
        sound_engine.play_explosion()
        self.explosions.append(Explosion(self.player.x, self.player.y, True))
        life_lost = self.player.hit(hit_x)

        if life_lost and self.player.lives <= 0:
            self._trigger_game_over()

    def _finish_challenging_stage(self):
        """Conclude challenging stage and calculate bonus."""
        self.state = GameState.CHALLENGING_RESULTS
        self.state_timer = 90
        hits = self.wave_mgr.challenging_hits
        if hits == self.wave_mgr.challenging_total:
            self.player.score += SCORE_CHALLENGING_PERFECT
            sound_engine.play_bonus()
        else:
            sound_engine.play_stage_start()

    def _trigger_game_over(self):
        self.state = GameState.GAME_OVER
        self.state_timer = 45  # Short input lock before allowing restart
        sound_engine.play_game_over()

        # Update high score leaderboard
        if is_high_score(self.player.score):
            add_high_score("PLY", self.player.score, self.stage)
            self.all_highscores = load_highscores()

    def render(self):
        """Draw current state to screen buffer and flush."""
        self.renderer.clear_playfield()
        buf = self.renderer.pf_buffer

        # Render starfield background
        self.starfield.render(buf)

        if self.state == GameState.TITLE:
            self._render_title_screen(buf)

        elif self.state == GameState.STAGE_INTRO:
            self._render_stage_intro(buf)
            self.player.draw(buf)

        elif self.state in (GameState.PLAYING, GameState.CAPTURING, GameState.PAUSED):
            self._render_gameplay(buf)
            if self.state == GameState.PAUSED:
                self._render_pause_overlay(buf)

        elif self.state == GameState.STAGE_CLEAR:
            self._render_gameplay(buf)
            self.renderer.draw_text(PLAYFIELD_WIDTH // 2 - 6, 14, "STAGE CLEAR!", COLOR_BANNER)

        elif self.state == GameState.CHALLENGING_RESULTS:
            self._render_challenging_results(buf)

        elif self.state == GameState.GAME_OVER:
            self._render_game_over_results(buf)

        # Flush frame to terminal
        self.renderer.render_frame(
            score=self.player.score,
            high_score=self.high_score,
            stage=self.stage,
            lives=self.player.lives,
            is_dual=self.player.is_dual,
            muted=sound_engine.muted,
            highscores=self.all_highscores,
            banner_text=self.banner_text
        )

    def _render_title_screen(self, buf):
        """Retro arcade title screen with animated logo and score table."""
        logo = [
            "   _________    __    ___   _________ ",
            "  / ____/   |  / /   /   | / ____/   |",
            " / / __/ /| | / /   / /| |/ / __/ /| |",
            "/ /_/ / ___ |/ /___/ ___ / /_/ / ___ |",
            "\____/_/  |_/_____/_/  |_\____/_/  |_|",
        ]
        start_y = 3
        logo_x = max(2, (PLAYFIELD_WIDTH - len(logo[0])) // 2)

        # Draw glowing Galaga logo
        col_list = [COLOR_BANNER, COLOR_EXP_ORANGE, COLOR_PLAYER_RED, COLOR_BANNER, COLOR_HUD_STAGE]
        logo_color = col_list[(self.tick_counter // 15) % len(col_list)]
        for idx, line in enumerate(logo):
            self.renderer.draw_text(logo_x, start_y + idx, line, logo_color)

        # Subtitle
        self.renderer.draw_text(PLAYFIELD_WIDTH // 2 - 13, start_y + 6, "(c) 1981 NAMCO / BAES INC.", COLOR_PLAYER_CYAN)

        # Point values showcase
        y_sc = start_y + 8
        self.renderer.draw_text(PLAYFIELD_WIDTH // 2 - 9, y_sc, "= POINT VALUES =", COLOR_HUD_LABEL)
        self.renderer.draw_text(10, y_sc + 2, " (O)  BOSS GALAGA", COLOR_BOSS_GREEN)
        self.renderer.draw_text(32, y_sc + 2, "150 / 400 PTS", COLOR_HUD_VAL)

        self.renderer.draw_text(10, y_sc + 4, r" \w/  RED BUTTERFLY", COLOR_BUTTERFLY_RED)
        self.renderer.draw_text(32, y_sc + 4, " 80 / 160 PTS", COLOR_HUD_VAL)

        self.renderer.draw_text(10, y_sc + 6, r" /o\  BLUE BEE", COLOR_BEE_CYAN)
        self.renderer.draw_text(32, y_sc + 6, " 50 / 100 PTS", COLOR_HUD_VAL)

        self.renderer.draw_text(10, y_sc + 8, r" [▲▲] DUAL FIGHTER RESCUE", COLOR_PLAYER_WHITE)
        self.renderer.draw_text(36, y_sc + 8, "1000 PTS", COLOR_BANNER)

        # Start prompt (blinking)
        if (self.tick_counter // 16) % 2 == 0:
            self.renderer.draw_text(PLAYFIELD_WIDTH // 2 - 12, y_sc + 11, "PRESS SPACE TO START", COLOR_BANNER)
        else:
            self.renderer.draw_text(PLAYFIELD_WIDTH // 2 - 12, y_sc + 11, "PRESS SPACE TO START", COLOR_GRAY)

        self.renderer.draw_text(PLAYFIELD_WIDTH // 2 - 11, y_sc + 13, "[A/D or Arrows] to Move", COLOR_GRAY)

    def _render_stage_intro(self, buf):
        stage_title = "CHALLENGING STAGE" if self.wave_mgr.is_challenging else f"STAGE  {self.stage}"
        self.renderer.draw_text(PLAYFIELD_WIDTH // 2 - (len(stage_title) // 2), 12, stage_title, COLOR_HUD_STAGE)
        self.renderer.draw_text(PLAYFIELD_WIDTH // 2 - 4, 15, "PLAYER 1", COLOR_HUD_LABEL)
        self.renderer.draw_text(PLAYFIELD_WIDTH // 2 - 3, 17, "READY", COLOR_BANNER)

    def _render_gameplay(self, buf):
        # 1. Tractor beam (behind ships)
        if self.active_tractor_beam:
            self.active_tractor_beam.draw(buf)

        # 2. Rescued ships
        for r_ship in self.rescued_ships:
            r_ship.draw(buf)

        # 3. Enemies
        for enemy in self.wave_mgr.enemies:
            enemy.draw(buf)

        # 4. Player
        self.player.draw(buf)

        # 5. Missiles & Bullets
        for missile in self.missiles:
            missile.draw(buf)
        for bullet in self.enemy_bullets:
            bullet.draw(buf)

        # 6. Explosions
        for exp in self.explosions:
            exp.draw(buf)

        # 7. Score popups
        for sp in self.score_popups:
            sp.draw(buf)

    def _render_pause_overlay(self, buf):
        self.renderer.draw_text(PLAYFIELD_WIDTH // 2 - 8, 14, "== GAME PAUSED ==", COLOR_BANNER)
        self.renderer.draw_text(PLAYFIELD_WIDTH // 2 - 10, 16, "PRESS P TO CONTINUE", COLOR_PLAYER_WHITE)

    def _render_challenging_results(self, buf):
        hits = self.wave_mgr.challenging_hits
        self.renderer.draw_text(PLAYFIELD_WIDTH // 2 - 9, 10, "- - RESULTS - -", COLOR_HUD_LABEL)
        self.renderer.draw_text(PLAYFIELD_WIDTH // 2 - 10, 13, f"NUMBER OF HITS: {hits:02d}", COLOR_PLAYER_CYAN)

        if hits == self.wave_mgr.challenging_total:
            self.renderer.draw_text(PLAYFIELD_WIDTH // 2 - 4, 16, "PERFECT!", COLOR_BANNER)
            self.renderer.draw_text(PLAYFIELD_WIDTH // 2 - 9, 18, "SPECIAL BONUS 10000", COLOR_BANNER)
        else:
            self.renderer.draw_text(PLAYFIELD_WIDTH // 2 - 11, 16, f"HIT POINTS: {hits * SCORE_CHALLENGING_HIT:05d}", COLOR_HUD_VAL)

    def _render_game_over_results(self, buf):
        """Classic Galaga arcade game over accuracy results table."""
        self.renderer.draw_text(PLAYFIELD_WIDTH // 2 - 5, 8, "GAME OVER", COLOR_HUD_LABEL)
        self.renderer.draw_text(PLAYFIELD_WIDTH // 2 - 9, 11, "- - RESULTS - -", COLOR_BANNER)

        shots = self.player.shots_fired
        hits = self.player.hits
        ratio = (hits / max(1, shots)) * 100.0

        self.renderer.draw_text(12, 14, f"SHOTS FIRED:       {shots}", COLOR_PLAYER_WHITE)
        self.renderer.draw_text(12, 16, f"NUMBER OF HITS:    {hits}", COLOR_PLAYER_WHITE)
        self.renderer.draw_text(12, 18, f"HIT-MISS RATIO:   {ratio:.1f} %", COLOR_HUD_STAGE)

        if self.state_timer <= 0:
            if (self.tick_counter // 15) % 2 == 0:
                self.renderer.draw_text(PLAYFIELD_WIDTH // 2 - 13, 22, "PRESS SPACE TO CONTINUE", COLOR_BANNER)

    def run(self):
        """Main game execution loop."""
        self.renderer.init_terminal()
        try:
            while self.running:
                frame_start = time.perf_counter()

                actions = self.inputs.get_actions()
                self.handle_input(actions)
                self.update()
                self.render()

                elapsed = time.perf_counter() - frame_start
                sleep_sec = max(0.001, self.frame_time - elapsed)
                time.sleep(sleep_sec)

        except KeyboardInterrupt:
            pass
        finally:
            sound_engine.stop()
            self.inputs.cleanup()
            self.renderer.cleanup_terminal()
            print("Thanks for playing Galaga Terminal Arcade!")
