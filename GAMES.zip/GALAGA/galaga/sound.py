"""Arcade Sound Engine for Galaga with background thread worker."""

import sys
import time
import queue
import threading
from typing import List, Tuple, Optional

# Check if winsound is available (Windows)
try:
    import winsound
    HAS_WINSOUND = True
except ImportError:
    HAS_WINSOUND = False


class SoundEngine:
    """Non-blocking arcade sound engine using background worker thread."""

    def __init__(self, enabled: bool = True):
        self.enabled = enabled and HAS_WINSOUND
        self.muted = not self.enabled
        self._queue: queue.Queue = queue.Queue(maxsize=8)
        self._running = True
        self._worker_thread = threading.Thread(target=self._worker, daemon=True)
        self._worker_thread.start()

    def _worker(self):
        """Worker loop that plays frequency tone sequences from the queue."""
        while self._running:
            try:
                tones = self._queue.get(timeout=0.1)
            except queue.Empty:
                continue

            if tones is None:  # Shutdown signal
                break

            if not self.muted and HAS_WINSOUND:
                for freq, duration_ms in tones:
                    if not self._running or self.muted:
                        break
                    try:
                        # Frequency must be in 37 - 32767 Hz range for winsound
                        safe_freq = max(37, min(32767, int(freq)))
                        winsound.Beep(safe_freq, int(duration_ms))
                    except Exception:
                        pass
            self._queue.task_done()

    def play(self, tones: List[Tuple[int, int]]):
        """Enqueue a sequence of (frequency_hz, duration_ms) pairs."""
        if self.muted or not self.enabled:
            return
        # If queue is getting backed up, drop new sounds to maintain arcade synchronicity
        if self._queue.qsize() > 2:
            return
        try:
            self._queue.put_nowait(tones)
        except queue.Full:
            pass

    def toggle_mute(self) -> bool:
        """Toggle audio mute state. Returns new muted state."""
        self.muted = not self.muted
        return self.muted

    def set_mute(self, muted: bool):
        """Set audio mute state."""
        self.muted = muted

    def stop(self):
        """Gracefully stop worker thread."""
        self._running = False
        try:
            self._queue.put_nowait(None)
        except Exception:
            pass

    # Preset Arcade Sound Effects
    def play_shoot(self):
        """Player laser shot."""
        self.play([(1500, 20), (1900, 20)])

    def play_hit(self):
        """Bullet hit on enemy."""
        self.play([(750, 30)])

    def play_explosion(self):
        """Enemy or player explosion."""
        self.play([(380, 25), (240, 35), (140, 45)])

    def play_dive(self):
        """Enemy break-off dive swoosh."""
        self.play([(850, 20), (620, 25)])

    def play_tractor(self):
        """Tractor beam capture wave."""
        self.play([(420, 35), (580, 35)])

    def play_rescue(self):
        """Dual fighter rescue celebration fanfare!"""
        self.play([(523, 50), (659, 50), (784, 60), (1046, 90)])

    def play_stage_start(self):
        """Stage start chime."""
        self.play([(440, 50), (554, 50), (659, 60), (880, 80)])

    def play_challenging_stage(self):
        """Challenging stage intro."""
        self.play([(659, 60), (784, 60), (988, 80), (1318, 100)])

    def play_game_over(self):
        """Game over descending tone."""
        self.play([(440, 80), (392, 80), (330, 90), (262, 140)])

    def play_bonus(self):
        """Challenging stage bonus award."""
        self.play([(880, 40), (1175, 40), (1480, 60)])


# Global instance
sound_engine = SoundEngine(enabled=True)
