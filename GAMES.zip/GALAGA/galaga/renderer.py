"""Flicker-free ANSI terminal renderer with double buffer and retro arcade bezel."""

import sys
import os
import shutil
from typing import List, Tuple, Optional
from .config import (
    PLAYFIELD_WIDTH, PLAYFIELD_HEIGHT, SIDEBAR_WIDTH,
    TOTAL_WIDTH, TOTAL_HEIGHT
)
from .colors import (
    rgb_fg, strip_ansi, visible_len, pad_ansi,
    COLOR_BORDER, COLOR_BORDER_CORNER, COLOR_HUD_LABEL, COLOR_HUD_VAL,
    COLOR_HUD_STAGE, COLOR_PLAYER_WHITE, COLOR_PLAYER_CYAN,
    COLOR_BOSS_GREEN, COLOR_BUTTERFLY_RED, COLOR_BEE_CYAN,
    COLOR_BANNER, COLOR_GRAY, COLOR_STAR_DIM, COLOR_STAR_MID,
    COLOR_STAR_BRIGHT, COLOR_STAR_WARP, RESET, BOLD
)

STAR_COLORS = {COLOR_STAR_DIM, COLOR_STAR_MID, COLOR_STAR_BRIGHT, COLOR_STAR_WARP}

# Enable ANSI escape processing on Windows console
# Reconfigure stdout for UTF-8 encoding on Windows consoles
if hasattr(sys.stdout, 'reconfigure'):
    try:
        sys.stdout.reconfigure(encoding='utf-8', errors='replace')
    except Exception:
        pass

if sys.platform == 'win32':
    try:
        import ctypes
        kernel32 = ctypes.windll.kernel32
        h_stdout = kernel32.GetStdHandle(-11)
        mode = ctypes.c_ulong()
        kernel32.GetConsoleMode(h_stdout, ctypes.byref(mode))
        kernel32.SetConsoleMode(h_stdout, mode.value | 0x0004 | 0x0001)
    except Exception:
        os.system('')  # Fallback to trigger VT processing


class Renderer:
    """High-performance ANSI screen renderer with double-buffer and arcade bezel."""

    def __init__(self, playfield_w: int = PLAYFIELD_WIDTH, playfield_h: int = PLAYFIELD_HEIGHT):
        self.playfield_w = playfield_w
        self.playfield_h = playfield_h
        self.sidebar_w = SIDEBAR_WIDTH

        # 2D cell buffer for playfield: each cell is (char, ansi_color_str)
        self.pf_buffer: List[List[Tuple[str, Optional[str]]]] = [
            [(' ', None) for _ in range(self.playfield_w)]
            for _ in range(self.playfield_h)
        ]

    def init_terminal(self):
        """Draw in the alternate screen so frames never scroll shell history."""
        sys.stdout.write("\x1b[?1049h\x1b[?25l\x1b[2J\x1b[H")
        sys.stdout.flush()

    def cleanup_terminal(self):
        """Restore the cursor and the previous shell screen."""
        sys.stdout.write(f"{RESET}\x1b[?25h\x1b[?1049l")
        sys.stdout.flush()

    def clear_playfield(self):
        """Reset playfield buffer to empty space."""
        for r in range(self.playfield_h):
            for c in range(self.playfield_w):
                self.pf_buffer[r][c] = (' ', None)

    def _render_row_cells(self, cells: List[Tuple[str, Optional[str]]]) -> str:
        """Serialize a row of cells into an ANSI string with color change optimization."""
        out = []
        current_col = None
        for ch, col in cells:
            if col != current_col:
                if current_col is not None and col is None:
                    out.append(RESET)
                elif col is not None:
                    out.append(col)
                current_col = col
            out.append(ch)
        if current_col is not None:
            out.append(RESET)
        return ''.join(out)

    def _visible_playfield(self, height: int) -> List[List[Tuple[str, Optional[str]]]]:
        """Fold the full game field into the terminal's available rows."""
        if height >= self.playfield_h:
            return self.pf_buffer

        compact = [[(' ', None) for _ in range(self.playfield_w)] for _ in range(height)]
        for source_y, row in enumerate(self.pf_buffer):
            target_y = round(source_y * (height - 1) / (self.playfield_h - 1))
            for x, (char, color) in enumerate(row):
                if char == ' ':
                    continue
                old_char, old_color = compact[target_y][x]
                # Keep ships, enemies, and shots visible when rows collapse.
                if old_char == ' ' or old_color in STAR_COLORS or color not in STAR_COLORS:
                    compact[target_y][x] = (char, color)
        return compact

    def draw_text(self, x: int, y: int, text: str, color: Optional[str] = None):
        """Directly write text into playfield buffer."""
        if not (0 <= y < self.playfield_h):
            return
        for idx, ch in enumerate(text):
            bx = x + idx
            if 0 <= bx < self.playfield_w:
                self.pf_buffer[y][bx] = (ch, color)

    def build_sidebar_lines(self, stage: int, lives: int, is_dual: bool, muted: bool, highscores: list) -> List[str]:
        """Construct the right-hand arcade marquee sidebar."""
        sb: List[str] = []
        w = self.sidebar_w

        def add_line(text: str = ""):
            sb.append(pad_ansi(text, w, 'left'))

        def add_center(text: str = ""):
            sb.append(pad_ansi(text, w, 'center'))

        add_center(f"{COLOR_BANNER}{BOLD}*** GALAGA ***{RESET}")
        add_center(f"{COLOR_HUD_STAGE}ARCADE CLASSIC{RESET}")
        add_line()
        add_line(f"{COLOR_HUD_LABEL}SCORE TABLE:{RESET}")
        add_line(f" {COLOR_BOSS_GREEN}(O){RESET} Boss Galaga:")
        add_line(f"   Formation: {COLOR_HUD_VAL}150{RESET}")
        add_line(f"   Diving:    {COLOR_HUD_VAL}400{RESET}")
        add_line(f" {COLOR_BUTTERFLY_RED}\\w/{RESET} Butterfly:")
        add_line(f"   Formation:  {COLOR_HUD_VAL}80{RESET}")
        add_line(f"   Diving:    {COLOR_HUD_VAL}160{RESET}")
        add_line(f" {COLOR_BEE_CYAN}/o\\{RESET} Blue Bee:")
        add_line(f"   Formation:  {COLOR_HUD_VAL}50{RESET}")
        add_line(f"   Diving:    {COLOR_HUD_VAL}100{RESET}")
        add_line()
        add_line(f"{COLOR_PLAYER_CYAN}DUAL FIGHTER:{RESET}")
        add_line(f" Rescue Bonus: {COLOR_HUD_VAL}1000{RESET}")
        add_line()
        add_line(f"{COLOR_HUD_LABEL}CONTROLS:{RESET}")
        add_line(" [A/D] / [Arrows] Move")
        add_line(" [Space] Fire Missile")
        add_line(" [P] Pause Game")
        snd_label = "OFF" if muted else "ON"
        add_line(f" [M] Mute ({snd_label})")
        add_line(" [Q] Quit Game")
        add_line()
        add_line(f"{COLOR_HUD_LABEL}LEADERBOARD:{RESET}")
        for entry in highscores[:3]:
            name = entry.get("name", "AAA")
            sc = entry.get("score", 0)
            add_line(f"  {name} - {COLOR_HUD_VAL}{sc:06d}{RESET}")

        # Pad sidebar to match playfield height
        while len(sb) < self.playfield_h:
            add_line()
        return sb[:self.playfield_h]

    def render_frame(self, score: int, high_score: int, stage: int,
                     lives: int, is_dual: bool, muted: bool, highscores: list,
                     banner_text: Optional[str] = None):
        """
        Assemble the complete arcade cabinet screen with top HUD,
        playfield, sidebar, and status footer, then flush to stdout.
        """
        try:
            term_w, term_h = shutil.get_terminal_size((80, 24))
        except Exception:
            term_w, term_h = 80, 24

        # Six rows are used by the cabinet frame and HUD. Leave one spare
        # column to avoid the terminal's bottom-right auto-wrap behavior.
        visible_h = min(self.playfield_h, term_h - 6)
        if term_w <= self.playfield_w + 2 or visible_h < 10:
            sys.stdout.write("\x1b[H\x1b[JResize terminal to at least "
                             f"{self.playfield_w + 3} columns by 16 rows.")
            sys.stdout.flush()
            return

        show_sidebar = term_w > (self.playfield_w + self.sidebar_w + 3)
        playfield = self._visible_playfield(visible_h)
        lines: List[str] = []

        # 1. Top Arcade HUD Bar
        hud_score = f"{COLOR_HUD_LABEL}1UP {COLOR_HUD_VAL}{score:06d}{RESET}"
        hud_hi = f"{COLOR_HUD_LABEL}HIGH {COLOR_HUD_VAL}{high_score:06d}{RESET}"
        hud_stg = f"{COLOR_HUD_STAGE}STAGE {stage:02d}{RESET}"

        hud_content = f"  {hud_score}        {hud_hi}        {hud_stg}  "
        hud_line = pad_ansi(hud_content, self.playfield_w, 'center')

        # Top Border
        border_top = f"{COLOR_BORDER_CORNER}╔" + ("═" * self.playfield_w)
        if show_sidebar:
            border_top += "╦" + ("═" * self.sidebar_w)
        border_top += f"╗{RESET}"
        lines.append(border_top)

        # HUD Row inside cabinet
        hud_row = f"{COLOR_BORDER}║{RESET}" + hud_line
        if show_sidebar:
            sb_header = pad_ansi(f"{COLOR_BANNER}NAMCO 1981{RESET}", self.sidebar_w, 'center')
            hud_row += f"{COLOR_BORDER}║{RESET}" + sb_header
        hud_row += f"{COLOR_BORDER}║{RESET}"
        lines.append(hud_row)

        # Divider below HUD
        div_row = f"{COLOR_BORDER}╠" + ("═" * self.playfield_w)
        if show_sidebar:
            div_row += "╬" + ("═" * self.sidebar_w)
        div_row += f"╣{RESET}"
        lines.append(div_row)

        # 2. Main Playfield & Sidebar Rows
        sidebar_lines = self.build_sidebar_lines(stage, lives, is_dual, muted, highscores) if show_sidebar else []

        for r in range(visible_h):
            row_str = self._render_row_cells(playfield[r])
            row_line = f"{COLOR_BORDER}║{RESET}{row_str}"
            if show_sidebar:
                sb_cell = sidebar_lines[r] if r < len(sidebar_lines) else (' ' * self.sidebar_w)
                row_line += f"{COLOR_BORDER}║{RESET}{sb_cell}"
            row_line += f"{COLOR_BORDER}║{RESET}"
            lines.append(row_line)

        # 3. Bottom Status Bar (Lives, Dual status, Audio)
        div_bottom = f"{COLOR_BORDER}╠" + ("═" * self.playfield_w)
        if show_sidebar:
            div_bottom += "╩" + ("═" * self.sidebar_w)
        div_bottom += f"╣{RESET}" if not show_sidebar else f"╝{RESET}"
        lines.append(div_bottom)

        # Lives Icons
        ship_icon = f"{COLOR_PLAYER_CYAN}▲▲{RESET}" if is_dual else f"{COLOR_PLAYER_WHITE}▲{RESET}"
        lives_display = " ".join([ship_icon] * max(0, lives))
        snd_txt = f"{COLOR_GRAY}MUTE{RESET}" if muted else f"{COLOR_BANNER}SOUND{RESET}"
        bottom_info = f" {COLOR_HUD_LABEL}SHIPS:{RESET} {lives_display}    {snd_txt}"
        if banner_text:
            bottom_info += f"   {COLOR_BANNER}{banner_text}{RESET}"

        status_row = f"{COLOR_BORDER}║{RESET}" + pad_ansi(bottom_info, self.playfield_w, 'left') + f"{COLOR_BORDER}║{RESET}"
        lines.append(status_row)

        # Final Bottom Border
        border_bottom = f"{COLOR_BORDER_CORNER}╚" + ("═" * self.playfield_w) + f"╝{RESET}"
        lines.append(border_bottom)

        # Single atomic frame flush
        frame_text = "\x1b[H" + "\r\n".join(line + "\x1b[K" for line in lines)
        try:
            sys.stdout.write(frame_text)
        except UnicodeEncodeError:
            sys.stdout.write(frame_text.encode('ascii', errors='replace').decode('ascii'))
        sys.stdout.flush()
