"""High score persistence and leaderboard manager."""

import json
from typing import List, Dict, Any
from .config import DATA_DIR, HIGHSCORES_FILE

DEFAULT_SCORES = [
    {"rank": 1, "name": "GAL", "score": 30000, "stage": 5},
    {"rank": 2, "name": "AGA", "score": 20000, "stage": 4},
    {"rank": 3, "name": "NAM", "score": 15000, "stage": 3},
    {"rank": 4, "name": "MID", "score": 10000, "stage": 2},
    {"rank": 5, "name": "ACE", "score": 5000, "stage": 1},
]


def load_highscores() -> List[Dict[str, Any]]:
    """Load high scores from file or create with default entries."""
    if not HIGHSCORES_FILE.exists():
        save_highscores(DEFAULT_SCORES)
        return DEFAULT_SCORES

    try:
        with open(HIGHSCORES_FILE, 'r', encoding='utf-8') as f:
            data = json.load(f)
            if isinstance(data, list) and len(data) > 0:
                return data
    except Exception:
        pass

    return DEFAULT_SCORES


def save_highscores(scores: List[Dict[str, Any]]):
    """Save high scores list to JSON file."""
    try:
        DATA_DIR.mkdir(parents=True, exist_ok=True)
        with open(HIGHSCORES_FILE, 'w', encoding='utf-8') as f:
            json.dump(scores, f, indent=2)
    except Exception:
        pass


def get_top_score() -> int:
    """Return the current #1 all-time high score."""
    scores = load_highscores()
    if scores:
        return scores[0].get("score", 20000)
    return 20000


def is_high_score(score: int) -> bool:
    """Check if given score qualifies for leaderboard top 5."""
    scores = load_highscores()
    if len(scores) < 5:
        return True
    return score > scores[-1].get("score", 0)


def add_high_score(name: str, score: int, stage: int) -> int:
    """
    Insert score into leaderboard, sort descending, keep top 5.
    Returns the rank (1-5) or 0 if not qualified.
    """
    scores = load_highscores()
    new_entry = {
        "name": (name.upper()[:3] or "AAA"),
        "score": score,
        "stage": stage
    }
    scores.append(new_entry)
    scores.sort(key=lambda x: x.get("score", 0), reverse=True)
    scores = scores[:5]

    for idx, item in enumerate(scores):
        item["rank"] = idx + 1

    save_highscores(scores)

    for idx, item in enumerate(scores):
        if item["name"] == new_entry["name"] and item["score"] == score:
            return idx + 1
    return 0
