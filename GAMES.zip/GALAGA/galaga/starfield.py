"""Parallax scrolling starfield background for deep arcade space."""

import random
from typing import List, Tuple
from .config import PLAYFIELD_WIDTH, PLAYFIELD_HEIGHT, STAR_COUNT
from .colors import COLOR_STAR_DIM, COLOR_STAR_MID, COLOR_STAR_BRIGHT, COLOR_STAR_WARP


class Star:
    def __init__(self, x: float, y: float, layer: int):
        self.x = x
        self.y = y
        self.layer = layer
        if layer == 0:
            self.char = '.'
            self.color = COLOR_STAR_DIM
            self.speed = 0.25
        elif layer == 1:
            self.char = '*'
            self.color = COLOR_STAR_MID
            self.speed = 0.55
        else:
            self.char = '+'
            self.color = COLOR_STAR_BRIGHT
            self.speed = 1.05


class Starfield:
    """Manages multi-layer scrolling stars."""

    def __init__(self, width: int = PLAYFIELD_WIDTH, height: int = PLAYFIELD_HEIGHT, count: int = STAR_COUNT):
        self.width = width
        self.height = height
        self.count = count
        self.warp_mode = False
        self.stars: List[Star] = []
        self._init_stars()

    def _init_stars(self):
        self.stars.clear()
        for _ in range(self.count):
            layer = random.choices([0, 1, 2], weights=[50, 35, 15])[0]
            x = random.randint(1, self.width - 2)
            y = random.uniform(1, self.height - 2)
            self.stars.append(Star(x, y, layer))

    def update(self):
        """Update star positions."""
        speed_mult = 3.5 if self.warp_mode else 1.0
        for star in self.stars:
            star.y += star.speed * speed_mult
            if star.y >= self.height - 1:
                star.y = 1.0
                star.x = random.randint(1, self.width - 2)

    def set_warp(self, warp: bool):
        """Toggle fast warp scrolling."""
        self.warp_mode = warp

    def render(self, buffer: List[List[Tuple[str, str]]]):
        """Render stars directly into the screen character buffer."""
        for star in self.stars:
            ix = int(star.x)
            iy = int(star.y)
            if 0 <= iy < self.height and 0 <= ix < self.width:
                color = COLOR_STAR_WARP if self.warp_mode else star.color
                char = '|' if self.warp_mode and star.layer >= 1 else star.char
                buffer[iy][ix] = (char, color)
