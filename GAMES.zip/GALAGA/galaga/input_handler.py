"""Cross-platform non-blocking keyboard input handler."""

import sys
import os
import ctypes
from enum import Enum, auto
from typing import Set, Optional

# Windows input
try:
    import msvcrt
    IS_WINDOWS = True
except ImportError:
    IS_WINDOWS = False

# Unix input
if not IS_WINDOWS:
    import select
    import termios
    import tty


class Action(Enum):
    LEFT = auto()
    RIGHT = auto()
    UP = auto()
    DOWN = auto()
    FIRE = auto()
    PAUSE = auto()
    MUTE = auto()
    QUIT = auto()
    START = auto()
    ANY_KEY = auto()


class InputHandler:
    """Non-blocking keyboard reader supporting Windows and POSIX terminals."""

    def __init__(self):
        self.orig_term_settings = None
        self._get_async_key_state = None
        if IS_WINDOWS:
            try:
                get_key_state = ctypes.windll.user32.GetAsyncKeyState
                get_key_state.argtypes = [ctypes.c_int]
                get_key_state.restype = ctypes.c_short
                self._get_async_key_state = get_key_state
            except (AttributeError, OSError):
                pass
        if not IS_WINDOWS:
            try:
                self.orig_term_settings = termios.tcgetattr(sys.stdin)
                tty.setcbreak(sys.stdin.fileno())
            except Exception:
                pass

    def cleanup(self):
        """Restore original terminal input settings."""
        if not IS_WINDOWS and self.orig_term_settings is not None:
            try:
                termios.tcsetattr(sys.stdin, termios.TCSADRAIN, self.orig_term_settings)
            except Exception:
                pass

    def get_actions(self) -> Set[Action]:
        """Poll input without blocking and return all detected player actions for this frame."""
        actions: Set[Action] = set()

        if IS_WINDOWS:
            while msvcrt.kbhit():
                ch = msvcrt.getwch()
                actions.add(Action.ANY_KEY)

                # Special key prefix (Arrow keys, Fn keys, etc.)
                if ch in ('\x00', '\xe0'):
                    if msvcrt.kbhit():
                        code = msvcrt.getwch()
                        if code == 'K':  # Left arrow
                            actions.add(Action.LEFT)
                        elif code == 'M':  # Right arrow
                            actions.add(Action.RIGHT)
                        elif code == 'H':  # Up arrow
                            actions.add(Action.UP)
                        elif code == 'P':  # Down arrow
                            actions.add(Action.DOWN)
                elif ch in ('a', 'A'):
                    actions.add(Action.LEFT)
                elif ch in ('d', 'D'):
                    actions.add(Action.RIGHT)
                elif ch in ('w', 'W'):
                    actions.add(Action.UP)
                elif ch in ('s', 'S'):
                    actions.add(Action.DOWN)
                elif ch == ' ':
                    actions.add(Action.FIRE)
                elif ch in ('\r', '\n'):
                    actions.add(Action.START)
                    actions.add(Action.FIRE)
                elif ch in ('p', 'P'):
                    actions.add(Action.PAUSE)
                elif ch in ('m', 'M'):
                    actions.add(Action.MUTE)
                elif ch in ('q', 'Q', '\x1b'):
                    actions.add(Action.QUIT)

            # Console key events arrive at the OS repeat rate. Poll keys that
            # should stay active every frame for smooth movement and fire.
            if self._get_async_key_state is not None:
                held = lambda key: bool(self._get_async_key_state(key) & 0x8000)
                if held(0x25) or held(ord('A')):  # left arrow / A
                    actions.add(Action.LEFT)
                if held(0x27) or held(ord('D')):  # right arrow / D
                    actions.add(Action.RIGHT)
                if held(0x20):  # space
                    actions.add(Action.FIRE)

        else:
            # POSIX non-blocking read
            try:
                while sys.stdin in select.select([sys.stdin], [], [], 0)[0]:
                    ch = sys.stdin.read(1)
                    actions.add(Action.ANY_KEY)
                    if ch == '\x1b':
                        # Check for escape sequence
                        if sys.stdin in select.select([sys.stdin], [], [], 0.01)[0]:
                            seq1 = sys.stdin.read(1)
                            if seq1 == '[':
                                if sys.stdin in select.select([sys.stdin], [], [], 0.01)[0]:
                                    seq2 = sys.stdin.read(1)
                                    if seq2 == 'D':
                                        actions.add(Action.LEFT)
                                    elif seq2 == 'C':
                                        actions.add(Action.RIGHT)
                                    elif seq2 == 'A':
                                        actions.add(Action.UP)
                                    elif seq2 == 'B':
                                        actions.add(Action.DOWN)
                        else:
                            actions.add(Action.QUIT)
                    elif ch in ('a', 'A'):
                        actions.add(Action.LEFT)
                    elif ch in ('d', 'D'):
                        actions.add(Action.RIGHT)
                    elif ch in ('w', 'W'):
                        actions.add(Action.UP)
                    elif ch in ('s', 'S'):
                        actions.add(Action.DOWN)
                    elif ch == ' ':
                        actions.add(Action.FIRE)
                    elif ch in ('\r', '\n'):
                        actions.add(Action.START)
                        actions.add(Action.FIRE)
                    elif ch in ('p', 'P'):
                        actions.add(Action.PAUSE)
                    elif ch in ('m', 'M'):
                        actions.add(Action.MUTE)
                    elif ch in ('q', 'Q'):
                        actions.add(Action.QUIT)
            except Exception:
                pass

        return actions
