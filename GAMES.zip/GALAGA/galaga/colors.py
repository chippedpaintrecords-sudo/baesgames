"""ANSI color utilities and palettes for Galaga arcade."""

import re

# ANSI regex pattern
ANSI_PATTERN = re.compile(r'\x1b\[[0-9;]*[a-zA-Z]')

RESET = "\x1b[0m"
BOLD = "\x1b[1m"
DIM = "\x1b[2m"
ITALIC = "\x1b[3m"
UNDERLINE = "\x1b[4m"
BLINK = "\x1b[5m"
REVERSE = "\x1b[7m"

def rgb_fg(r: int, g: int, b: int) -> str:
    """Return ANSI 24-bit truecolor escape code for foreground."""
    return f"\x1b[38;2;{r};{g};{b}m"

def rgb_bg(r: int, g: int, b: int) -> str:
    """Return ANSI 24-bit truecolor escape code for background."""
    return f"\x1b[48;2;{r};{g};{b}m"

def fg(r: int, g: int, b: int, text: str) -> str:
    """Wrap text in foreground RGB color and reset."""
    return f"{rgb_fg(r, g, b)}{text}{RESET}"

def strip_ansi(text: str) -> str:
    """Strip all ANSI escape codes from text."""
    return ANSI_PATTERN.sub('', text)

def visible_len(text: str) -> int:
    """Return the visible character width of a string excluding ANSI sequences."""
    return len(strip_ansi(text))

def pad_ansi(text: str, width: int, align: str = 'left') -> str:
    """
    Pad a string containing ANSI escape codes to a fixed visible width.
    align can be 'left', 'right', or 'center'.
    """
    vlen = visible_len(text)
    pad = max(0, width - vlen)
    if align == 'left':
        return text + (' ' * pad)
    elif align == 'right':
        return (' ' * pad) + text
    elif align == 'center':
        left_pad = pad // 2
        right_pad = pad - left_pad
        return (' ' * left_pad) + text + (' ' * right_pad)
    return text

# Arcade Color Palette
COLOR_BLACK = rgb_fg(0, 0, 0)
COLOR_WHITE = rgb_fg(255, 255, 255)
COLOR_GRAY = rgb_fg(140, 140, 140)
COLOR_DARK_GRAY = rgb_fg(60, 60, 80)

# Player Colors
COLOR_PLAYER_WHITE = rgb_fg(240, 245, 255)
COLOR_PLAYER_RED = rgb_fg(255, 50, 50)
COLOR_PLAYER_CYAN = rgb_fg(60, 220, 255)
COLOR_PLAYER_GOLD = rgb_fg(255, 215, 0)

# Enemy Colors
# Boss Galaga: Lime green when healthy, deep blue when damaged
COLOR_BOSS_GREEN = rgb_fg(50, 220, 60)
COLOR_BOSS_YELLOW = rgb_fg(255, 230, 0)
COLOR_BOSS_DAMAGED = rgb_fg(40, 140, 255)

# Red Butterfly: Crimson Red + Amber
COLOR_BUTTERFLY_RED = rgb_fg(255, 55, 55)
COLOR_BUTTERFLY_AMBER = rgb_fg(255, 170, 0)

# Blue Bee: Cyan wings + Yellow core
COLOR_BEE_CYAN = rgb_fg(40, 210, 255)
COLOR_BEE_YELLOW = rgb_fg(255, 220, 30)

# Projectiles
COLOR_PLAYER_MISSILE = rgb_fg(255, 255, 120)
COLOR_ENEMY_BULLET = rgb_fg(255, 90, 40)

# Tractor Beam
COLOR_BEAM_CYAN = rgb_fg(0, 255, 255)
COLOR_BEAM_BLUE = rgb_fg(65, 150, 255)
COLOR_BEAM_WHITE = rgb_fg(220, 240, 255)

# Particles / Explosions
COLOR_EXP_WHITE = rgb_fg(255, 255, 255)
COLOR_EXP_YELLOW = rgb_fg(255, 240, 70)
COLOR_EXP_ORANGE = rgb_fg(255, 140, 20)
COLOR_EXP_RED = rgb_fg(230, 30, 30)

# Starfield Layers
COLOR_STAR_DIM = rgb_fg(70, 70, 110)
COLOR_STAR_MID = rgb_fg(140, 160, 220)
COLOR_STAR_BRIGHT = rgb_fg(255, 255, 255)
COLOR_STAR_WARP = rgb_fg(120, 200, 255)

# UI & HUD
COLOR_HUD_LABEL = rgb_fg(255, 50, 50)     # "1UP", "HIGH SCORE"
COLOR_HUD_VAL = rgb_fg(255, 255, 255)     # Scores
COLOR_HUD_STAGE = rgb_fg(60, 220, 255)    # Stage badges
COLOR_BORDER = rgb_fg(50, 80, 160)        # Deep arcade cabinet blue border
COLOR_BORDER_CORNER = rgb_fg(90, 130, 220)
COLOR_BANNER = rgb_fg(255, 220, 0)
