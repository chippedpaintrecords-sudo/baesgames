"""Galaga Terminal Arcade - Main Entry Point.

Launch the game with:
    python main.py
"""

import argparse
from galaga.config import FPS
from galaga.sound import sound_engine
from galaga.game import GalagaGame


def parse_arguments():
    parser = argparse.ArgumentParser(
        description="Galaga Terminal Arcade - Faithful 1981 arcade clone in Python"
    )
    parser.add_argument(
        "--no-sound", "-m", action="store_true",
        help="Start the game with sound effects muted"
    )
    parser.add_argument(
        "--fps", type=int, default=FPS,
        help=f"Target frame rate (default: {FPS})"
    )
    args = parser.parse_args()
    if args.fps <= 0:
        parser.error("--fps must be a positive integer")
    return args


def main():
    args = parse_arguments()

    if args.no_sound:
        sound_engine.set_mute(True)

    game = GalagaGame(fps=args.fps)
    game.run()


if __name__ == "__main__":
    main()
