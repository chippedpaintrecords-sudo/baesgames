@echo off
setlocal
title GALAGA TERMINAL ARCADE
set "PYTHON_EXE="
for /d %%D in ("%LOCALAPPDATA%\Programs\Python\Python3*") do (
    if exist "%%~fD\python.exe" set "PYTHON_EXE=%%~fD\python.exe"
)
if defined PYTHON_EXE (
    "%PYTHON_EXE%" "%~dp0main.py" %*
) else (
    python "%~dp0main.py" %*
)
if errorlevel 1 (
    echo.
    echo Game exited with error. Press any key to close.
    pause >nul
)
