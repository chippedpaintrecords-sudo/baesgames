# 🚀 GALAGA Terminal Arcade

A faithful, feature-complete clone of the iconic 1981 **Galaga** arcade cabinet running entirely in your terminal! Built in pure Python with zero external game engine dependencies, featuring smooth flicker-free ANSI rendering, authentic enemy flight curves, tractor beam captures, dual fighter linkage, bonus challenging stages, and retro arcade sound effects.

---

## 🕹️ Quick Start

### Windows
Double-click `run.bat` or launch from PowerShell / Command Prompt:

```powershell
.\run.bat
```

The display fits a standard 80 x 24 terminal. A larger terminal shows more vertical detail and the score sidebar; the minimum size is 59 columns by 16 rows.

### Linux / macOS
```bash
python3 main.py
```

### Command-Line Options
On Windows, pass these options to `.\run.bat` if `python` does not launch your installed interpreter.

```bash
python main.py --help
python main.py --no-sound     # Start with audio muted
python main.py --fps 40       # Customize frame rate (default: 35; also changes game pace)
```

---

## 🎮 Controls

| Action | Keys | Description |
|---|---|---|
| **Move Left / Right** | `Left` / `Right` Arrow or `A` / `D` | Move the ship; held keys move smoothly on Windows |
| **Fire Missile** | `Spacebar` or `Enter` | Fire lasers (up to 2 for single, 4 for dual); hold Space on Windows |
| **Pause Game** | `P` | Pause / Resume gameplay |
| **Mute / Unmute** | `M` | Toggle arcade sound effects in real-time |
| **Start / Restart** | `Spacebar` or `Enter` | Start game from title / continue from Game Over |
| **Quit Game** | `Q` or `Esc` | Return to title screen or exit |

---

## ✨ Authentic Arcade Features

### 1. 🛸 Dual Fighter & Tractor Beam Capture Mechanics
- **Tractor Beam**: Boss Galagas periodically descend, hover, and project an expanding cone of shimmering cyan tractor energy.
- **Ship Capture**: If caught in the tractor beam, your ship spins upward into the Boss Galaga and is held captive!
- **Fighter Rescue**: When that Boss Galaga later dive-bombs with your captured fighter, destroy the diving Boss (without hitting your captured ship) to release your captive.
- **Dual Fighter Mode**: The freed ship descends and docks beside your ship, linking together into a **Dual Fighter**!
  - 2x firing power: 2 parallel pairs of missiles (up to 4 on screen at once).
  - Absorbs a hit: if an enemy bullet clips one side, that ship explodes while the other survives as a single fighter!

### 2. 🐝 Authentic 40-Enemy Formation & Flight Dynamics
- **Choreographed Entry Waves**: Each stage begins with 5 swooping groups of 8 enemies entering from screen corners along cubic Bezier curves, looping across the display before docking.
- **Breathing Formation**: Enemies in the grid oscillate horizontally and pulse vertically.
- **Dynamic Dive-Bombs**: Blue Bees and Red Butterflies peel off in high-speed dive attacks, looping towards your ship while firing plasma bullets.
- **Escort Attacks**: Boss Galagas dive flanked by 1 or 2 Red Butterfly escorts.

### 3. 🎯 Bonus Challenging Stages (Bonus Rounds)
- Occurs on **Stage 3**, **Stage 7**, **Stage 11**, and every 4th stage thereafter.
- 5 successive waves of 8 enemies fly through acrobatic figure-8s and loops across the stars.
- Enemies do not fire bullets—test your marksmanship!
- End-of-stage report:
- Each hit scores 100 points immediately.
- Destroy all 40 enemies for an additional **PERFECT! 10,000 PTS** bonus!

### 4. 📊 Iconic Galaga Results Screen
At Game Over, see your true arcade performance statistics:
- **Shots Fired**
- **Number of Hits**
- **Hit-Miss Ratio %**
- Automatic high score tracking and leaderboard persistence in `data/highscores.json`.

### 5. 🔊 Arcade Sound Engine
- Non-blocking background worker thread synthesizing retro arcade frequencies (via Windows `winsound` with safe fallback).
- Distinct sound signatures for laser firing, dive drops, tractor beam pulses, explosions, dual fighter rescue fanfare, and stage clear melodies.
- Press `M` anytime to mute or unmute.

### 6. 🌌 Parallax Scrolling Starfield & Zero-Flicker Renderer
- 3-layer parallax starfield with variable speeds and twinkling effects.
- Warp-speed hyperdrive star streaming during stage warp intros.
- Atomic single-buffer ANSI cursor positioning engine (`\x1b[H`) eliminating screen tear and flicker.
- Retro arcade bezel frame with live leaderboard, score values, and ships remaining counter.

---

## 🏆 Scoring Guide

| Enemy | In Formation | In Flight / Diving |
|---|---|---|
| **Boss Galaga** `(O)` | 150 pts | 400 pts |
| **Red Butterfly** `\w/` | 80 pts | 160 pts |
| **Blue Bee** `/o\` | 50 pts | 100 pts |
| **Captured Fighter Rescue** | — | **1,000 pts** |
| **Challenging Stage Hit** | — | 100 pts each |
| **Challenging Stage Perfect (40/40)** | — | **10,000 pts** |
| **Extra Ship (1UP)** | Awarded at **20,000 pts**, then every **70,000 pts** |

---

## 📁 Project Structure

```
GALAGA/
├── galaga/
│   ├── __init__.py         # Package initialization
│   ├── config.py           # Speeds, dimensions, score tables, and timing constants
│   ├── colors.py           # ANSI 24-bit TrueColor palettes and string alignment tools
│   ├── input_handler.py    # Non-blocking keyboard input (Windows msvcrt + POSIX)
│   ├── sound.py            # Asynchronous arcade audio synthesizer
│   ├── renderer.py         # Double-buffered flicker-free ANSI terminal renderer
│   ├── starfield.py        # Multi-layer parallax scrolling background
│   ├── sprites.py          # Multi-frame animated ASCII sprites and colors
│   ├── entities.py         # Player, Enemy, Bullet, TractorBeam, RescuedShip classes
│   ├── formations.py       # Cubic Bezier math, acrobatic paths, and grid geometry
│   ├── waves.py            # Stage wave choreographer and challenging stage manager
│   ├── game.py             # Central arcade state machine and collision engine
│   └── highscores.py       # Leaderboard loading and persistence
├── tests/
│   ├── test_game.py        # Comprehensive unittest test suite
│   └── simulate_full_run.py# Headless end-to-end integration test
├── data/
│   └── highscores.json     # Saved high scores
├── main.py                 # Primary game launcher
├── run.bat                 # Windows double-click launcher
└── README.md               # Game documentation
```

---

## 🧪 Testing

Run the test suite at any time:

```bash
# Run unit tests
python -m unittest tests/test_game.py

# Run full headless gameplay simulation
python tests/simulate_full_run.py
```
