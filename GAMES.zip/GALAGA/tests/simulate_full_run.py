"""End-to-end headless gameplay simulation test."""

import sys
from pathlib import Path
sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

from galaga.game import GalagaGame, GameState
from galaga.input_handler import Action
from galaga.entities import EnemyState, EnemyType, Missile, PlayerState

def test_full_simulation():
    print("Testing Galaga end-to-end headless simulation...")
    game = GalagaGame()

    # 1. Title screen
    assert game.state == GameState.TITLE
    game.update()
    game.render()

    # 2. Press Space to Start
    game.handle_input({Action.START})
    assert game.state == GameState.STAGE_INTRO
    assert game.stage == 1

    # Fast forward through intro
    for _ in range(70):
        game.update()
    assert game.state == GameState.PLAYING
    print("✓ Stage 1 start verified")

    # 3. Simulate gameplay with player shooting
    for frame in range(120):
        if frame % 10 == 0:
            game.handle_input({Action.FIRE})
        if frame % 4 == 0:
            game.handle_input({Action.LEFT if (frame // 30) % 2 == 0 else Action.RIGHT})
        game.update()
        game.render()

    print(f"✓ Firing and movement verified (Shots: {game.player.shots_fired}, Score: {game.player.score})")

    # 4. Test Tractor Beam and Capture
    boss = [e for e in game.wave_mgr.enemies if e.enemy_type == EnemyType.BOSS][0]
    boss.y = 10.0
    boss.state = EnemyState.TRACTOR_BEAM
    boss.tractor_timer = 100
    boss.tractor_beam_width = 12.0
    boss.x = game.player.x
    game.update()
    assert game.state == GameState.CAPTURING
    print("✓ Tractor beam capture triggered")

    # Animate capture sequence
    for _ in range(40):
        game.update()
    assert boss.has_captured_ship == True
    print("✓ Player captured by Boss Galaga verified")

    # 5. Test Rescuing Captured Fighter -> DUAL FIGHTER
    boss.state = EnemyState.DIVING
    boss.hp = 1  # 1 HP left so next missile kills
    # Fire missile at Boss
    hit_missile = Missile(boss.x + 1.0, boss.y + 0.8)
    game.missiles.append(hit_missile)
    game._check_missile_enemy_collisions()
    assert len(game.rescued_ships) > 0
    print("✓ Rescued ship spawned from Boss")

    # Rescued ship descends to player
    game.player.state = PlayerState.ALIVE
    game.player.y = 25.0
    game.rescued_ships[0].y = 24.9
    game.update()
    assert game.player.is_dual == True
    print(f"✓ DUAL FIGHTER ACTIVATED! Width: {game.player.width}, Firepoints: {len(game.player.get_fire_positions())}")

    # Dual fighter fires 2 parallel missiles
    game.handle_input({Action.FIRE})
    assert len(game.missiles) >= 2
    print("✓ Dual missiles fired simultaneously")

    # 6. Test Challenging Stage Setup
    game._start_stage(3)
    assert game.wave_mgr.is_challenging == True
    for _ in range(70):
        game.update()
    assert game.state == GameState.PLAYING
    print("✓ Challenging Stage 3 initiated")

    # 7. Test Results Screen
    game.player.lives = 0
    game.player.hit()
    game._trigger_game_over()
    assert game.state == GameState.GAME_OVER
    game.render()
    print("✓ Game Over results screen rendered successfully")

    print("\nALL SIMULATION TESTS PASSED PERFECTLY!")

if __name__ == "__main__":
    test_full_simulation()
