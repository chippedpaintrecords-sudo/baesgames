"""Comprehensive test suite for Galaga Terminal Arcade."""

import sys
import unittest
import io
import os
from contextlib import redirect_stdout
from unittest.mock import patch
from pathlib import Path

# Add project root to sys.path
sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

from galaga.config import (
    PLAYFIELD_WIDTH, PLAYFIELD_HEIGHT, SCORE_BOSS_FORMATION, SCORE_BOSS_DIVING,
    SCORE_BUTTERFLY_FORMATION, SCORE_BEE_FORMATION, SCORE_RESCUE_BONUS
)
from galaga.colors import strip_ansi, visible_len, pad_ansi, rgb_fg
from galaga.starfield import Starfield
from galaga.formations import (
    cubic_bezier, generate_entry_path_top_right,
    generate_entry_path_top_left, generate_dive_path
)
from galaga.entities import (
    Player, PlayerState, Missile, Enemy, EnemyType, EnemyState,
    TractorBeam, RescuedShip, Explosion
)
from galaga.waves import WaveManager
from galaga.renderer import Renderer
from galaga.highscores import (
    load_highscores, save_highscores, add_high_score, is_high_score
)
from galaga.game import GalagaGame, GameState
from galaga.input_handler import Action, InputHandler, IS_WINDOWS


class TestGalagaColors(unittest.TestCase):
    def test_strip_and_visible_len(self):
        colored_txt = f"{rgb_fg(255, 0, 0)}TESTING{rgb_fg(0, 255, 0)} 123\x1b[0m"
        self.assertEqual(strip_ansi(colored_txt), "TESTING 123")
        self.assertEqual(visible_len(colored_txt), 11)

    def test_pad_ansi(self):
        colored_txt = f"{rgb_fg(255, 0, 0)}ABC\x1b[0m"
        padded_left = pad_ansi(colored_txt, 10, 'left')
        self.assertEqual(visible_len(padded_left), 10)
        self.assertTrue(padded_left.endswith("       "))

        padded_center = pad_ansi(colored_txt, 9, 'center')
        self.assertEqual(visible_len(padded_center), 9)


class TestTerminalRendering(unittest.TestCase):
    def test_frame_fits_common_terminal_sizes(self):
        renderer = Renderer()
        renderer.pf_buffer[27][20] = ('P', None)
        for width, height in [(80, 24), (84, 36), (120, 40)]:
            output = io.StringIO()
            with patch("galaga.renderer.shutil.get_terminal_size",
                       return_value=os.terminal_size((width, height))):
                with redirect_stdout(output):
                    renderer.render_frame(0, 30000, 1, 3, False, True, [])
            lines = strip_ansi(output.getvalue()).splitlines()
            self.assertLessEqual(len(lines), height)
            self.assertTrue(all(len(line) < width for line in lines))
            self.assertTrue(any('P' in line for line in lines))

    def test_short_terminal_shows_resize_message(self):
        renderer = Renderer()
        output = io.StringIO()
        with patch("galaga.renderer.shutil.get_terminal_size",
                   return_value=os.terminal_size((80, 12))):
            with redirect_stdout(output):
                renderer.render_frame(0, 30000, 1, 3, False, True, [])
        self.assertIn("Resize terminal", output.getvalue())


class TestGalagaFormationsAndCurves(unittest.TestCase):
    def test_cubic_bezier(self):
        p0 = (0.0, 0.0)
        p1 = (10.0, 0.0)
        p2 = (10.0, 20.0)
        p3 = (20.0, 20.0)
        start = cubic_bezier(p0, p1, p2, p3, 0.0)
        mid = cubic_bezier(p0, p1, p2, p3, 0.5)
        end = cubic_bezier(p0, p1, p2, p3, 1.0)

        self.assertAlmostEqual(start[0], 0.0)
        self.assertAlmostEqual(start[1], 0.0)
        self.assertAlmostEqual(mid[0], 10.0)
        self.assertAlmostEqual(mid[1], 10.0)
        self.assertAlmostEqual(end[0], 20.0)
        self.assertAlmostEqual(end[1], 20.0)

    def test_entry_paths(self):
        path = generate_entry_path_top_right((25.0, 5.0), PLAYFIELD_WIDTH, PLAYFIELD_HEIGHT)
        self.assertEqual(len(path), 7)
        self.assertEqual(path[-1], (25.0, 5.0))


class TestGalagaEntities(unittest.TestCase):
    def test_player_single_movement_and_bounds(self):
        player = Player(start_x=10, start_y=25)
        self.assertEqual(player.width, 3)
        self.assertFalse(player.is_dual)

        # Move left
        player.move(-5.0)
        self.assertEqual(player.x, 5.0)

        # Hit left boundary clamp
        player.move(-10.0)
        self.assertEqual(player.x, 2.0)

        # Move right
        player.move(100.0)
        self.assertEqual(player.x, PLAYFIELD_WIDTH - 2.0 - player.width)

    def test_player_dual_mode(self):
        player = Player(start_x=10, start_y=25)
        player.is_dual = True
        self.assertEqual(player.width, 7)
        fire_pos = player.get_fire_positions()
        self.assertEqual(len(fire_pos), 2)

        # Left side hit should drop to single fighter without losing life
        life_lost = player.hit(bullet_x=player.x + 1.0)
        self.assertFalse(life_lost)
        self.assertFalse(player.is_dual)
        self.assertEqual(player.lives, 3)

    def test_enemy_hp_and_score(self):
        boss = Enemy(EnemyType.BOSS, 0, 0, 20.0, 5.0)
        self.assertEqual(boss.hp, 2)
        self.assertEqual(boss.score_value(), SCORE_BOSS_FORMATION)

        # 1st hit damages boss
        killed = boss.take_damage()
        self.assertFalse(killed)
        self.assertEqual(boss.hp, 1)

        # Set to diving
        boss.state = EnemyState.DIVING
        self.assertEqual(boss.score_value(), SCORE_BOSS_DIVING)

        # 2nd hit destroys boss
        killed = boss.take_damage()
        self.assertTrue(killed)
        self.assertEqual(boss.hp, 0)

    def test_tractor_beam(self):
        boss = Enemy(EnemyType.BOSS, 0, 0, 25.0, 10.0)
        boss.state = EnemyState.TRACTOR_BEAM
        boss.tractor_beam_width = 10.0
        beam = TractorBeam(boss)

        player_in = Player(start_x=25.0, start_y=PLAYFIELD_HEIGHT - 3)
        self.assertTrue(beam.check_capture(player_in))

        player_out = Player(start_x=5.0, start_y=PLAYFIELD_HEIGHT - 3)
        self.assertFalse(beam.check_capture(player_out))


class TestWaveManager(unittest.TestCase):
    def test_wave_setup_40_enemies(self):
        wm = WaveManager(PLAYFIELD_WIDTH, PLAYFIELD_HEIGHT)
        wm.setup_stage(1)
        self.assertEqual(len(wm.enemies), 40)

        bosses = [e for e in wm.enemies if e.enemy_type == EnemyType.BOSS]
        butterflies = [e for e in wm.enemies if e.enemy_type == EnemyType.BUTTERFLY]
        bees = [e for e in wm.enemies if e.enemy_type == EnemyType.BEE]

        self.assertEqual(len(bosses), 4)
        self.assertEqual(len(butterflies), 16)
        self.assertEqual(len(bees), 20)
        self.assertFalse(wm.is_challenging)

    def test_challenging_stage_detection(self):
        wm = WaveManager(PLAYFIELD_WIDTH, PLAYFIELD_HEIGHT)
        self.assertFalse(wm.is_stage_challenging(1))
        self.assertFalse(wm.is_stage_challenging(2))
        self.assertTrue(wm.is_stage_challenging(3))
        self.assertFalse(wm.is_stage_challenging(4))
        self.assertTrue(wm.is_stage_challenging(7))

    def test_queued_enemies_wait_offscreen(self):
        wm = WaveManager(PLAYFIELD_WIDTH, PLAYFIELD_HEIGHT)
        wm.setup_stage(1)
        queued_enemy, path, delay = wm.entry_queue[-1]
        self.assertGreater(delay, 0)
        self.assertEqual((queued_enemy.x, queued_enemy.y), (-10.0, -10.0))
        self.assertFalse(0 <= queued_enemy.x < PLAYFIELD_WIDTH and
                         0 <= queued_enemy.y < PLAYFIELD_HEIGHT)
        wm.update(PLAYFIELD_WIDTH / 2, False)
        self.assertEqual(queued_enemy.path, [])

    def test_escort_returns_after_boss_dies(self):
        boss = Enemy(EnemyType.BOSS, 0, 4, 24.0, 4.0)
        escort = Enemy(EnemyType.BUTTERFLY, 1, 4, 24.0, 7.0)
        escort.x, escort.y = 28.0, 19.0
        escort.state = EnemyState.DIVING
        escort.is_escort = True
        escort.boss_leader = boss
        boss.state = EnemyState.DEAD

        escort.update(0.0, 0.0, 25.0)
        self.assertEqual(escort.state, EnemyState.RETURNING_TO_FORMATION)
        self.assertFalse(escort.is_escort)
        for _ in range(35):
            escort.update(0.0, 0.0, 25.0)
        self.assertEqual(escort.state, EnemyState.IN_FORMATION)


class TestGalagaGameSimulation(unittest.TestCase):
    def test_fps_and_dual_missile_limit(self):
        game = GalagaGame(fps=50)
        self.assertAlmostEqual(game.frame_time, 0.02)
        with self.assertRaises(ValueError):
            GalagaGame(fps=0)

        game.start_new_game()
        game.state = GameState.PLAYING
        game.player.is_dual = True
        game.missiles = [Missile(1.0, 10.0) for _ in range(3)]
        game.handle_input({Action.FIRE})
        self.assertEqual(len(game.missiles), 3)
        game.missiles.pop()
        game.handle_input({Action.FIRE})
        self.assertEqual(len(game.missiles), 4)

    def test_challenging_hits_are_scored_once_and_perfect_adds_bonus(self):
        game = GalagaGame()
        game._start_stage(3)
        enemy = game.wave_mgr.enemies[0]
        enemy.x, enemy.y = 24.0, 12.0
        game.missiles.append(Missile(enemy.x + 1.0, enemy.y + 0.8))
        game._check_missile_enemy_collisions()
        self.assertEqual(game.player.score, 100)
        self.assertEqual(game.wave_mgr.challenging_hits, 1)

        game._finish_challenging_stage()
        self.assertEqual(game.player.score, 100)

        game.wave_mgr.challenging_hits = game.wave_mgr.challenging_total
        game.player.score = 4000
        game._finish_challenging_stage()
        self.assertEqual(game.player.score, 14000)

    def test_extra_lives_for_large_score_jump(self):
        game = GalagaGame()
        game.player.score = 160000
        game.update()
        self.assertEqual(game.player.lives, 6)
        self.assertEqual(game.extra_life_target, 230000)

    def test_headless_game_simulation(self):
        game = GalagaGame()
        self.assertEqual(game.state, GameState.TITLE)

        # Start game
        game.handle_input({Action.START})
        self.assertEqual(game.state, GameState.STAGE_INTRO)
        self.assertEqual(game.stage, 1)

        # Run through intro frames
        for _ in range(70):
            game.update()
        self.assertEqual(game.state, GameState.PLAYING)

        # Simulate player moving and firing
        game.handle_input({Action.LEFT, Action.FIRE})
        self.assertTrue(len(game.missiles) > 0)
        self.assertEqual(game.player.shots_fired, 1)

        # Simulate 100 gameplay frames
        for _ in range(100):
            game.update()

        # Verify starfield and entities continue running smoothly
        self.assertTrue(game.tick_counter > 150)


@unittest.skipUnless(IS_WINDOWS, "Windows held-key polling")
class TestWindowsInput(unittest.TestCase):
    def test_held_controls_work_without_repeat_events(self):
        handler = InputHandler()
        held_keys = {0x25, 0x20}  # left arrow and space
        handler._get_async_key_state = lambda key: 0x8000 if key in held_keys else 0
        with patch("galaga.input_handler.msvcrt.kbhit", return_value=False):
            actions = handler.get_actions()
        self.assertIn(Action.LEFT, actions)
        self.assertIn(Action.FIRE, actions)
        self.assertNotIn(Action.RIGHT, actions)


if __name__ == "__main__":
    unittest.main()
