#!/usr/bin/env python3
"""
CENTIPEDE
=========
Launch script for the Centipede terminal arcade game.
"""

from centipede import main

if __name__ == "__main__":
    main()
