#!/usr/bin/env python3
"""
CENTIPEDE - Classic Atari 1980 Arcade Terminal Clone
====================================================
A complete, retro-authentic Centipede arcade clone designed for the terminal.
Features:
  - 100% Flicker-free ANSI double-buffered rendering
  - Authentic Centipede physics: snaking trail, splitting upon hit, head promotion
  - Poisoned mushroom plunger behavior
  - Bouncing Spiders with proximity-based dynamic scoring (300 / 600 / 900 pts)
  - Dropping Fleas that seed mushrooms when density is low (200 pts)
  - Scorpions crawling horizontally to poison mushrooms (1,000 pts)
  - Post-death mushroom regeneration tally with bonus points (10 pts per mushroom)
  - Extra bonus life awarded every 12,000 points
  - Cycling retro color palettes per wave
  - Threaded chiptune audio synthesizer (mute toggle with 'M')
  - Explosions, particle debris, and floating score popups
  - Smooth 4-way/8-way movement within restricted player territory
  - Persistent high-score tracking across sessions
  - Cross-platform support (Windows GetAsyncKeyState / msvcrt + Unix termios/select)
"""

import sys
import os
import time
import json
import math
import random
import queue
import threading

# ---------------------------------------------------------------------------
# Platform and Terminal Configuration
# ---------------------------------------------------------------------------

IS_WINDOWS = sys.platform == "win32"

if IS_WINDOWS:
    import msvcrt
    import ctypes
    # Enable Virtual Terminal Processing for ANSI colors & UTF-8 output
    try:
        sys.stdout.reconfigure(encoding="utf-8")
    except Exception:
        pass
    try:
        kernel32 = ctypes.windll.kernel32
        kernel32.SetConsoleOutputCP(65001)
        kernel32.SetConsoleCP(65001)
        h_stdout = kernel32.GetStdHandle(-11)  # STD_OUTPUT_HANDLE
        mode = ctypes.c_ulong()
        if kernel32.GetConsoleMode(h_stdout, ctypes.byref(mode)):
            mode.value |= 0x0004  # ENABLE_VIRTUAL_TERMINAL_PROCESSING
            kernel32.SetConsoleMode(h_stdout, mode)
    except Exception:
        pass
else:
    import select
    import tty
    import termios


# ---------------------------------------------------------------------------
# ANSI Color Codes & Styles
# ---------------------------------------------------------------------------

RESET = "\033[0m"
BOLD = "\033[1m"
DIM = "\033[2m"

# Foreground Colors
C_RED = "\033[91m"
C_GREEN = "\033[92m"
C_YELLOW = "\033[93m"
C_BLUE = "\033[94m"
C_MAGENTA = "\033[95m"
C_CYAN = "\033[96m"
C_WHITE = "\033[97m"
C_GRAY = "\033[90m"
C_ORANGE = "\033[38;5;208m"
C_PURPLE = "\033[38;5;135m"
C_GOLD = "\033[38;5;220m"
C_NEON_PINK = "\033[38;5;201m"
C_LIME = "\033[38;5;118m"

# Cursor Controls
CURSOR_HIDE = "\033[?25l"
CURSOR_SHOW = "\033[?25h"
CURSOR_HOME = "\033[H"
CLEAR_SCREEN = "\033[2J"


# ---------------------------------------------------------------------------
# Wave Retro Color Palettes (Authentic Arcade Color Cycling)
# ---------------------------------------------------------------------------

PALETTES = [
    {
        "name": "Emerald Glade",
        "mushroom": C_GREEN,
        "poison": C_MAGENTA,
        "centipede_head": BOLD + C_YELLOW,
        "centipede_body": C_YELLOW,
        "spider": C_WHITE,
        "flea": C_CYAN,
        "scorpion": C_RED,
        "border": BOLD + C_GREEN,
    },
    {
        "name": "Neon Amber",
        "mushroom": C_CYAN,
        "poison": C_RED,
        "centipede_head": BOLD + C_ORANGE,
        "centipede_body": C_ORANGE,
        "spider": C_YELLOW,
        "flea": C_LIME,
        "scorpion": C_MAGENTA,
        "border": BOLD + C_CYAN,
    },
    {
        "name": "Violet Mire",
        "mushroom": C_MAGENTA,
        "poison": C_YELLOW,
        "centipede_head": BOLD + C_LIME,
        "centipede_body": C_LIME,
        "spider": C_CYAN,
        "flea": C_GOLD,
        "scorpion": C_ORANGE,
        "border": BOLD + C_MAGENTA,
    },
    {
        "name": "Solar Flare",
        "mushroom": C_YELLOW,
        "poison": C_NEON_PINK,
        "centipede_head": BOLD + C_CYAN,
        "centipede_body": C_CYAN,
        "spider": C_NEON_PINK,
        "flea": C_WHITE,
        "scorpion": C_GREEN,
        "border": BOLD + C_YELLOW,
    },
    {
        "name": "Crimson Cavern",
        "mushroom": C_RED,
        "poison": C_CYAN,
        "centipede_head": BOLD + C_WHITE,
        "centipede_body": C_WHITE,
        "spider": C_ORANGE,
        "flea": C_PURPLE,
        "scorpion": C_YELLOW,
        "border": BOLD + C_RED,
    },
    {
        "name": "Cyber Dusk",
        "mushroom": C_PURPLE,
        "poison": C_LIME,
        "centipede_head": BOLD + C_NEON_PINK,
        "centipede_body": C_NEON_PINK,
        "spider": C_LIME,
        "flea": C_CYAN,
        "scorpion": C_WHITE,
        "border": BOLD + C_PURPLE,
    },
]

def get_palette(wave: int) -> dict:
    return PALETTES[(wave - 1) % len(PALETTES)]


# ---------------------------------------------------------------------------
# Non-blocking Keyboard Input Handler
# ---------------------------------------------------------------------------

class InputHandler:
    """Handles cross-platform non-blocking keyboard input with high responsiveness."""
    def __init__(self):
        self.old_term_settings = None
        self._movement_until = {
            "left": 0.0,
            "right": 0.0,
            "up": 0.0,
            "down": 0.0,
        }
        self._escape_sequence = ""
        self._escape_time = 0.0
        self._get_async_key_state = None
        self._command_down = {"pause": False, "mute": False, "quit": False, "restart": False}
        self._command_ready_at = {"pause": 0.0, "mute": 0.0, "quit": 0.0, "restart": 0.0}

        if IS_WINDOWS:
            try:
                self._get_async_key_state = ctypes.windll.user32.GetAsyncKeyState
            except (AttributeError, OSError):
                self._get_async_key_state = None
        else:
            try:
                self.old_term_settings = termios.tcgetattr(sys.stdin)
                tty.setcbreak(sys.stdin.fileno())
            except Exception:
                pass

    def cleanup(self):
        if not IS_WINDOWS and self.old_term_settings:
            try:
                termios.tcsetattr(sys.stdin, termios.TCSADRAIN, self.old_term_settings)
            except Exception:
                pass

    def poll_keys(self) -> dict:
        """Returns a dict of action flags detected in the input buffer."""
        actions = {
            "left": False,
            "right": False,
            "up": False,
            "down": False,
            "fire": False,
            "pause": False,
            "mute": False,
            "quit": False,
            "restart": False,
            "start": False,
        }

        movement_events = {"left": False, "right": False, "up": False, "down": False}

        if IS_WINDOWS:
            while msvcrt.kbhit():
                try:
                    ch = msvcrt.getch()
                except Exception:
                    break
                if ch in (b"\x00", b"\xe0"):
                    try:
                        ch2 = msvcrt.getch()
                    except Exception:
                        break
                    if ch2 == b"K":  # Left Arrow
                        movement_events["left"] = True
                    elif ch2 == b"M":  # Right Arrow
                        movement_events["right"] = True
                    elif ch2 == b"H":  # Up Arrow
                        movement_events["up"] = True
                    elif ch2 == b"P":  # Down Arrow
                        movement_events["down"] = True
                else:
                    c = ch.decode("latin1", errors="ignore").lower()
                    if c == "a":
                        movement_events["left"] = True
                    elif c == "d":
                        movement_events["right"] = True
                    elif c == "w":
                        movement_events["up"] = True
                    elif c == "s":
                        movement_events["down"] = True
                    elif c == " ":
                        actions["fire"] = True
                        actions["start"] = True
                    elif c == "p":
                        actions["pause"] = True
                    elif c == "m":
                        actions["mute"] = True
                    elif c in ("q", "\x1b"):
                        actions["quit"] = True
                    elif c == "r":
                        actions["restart"] = True
                    elif c in ("\r", "\n"):
                        actions["start"] = True
                        actions["fire"] = True
        else:
            while True:
                rlist, _, _ = select.select([sys.stdin.fileno()], [], [], 0)
                if not rlist:
                    break
                try:
                    chunk = os.read(sys.stdin.fileno(), 4096)
                except (OSError, ValueError):
                    break
                if not chunk:
                    break
                for ch in chunk.decode("utf-8", errors="ignore"):
                    if self._escape_sequence:
                        if self._escape_sequence == "\033" and ch == "[":
                            self._escape_sequence = "\033["
                            continue
                        if self._escape_sequence == "\033[":
                            if ch == "D":
                                movement_events["left"] = True
                            elif ch == "C":
                                movement_events["right"] = True
                            elif ch == "A":
                                movement_events["up"] = True
                            elif ch == "B":
                                movement_events["down"] = True
                            self._escape_sequence = ""
                            continue
                        self._escape_sequence = ""
                        actions["quit"] = True
                    if ch == "\033":
                        self._escape_sequence = "\033"
                        self._escape_time = time.perf_counter()
                        continue
                    c = ch.lower()
                    if c == "a":
                        movement_events["left"] = True
                    elif c == "d":
                        movement_events["right"] = True
                    elif c == "w":
                        movement_events["up"] = True
                    elif c == "s":
                        movement_events["down"] = True
                    elif c == " ":
                        actions["fire"] = True
                        actions["start"] = True
                    elif c == "p":
                        actions["pause"] = True
                    elif c == "m":
                        actions["mute"] = True
                    elif c == "q":
                        actions["quit"] = True
                    elif c == "r":
                        actions["restart"] = True
                    elif c in ("\r", "\n"):
                        actions["start"] = True
                        actions["fire"] = True

            if self._escape_sequence and time.perf_counter() - self._escape_time > 0.04:
                if self._escape_sequence == "\033":
                    actions["quit"] = True
                self._escape_sequence = ""

        now = time.perf_counter()
        for direction in ("left", "right", "up", "down"):
            if movement_events[direction]:
                self._movement_until[direction] = now + 0.18
            actions[direction] = now < self._movement_until[direction]

        # Windows physical key polling via GetAsyncKeyState for lag-free diagonal movement
        if self._get_async_key_state is not None:
            try:
                # 0x25: Left, 0x27: Right, 0x26: Up, 0x28: Down
                # 0x41: A, 0x44: D, 0x57: W, 0x53: S, 0x20: Space
                actions["left"] = bool(movement_events["left"] or
                                       self._get_async_key_state(0x41) & 0x8000 or
                                       self._get_async_key_state(0x25) & 0x8000)
                actions["right"] = bool(movement_events["right"] or
                                        self._get_async_key_state(0x44) & 0x8000 or
                                        self._get_async_key_state(0x27) & 0x8000)
                actions["up"] = bool(movement_events["up"] or
                                     self._get_async_key_state(0x57) & 0x8000 or
                                     self._get_async_key_state(0x26) & 0x8000)
                actions["down"] = bool(movement_events["down"] or
                                       self._get_async_key_state(0x53) & 0x8000 or
                                       self._get_async_key_state(0x28) & 0x8000)
                actions["fire"] = bool(actions["fire"] or
                                       self._get_async_key_state(0x20) & 0x8000)
            except (OSError, ValueError):
                self._get_async_key_state = None

        # Debounce toggles
        for command, virtual_keys in (("pause", (0x50,)), ("mute", (0x4D,)),
                                      ("quit", (0x51, 0x1B)), ("restart", (0x52,))):
            event = actions[command]
            if self._get_async_key_state is not None:
                try:
                    down = any(self._get_async_key_state(key) & 0x8000 for key in virtual_keys)
                    actions[command] = bool((down or event) and not self._command_down[command])
                    self._command_down[command] = bool(down)
                    continue
                except (OSError, ValueError):
                    self._get_async_key_state = None
            actions[command] = bool(event and now >= self._command_ready_at[command])
            if actions[command]:
                self._command_ready_at[command] = now + 0.35

        return actions


# ---------------------------------------------------------------------------
# Retro Chiptune Audio Synthesizer (Background Worker)
# ---------------------------------------------------------------------------

class SoundManager:
    """Threaded sound synthesizer producing retro arcade effects."""
    def __init__(self):
        self.enabled = True
        self.queue = queue.Queue(maxsize=12)
        self.running = True
        self.thread = threading.Thread(target=self._worker, daemon=True)
        self.thread.start()

    def _worker(self):
        while self.running:
            try:
                item = self.queue.get(timeout=0.1)
            except queue.Empty:
                continue
            if item is None:
                break
            freq, dur = item
            if self.enabled and IS_WINDOWS:
                try:
                    import winsound
                    winsound.Beep(freq, dur)
                except Exception:
                    pass
            self.queue.task_done()

    def play(self, freq: int, dur: int = 30):
        if not self.enabled or not IS_WINDOWS:
            return
        if not self.queue.full():
            try:
                self.queue.put_nowait((freq, dur))
            except queue.Full:
                pass

    def shoot(self):
        self.play(1100, 20)

    def centipede_head_hit(self):
        self.play(460, 35)

    def centipede_body_hit(self):
        self.play(340, 25)

    def mushroom_hit(self):
        self.play(650, 20)

    def mushroom_destroy(self):
        self.play(820, 25)

    def mushroom_heal(self):
        self.play(740, 25)

    def spider_bounce(self):
        self.play(520, 25)

    def spider_killed(self):
        self.play(260, 50)

    def flea_drop(self):
        self.play(880, 20)

    def flea_killed(self):
        self.play(380, 40)

    def scorpion_scuttle(self):
        self.play(290, 25)

    def scorpion_killed(self):
        self.play(950, 60)

    def player_hit(self):
        self.play(95, 120)

    def extra_life(self):
        for f in (523, 659, 784, 1046):
            self.play(f, 40)

    def wave_clear(self):
        for f in (440, 554, 659, 880):
            self.play(f, 50)

    def toggle(self) -> bool:
        self.enabled = not self.enabled
        return self.enabled

    def stop(self):
        self.running = False
        try:
            self.queue.put_nowait(None)
        except Exception:
            pass


# ---------------------------------------------------------------------------
# High Score Manager
# ---------------------------------------------------------------------------

SCORE_FILE = os.path.join(os.path.dirname(os.path.abspath(__file__)), "highscore.json")

def load_high_score() -> int:
    try:
        if os.path.exists(SCORE_FILE):
            with open(SCORE_FILE, "r", encoding="utf-8") as f:
                data = json.load(f)
                return int(data.get("high_score", 0))
    except Exception:
        pass
    return 0

def save_high_score(score: int):
    try:
        data = {"high_score": score}
        with open(SCORE_FILE, "w", encoding="utf-8") as f:
            json.dump(data, f)
    except Exception:
        pass


# ---------------------------------------------------------------------------
# Game Sprites & Entities
# ---------------------------------------------------------------------------

class Mushroom:
    """A destructible mushroom occupying 1 cell."""
    def __init__(self, x: int, y: int, health: int = 4, poisoned: bool = False):
        self.x = x
        self.y = y
        self.health = health  # 4 down to 1
        self.poisoned = poisoned

    def get_char(self) -> str:
        if self.poisoned:
            return "☣" if self.health > 2 else "x"
        if self.health >= 4:
            return "♠"
        elif self.health == 3:
            return "¥"
        elif self.health == 2:
            return "•"
        else:
            return "·"


class CentipedeSegment:
    """Single segment of a Centipede."""
    def __init__(self, x: int, y: int, is_head: bool = False, dx: int = 1):
        self.x = x
        self.y = y
        self.is_head = is_head
        self.dx = dx  # Direction facing


class Centipede:
    """A connected train of centipede segments."""
    def __init__(self, segments: list, dx: int = 1, vertical_dir: int = 1, speed: float = 10.0):
        self.segments = segments
        self.dx = dx                    # 1: right, -1: left
        self.vertical_dir = vertical_dir  # 1: moving down, -1: moving up (in player area)
        self.speed = speed              # Cells per second
        self.is_plunging = False        # True when heading straight down after touching poisoned mushroom
        self.move_timer = 0.0

    @property
    def head(self) -> CentipedeSegment:
        return self.segments[0] if self.segments else None

    @property
    def is_alive(self) -> bool:
        return len(self.segments) > 0


class Spider:
    """Bounces zig-zag through the player territory and eats mushrooms."""
    def __init__(self, x: int, y: int, dx: int = 1):
        self.x = float(x)
        self.y = float(y)
        self.dx = dx
        self.dy = 1
        self.speed = 12.0
        self.active = True
        self.move_timer = 0.0
        self.sound_step = 0
        self.change_dir_timer = random.uniform(0.5, 1.2)


class Flea:
    """Drops straight down rapidly from the ceiling, seeding mushrooms."""
    def __init__(self, x: int):
        self.x = x
        self.y = 0.0
        self.health = 2
        self.speed = 18.0
        self.active = True
        self.move_timer = 0.0


class Scorpion:
    """Crawls horizontally across the screen, poisoning all mushrooms in its path."""
    def __init__(self, x: int, y: int, dx: int):
        self.x = float(x)
        self.y = y
        self.dx = dx
        self.speed = 11.0
        self.active = True
        self.move_timer = 0.0
        self.sound_step = 0


class Dart:
    """High-speed blaster projectile fired upward by the player."""
    def __init__(self, x: int, y: int):
        self.x = x
        self.y = float(y)
        self.travel = 0.0
        self.speed = 48.0  # Cells per second


class Particle:
    """Explosion / spark particle effect."""
    def __init__(self, x: float, y: float, char: str, color: str, life: int, dx: float, dy: float):
        self.x = float(x)
        self.y = float(y)
        self.char = char
        self.color = color
        self.life = life
        self.dx = dx
        self.dy = dy


class FloatingText:
    """Popup score or event text."""
    def __init__(self, x: int, y: int, text: str, color: str, life: int = 16):
        self.x = x
        self.y = y
        self.text = text
        self.color = color
        self.life = life


# ---------------------------------------------------------------------------
# Centipede Main Game Engine
# ---------------------------------------------------------------------------

class CentipedeGame:
    # Canvas Dimensions (Playfield Inside Borders)
    CANVAS_WIDTH = 54
    CANVAS_HEIGHT = 24
    PLAYER_MIN_Y = 18  # Player restricted to rows 18..23 (Bottom 6 rows)
    PLAYER_MAX_Y = 23

    def __init__(self):
        self.sound_mgr = SoundManager()
        self.input_handler = InputHandler()
        self.high_score = load_high_score()
        self.state = "TITLE"  # TITLE, PLAYING, PAUSED, REGENERATING, WAVE_CLEAR, PLAYER_HIT, GAME_OVER

        # Session Stats
        self.score = 0
        self.lives = 3
        self.wave = 1
        self.new_high_score = False
        self.next_extra_life_score = 12000

        # Player Bug Blaster
        self.player_x = self.CANVAS_WIDTH // 2
        self.player_y = 22
        self.player_invuln_timer = 0.0
        self.player_move_timer = 0.0
        self.dart: Dart = None  # Classic single dart on screen

        # Mushroom Field: (x, y) -> Mushroom
        self.mushrooms: dict = {}

        # Enemies
        self.centipedes: list = []
        self.spider: Spider = None
        self.flea: Flea = None
        self.scorpion: Scorpion = None

        # Timers for Spawning Hazards
        self.spider_spawn_timer = random.uniform(4.0, 8.0)
        self.flea_spawn_timer = random.uniform(8.0, 14.0)
        self.scorpion_spawn_timer = random.uniform(10.0, 18.0)
        self.player_zone_spawn_timer = random.uniform(4.0, 7.0)

        # Visual Effects
        self.particles: list = []
        self.floating_texts: list = []
        self.stars: list = []
        self._init_stars()

        # State Timers
        self.state_timer = 0.0
        self.regen_queue = []  # Mushrooms to heal during death sequence
        self.regen_timer = 0.0

    def _init_stars(self):
        """Ambient subtle starfield background."""
        rng = random.Random(42)
        chars = ["·", "°", "·"]
        for _ in range(30):
            sx = rng.randint(0, self.CANVAS_WIDTH - 1)
            sy = rng.randint(0, self.CANVAS_HEIGHT - 1)
            sch = rng.choice(chars)
            self.stars.append((sx, sy, sch))

    def start_game(self):
        self.score = 0
        self.lives = 3
        self.wave = 1
        self.new_high_score = False
        self.next_extra_life_score = 12000
        self.player_move_timer = 0.0
        self.regen_queue.clear()
        self.regen_timer = 0.0
        self.state_timer = 0.0
        self._init_mushrooms(count=42)
        self.init_wave(self.wave)
        self.state = "PLAYING"

    def _init_mushrooms(self, count: int = 42):
        """Populate initial mushroom field across playfield."""
        self.mushrooms.clear()
        attempts = 0
        while len(self.mushrooms) < count and attempts < 1000:
            attempts += 1
            x = random.randint(1, self.CANVAS_WIDTH - 2)
            y = random.randint(1, self.PLAYER_MAX_Y - 1)
            # Avoid immediate start position of player
            if (x, y) in ((self.CANVAS_WIDTH // 2, 22), (self.CANVAS_WIDTH // 2 - 1, 22), (self.CANVAS_WIDTH // 2 + 1, 22)):
                continue
            if (x, y) not in self.mushrooms:
                self.mushrooms[(x, y)] = Mushroom(x, y, health=4, poisoned=False)

    def init_wave(self, wave: int):
        """Set up wave centipede and reset enemy spawners."""
        self.wave = wave
        self.centipedes.clear()
        self.spider = None
        self.flea = None
        self.scorpion = None
        self.dart = None
        self.particles.clear()
        self.floating_texts.clear()

        # Replenish some mushrooms if field is overly bare
        if len(self.mushrooms) < 30:
            to_add = 35 - len(self.mushrooms)
            for _ in range(to_add):
                x = random.randint(1, self.CANVAS_WIDTH - 2)
                y = random.randint(1, self.PLAYER_MAX_Y - 1)
                if (x, y) not in self.mushrooms:
                    self.mushrooms[(x, y)] = Mushroom(x, y, health=4, poisoned=False)

        # Centipede configuration:
        # Wave 1: 1 train of 12 segments
        # Wave 2+: train of (12 - (wave - 1)) + (wave - 1) independent heads!
        base_speed = 9.0 + (wave - 1) * 1.2
        main_len = max(1, 12 - (wave - 1))
        extra_heads = min(11, wave - 1)

        # Main centipede starts at top-left moving right
        segments = []
        for i in range(main_len):
            is_hd = (i == 0)
            segments.append(CentipedeSegment(x=main_len - 1 - i, y=0, is_head=is_hd, dx=1))
        self.centipedes.append(Centipede(segments, dx=1, vertical_dir=1, speed=base_speed))

        # Extra independent solo heads
        for _ in range(extra_heads):
            hx = random.randint(1, self.CANVAS_WIDTH - 2)
            head_seg = CentipedeSegment(x=hx, y=0, is_head=True, dx=random.choice([-1, 1]))
            solo_cent = Centipede([head_seg], dx=head_seg.dx, vertical_dir=1, speed=base_speed * 1.15)
            self.centipedes.append(solo_cent)

        # Reset player to center bottom with invulnerability
        self.player_x = self.CANVAS_WIDTH // 2
        self.player_y = 22
        self.player_invuln_timer = 2.0

        # Reset hazard timers
        self.spider_spawn_timer = random.uniform(4.0, 8.0)
        self.flea_spawn_timer = random.uniform(8.0, 14.0)
        self.scorpion_spawn_timer = random.uniform(10.0, 18.0)
        self.player_zone_spawn_timer = random.uniform(4.0, 7.0)

    def _add_score(self, pts: int, x: int = None, y: int = None, popup: bool = False):
        self.score += pts
        if self.score > self.high_score:
            self.high_score = self.score
            self.new_high_score = True
            save_high_score(self.high_score)

        if popup and x is not None and y is not None:
            self.floating_texts.append(FloatingText(x, y, f"+{pts}", C_YELLOW, life=16))

        # Bonus Extra Life
        while self.score >= self.next_extra_life_score:
            self.lives += 1
            self.next_extra_life_score += 12000
            self.sound_mgr.extra_life()
            self.floating_texts.append(
                FloatingText(self.player_x - 3, self.player_y - 1, "★ 1-UP! ★", BOLD + C_GREEN, life=28)
            )

    # -----------------------------------------------------------------------
    # Game Loop Updates
    # -----------------------------------------------------------------------

    def update(self, dt: float, actions: dict):
        # Update particles & floating text in all active states
        self._update_particles(dt)
        self._update_floating_texts(dt)

        if actions.get("mute"):
            self.sound_mgr.toggle()

        if self.state == "TITLE":
            if actions.get("start") or actions.get("fire"):
                self.start_game()
            return

        if self.state == "PAUSED":
            if actions.get("pause") or actions.get("start") or actions.get("fire"):
                self.state = "PLAYING"
            elif actions.get("quit"):
                self.state = "TITLE"
            return

        if self.state == "GAME_OVER":
            if actions.get("restart") or actions.get("start") or actions.get("fire"):
                self.start_game()
            elif actions.get("quit"):
                self.state = "TITLE"
            return

        if self.state == "WAVE_CLEAR":
            self.state_timer -= dt
            if self.state_timer <= 0:
                self.init_wave(self.wave + 1)
                self.state = "PLAYING"
            return

        if self.state == "PLAYER_HIT":
            self.state_timer -= dt
            if self.state_timer <= 0:
                if self.lives <= 0:
                    self.state = "GAME_OVER"
                else:
                    self._start_mushroom_regeneration()
            return

        if self.state == "REGENERATING":
            self._update_mushroom_regeneration(dt)
            return

        if self.state == "PLAYING":
            if actions.get("pause"):
                self.state = "PAUSED"
                return
            if actions.get("quit"):
                self.state = "TITLE"
                return
            self._update_playing(dt, actions)

    def _update_playing(self, dt: float, actions: dict):
        if self.player_invuln_timer > 0:
            self.player_invuln_timer = max(0.0, self.player_invuln_timer - dt)

        # 1. Player Movement & Firing
        self._update_player(dt, actions)
        self._check_player_collision()
        if self.state != "PLAYING":
            return

        # 2. Player Dart Projectile
        self._update_dart(dt)

        # 3. Centipede Snaking
        self._update_centipedes(dt)
        if self.state != "PLAYING":
            return

        # 4. Spiders
        self._update_spider(dt)
        if self.state != "PLAYING":
            return

        # 5. Fleas
        self._update_flea(dt)
        if self.state != "PLAYING":
            return

        # 6. Scorpions
        self._update_scorpion(dt)

        # 7. Player Zone Extra Solo Head Spawn Check
        self._update_player_zone_spawns(dt)

        # 8. Check Wave Cleared
        if len(self.centipedes) == 0:
            wave_bonus = 1000 * self.wave
            self._add_score(wave_bonus, self.CANVAS_WIDTH // 2 - 5, 10, popup=True)
            self.sound_mgr.wave_clear()
            self.state = "WAVE_CLEAR"
            self.state_timer = 2.0

    def _update_player(self, dt: float, actions: dict):
        # 4-way / 8-way responsive movement
        dx = 0
        dy = 0
        if actions.get("left"):
            dx -= 1
        if actions.get("right"):
            dx += 1
        if actions.get("up"):
            dy -= 1
        if actions.get("down"):
            dy += 1

        self.player_move_timer += dt
        move_delay = 0.045  # Responsive movement speed
        if (dx != 0 or dy != 0) and self.player_move_timer >= move_delay:
            self.player_move_timer = 0.0
            new_x = self.player_x + dx
            new_y = self.player_y + dy

            # Clamp within player zone
            new_x = max(0, min(self.CANVAS_WIDTH - 1, new_x))
            new_y = max(self.PLAYER_MIN_Y, min(self.PLAYER_MAX_Y, new_y))

            # Disallow walking through mushrooms
            if (new_x, new_y) not in self.mushrooms:
                self.player_x = new_x
                self.player_y = new_y
            elif (new_x, self.player_y) not in self.mushrooms:
                self.player_x = new_x
            elif (self.player_x, new_y) not in self.mushrooms:
                self.player_y = new_y

        # Dart Firing (arcade mechanic: fire dart if none active)
        if actions.get("fire") and self.dart is None:
            self.dart = Dart(self.player_x, self.player_y)
            self.sound_mgr.shoot()

    def _check_player_collision(self):
        """Catch contact when the player moves into an enemy or invulnerability expires."""
        if self.player_invuln_timer > 0 or self.state != "PLAYING":
            return
        pos = (self.player_x, self.player_y)
        if any((seg.x, seg.y) == pos for cent in self.centipedes for seg in cent.segments):
            self._player_killed()
        elif self.spider and self.spider.active and (round(self.spider.x), round(self.spider.y)) == pos:
            self._player_killed()
        elif self.flea and self.flea.active and (self.flea.x, round(self.flea.y)) == pos:
            self._player_killed()

    def _update_dart(self, dt: float):
        if self.dart is None:
            return

        self.dart.travel += dt * self.dart.speed
        steps = int(self.dart.travel)
        if steps <= 0:
            return
        self.dart.travel -= steps

        for _ in range(steps):
            self.dart.y -= 1
            curr_y = int(round(self.dart.y))
            curr_x = self.dart.x

            if curr_y < 0:
                self.dart = None
                return

            # Check Collision: Mushroom
            if (curr_x, curr_y) in self.mushrooms:
                mush = self.mushrooms[(curr_x, curr_y)]
                mush.health -= 1
                if mush.health <= 0:
                    del self.mushrooms[(curr_x, curr_y)]
                    self._add_score(5, curr_x, curr_y)
                    self.sound_mgr.mushroom_destroy()
                    self._spawn_debris(curr_x, curr_y, C_GREEN, count=5)
                else:
                    self._add_score(1)
                    self.sound_mgr.mushroom_hit()
                    self._spawn_debris(curr_x, curr_y, C_GREEN, count=2)
                self.dart = None
                return

            # Check Collision: Centipede
            hit_centipede = False
            for cent in self.centipedes[:]:
                for idx, seg in enumerate(cent.segments):
                    if seg.x == curr_x and seg.y == curr_y:
                        hit_centipede = True
                        self._centipede_hit(cent, idx)
                        self.dart = None
                        return
                if hit_centipede:
                    break

            # Check Collision: Spider
            if self.spider and self.spider.active:
                sp_x = int(round(self.spider.x))
                sp_y = int(round(self.spider.y))
                if sp_x == curr_x and sp_y == curr_y:
                    self._kill_spider()
                    self.dart = None
                    return

            # Check Collision: Flea
            if self.flea and self.flea.active:
                fl_x = self.flea.x
                fl_y = int(round(self.flea.y))
                if fl_x == curr_x and fl_y == curr_y:
                    self._hit_flea()
                    self.dart = None
                    return

            # Check Collision: Scorpion
            if self.scorpion and self.scorpion.active:
                sc_x = int(round(self.scorpion.x))
                sc_y = self.scorpion.y
                if sc_x == curr_x and sc_y == curr_y:
                    self._kill_scorpion()
                    self.dart = None
                    return

    def _centipede_hit(self, cent: Centipede, hit_idx: int):
        hit_seg = cent.segments[hit_idx]
        is_head = hit_seg.is_head

        # Spawn mushroom at hit segment location
        if (hit_seg.x, hit_seg.y) not in self.mushrooms:
            self.mushrooms[(hit_seg.x, hit_seg.y)] = Mushroom(hit_seg.x, hit_seg.y, health=4, poisoned=False)

        pal = get_palette(self.wave)
        if is_head:
            self._add_score(100, hit_seg.x, hit_seg.y, popup=True)
            self.sound_mgr.centipede_head_hit()
            self._spawn_explosion(hit_seg.x, hit_seg.y, pal["centipede_head"], count=8)
        else:
            self._add_score(10, hit_seg.x, hit_seg.y, popup=True)
            self.sound_mgr.centipede_body_hit()
            self._spawn_explosion(hit_seg.x, hit_seg.y, pal["centipede_body"], count=6)

        # Splitting logic
        front = cent.segments[:hit_idx]
        back = cent.segments[hit_idx + 1:]

        if is_head:
            # Removed the head
            if back:
                back[0].is_head = True
                cent.segments = back
            else:
                self.centipedes.remove(cent)
        elif not back:
            # Hit the tail segment
            cent.segments = front
        else:
            # Hit in the middle: splits into two independent centipedes!
            cent.segments = front
            back[0].is_head = True
            new_cent = Centipede(
                segments=back,
                dx=cent.dx,
                vertical_dir=cent.vertical_dir,
                speed=cent.speed * 1.05
            )
            self.centipedes.append(new_cent)

    def _update_centipedes(self, dt: float):
        for cent in self.centipedes[:]:
            if self.state != "PLAYING":
                break
            if not cent.is_alive:
                self.centipedes.remove(cent)
                continue

            cent.move_timer += dt
            step_duration = 1.0 / cent.speed
            while cent.move_timer >= step_duration and self.state == "PLAYING":
                cent.move_timer -= step_duration
                self._step_centipede(cent)

    def _step_centipede(self, cent: Centipede):
        head = cent.head
        if not head:
            return

        old_positions = [(s.x, s.y, s.dx) for s in cent.segments]

        # Determine next head position
        if cent.is_plunging:
            # Poison plunge: drops straight down every step until reaching bottom row
            next_x = head.x
            next_y = head.y + 1
            if next_y >= self.CANVAS_HEIGHT - 1:
                cent.is_plunging = False
                next_y = self.CANVAS_HEIGHT - 1
                cent.vertical_dir = -1  # Rebounds upward inside player area
                cent.dx = random.choice([-1, 1])
        else:
            cand_x = head.x + cent.dx
            cand_y = head.y

            # Check if horizontal step is blocked by boundary or mushroom
            blocked = False
            if cand_x < 0 or cand_x >= self.CANVAS_WIDTH:
                blocked = True
            elif (cand_x, cand_y) in self.mushrooms:
                mush = self.mushrooms[(cand_x, cand_y)]
                if mush.poisoned:
                    cent.is_plunging = True
                blocked = True

            if not blocked:
                next_x = cand_x
                next_y = cand_y
            else:
                # Turn and move vertically
                next_x = head.x
                next_y = head.y + cent.vertical_dir

                # Bounce off bottom of screen
                if next_y >= self.CANVAS_HEIGHT:
                    cent.vertical_dir = -1
                    next_y = self.CANVAS_HEIGHT - 2
                # Bounce off top of player zone while rebounding up
                elif cent.vertical_dir == -1 and next_y < self.PLAYER_MIN_Y:
                    cent.vertical_dir = 1
                    next_y = self.PLAYER_MIN_Y + 1

                # Reverse horizontal direction
                cent.dx = -cent.dx

        # Move head to new position
        head.x = next_x
        head.y = next_y
        head.dx = cent.dx

        # Trail segments follow the one in front
        for i in range(1, len(cent.segments)):
            cent.segments[i].x = old_positions[i - 1][0]
            cent.segments[i].y = old_positions[i - 1][1]
            cent.segments[i].dx = old_positions[i - 1][2]

        # Check Player Collision with Centipede
        if self.player_invuln_timer <= 0:
            for s in cent.segments:
                if s.x == self.player_x and s.y == self.player_y:
                    self._player_killed()
                    return

    def _update_player_zone_spawns(self, dt: float):
        """When centipedes are cycling in player zone, extra solo heads spawn from sides."""
        in_player_zone = any(
            any(s.y >= self.PLAYER_MIN_Y for s in c.segments)
            for c in self.centipedes
        )
        if not in_player_zone:
            return

        self.player_zone_spawn_timer -= dt
        if self.player_zone_spawn_timer <= 0:
            self.player_zone_spawn_timer = random.uniform(5.0, 9.0)
            from_left = random.choice([True, False])
            spawn_x = 0 if from_left else self.CANVAS_WIDTH - 1
            spawn_y = random.randint(self.PLAYER_MIN_Y, self.CANVAS_HEIGHT - 1)
            spawn_dx = 1 if from_left else -1
            solo_head = CentipedeSegment(x=spawn_x, y=spawn_y, is_head=True, dx=spawn_dx)
            solo_cent = Centipede([solo_head], dx=spawn_dx, vertical_dir=1, speed=12.0 + self.wave)
            self.centipedes.append(solo_cent)

    def _update_spider(self, dt: float):
        if self.spider is None or not self.spider.active:
            self.spider_spawn_timer -= dt
            if self.spider_spawn_timer <= 0:
                # Spawn new spider
                from_left = random.choice([True, False])
                sx = 0 if from_left else self.CANVAS_WIDTH - 1
                sy = random.randint(self.PLAYER_MIN_Y, self.CANVAS_HEIGHT - 1)
                sdx = 1 if from_left else -1
                self.spider = Spider(sx, sy, sdx)
                self.spider_spawn_timer = random.uniform(7.0, 14.0)
            return

        sp = self.spider
        sp.move_timer += dt
        sp.change_dir_timer -= dt
        if sp.change_dir_timer <= 0:
            sp.change_dir_timer = random.uniform(0.4, 0.9)
            sp.dy = random.choice([-1, 1])

        step_dur = 1.0 / sp.speed
        if sp.move_timer >= step_dur:
            sp.move_timer -= step_dur
            sp.x += sp.dx
            sp.y += sp.dy

            sp.sound_step += 1
            if sp.sound_step % 4 == 0:
                self.sound_mgr.spider_bounce()

            # Bound vertically within player zone & eat mushrooms
            if sp.y < self.PLAYER_MIN_Y:
                sp.y = self.PLAYER_MIN_Y
                sp.dy = 1
            elif sp.y > self.PLAYER_MAX_Y:
                sp.y = self.PLAYER_MAX_Y
                sp.dy = -1

            # Check off-screen
            if sp.x < 0 or sp.x >= self.CANVAS_WIDTH:
                sp.active = False
                self.spider = None
                return

            # Mushroom eating mechanic
            ix = int(round(sp.x))
            iy = int(round(sp.y))
            if (ix, iy) in self.mushrooms and random.random() < 0.45:
                del self.mushrooms[(ix, iy)]

            # Check player collision
            if self.player_invuln_timer <= 0 and ix == self.player_x and iy == self.player_y:
                self._player_killed()

    def _kill_spider(self):
        if not self.spider:
            return
        sp_x = int(round(self.spider.x))
        sp_y = int(round(self.spider.y))
        dist = abs(sp_y - self.player_y)
        if dist <= 2:
            pts = 900
        elif dist <= 4:
            pts = 600
        else:
            pts = 300

        self._add_score(pts, sp_x, sp_y, popup=True)
        self.sound_mgr.spider_killed()
        pal = get_palette(self.wave)
        self._spawn_explosion(sp_x, sp_y, pal["spider"], count=12)
        self.spider.active = False
        self.spider = None

    def _update_flea(self, dt: float):
        if self.flea is None or not self.flea.active:
            # Flea spawns when player zone is cleared of mushrooms or periodically
            mush_in_player_zone = sum(1 for (mx, my) in self.mushrooms if my >= self.PLAYER_MIN_Y)
            if mush_in_player_zone < 5:
                self.flea_spawn_timer -= dt * 2.5  # Accelerated spawn if barren
            else:
                self.flea_spawn_timer -= dt

            if self.flea_spawn_timer <= 0:
                fx = random.randint(2, self.CANVAS_WIDTH - 3)
                self.flea = Flea(fx)
                self.flea_spawn_timer = random.uniform(9.0, 16.0)
                self.sound_mgr.flea_drop()
            return

        fl = self.flea
        fl.move_timer += dt
        step_dur = 1.0 / fl.speed
        if fl.move_timer >= step_dur:
            fl.move_timer -= step_dur
            fl.y += 1.0

            iy = int(round(fl.y))
            # Seed mushrooms as it drops
            if 0 < iy < self.CANVAS_HEIGHT and random.random() < 0.28:
                if (fl.x, iy) not in self.mushrooms:
                    self.mushrooms[(fl.x, iy)] = Mushroom(fl.x, iy, health=4, poisoned=False)

            # Check player collision
            if self.player_invuln_timer <= 0 and fl.x == self.player_x and iy == self.player_y:
                self._player_killed()
                return

            # Check reached bottom
            if iy >= self.CANVAS_HEIGHT:
                fl.active = False
                self.flea = None

    def _hit_flea(self):
        if not self.flea:
            return
        self.flea.health -= 1
        if self.flea.health <= 0:
            fx = self.flea.x
            fy = int(round(self.flea.y))
            self._add_score(200, fx, fy, popup=True)
            self.sound_mgr.flea_killed()
            pal = get_palette(self.wave)
            self._spawn_explosion(fx, fy, pal["flea"], count=10)
            self.flea.active = False
            self.flea = None
        else:
            # Flea speeds up after first hit
            self.flea.speed *= 1.6
            self.sound_mgr.centipede_body_hit()

    def _update_scorpion(self, dt: float):
        # Scorpions begin appearing in wave 2+
        if self.wave < 2:
            return

        if self.scorpion is None or not self.scorpion.active:
            self.scorpion_spawn_timer -= dt
            if self.scorpion_spawn_timer <= 0:
                from_left = random.choice([True, False])
                sx = 0 if from_left else self.CANVAS_WIDTH - 1
                sy = random.randint(4, 15)
                sdx = 1 if from_left else -1
                self.scorpion = Scorpion(sx, sy, sdx)
                self.scorpion_spawn_timer = random.uniform(12.0, 22.0)
            return

        sc = self.scorpion
        sc.move_timer += dt
        step_dur = 1.0 / sc.speed
        if sc.move_timer >= step_dur:
            sc.move_timer -= step_dur
            sc.x += sc.dx

            sc.sound_step += 1
            if sc.sound_step % 3 == 0:
                self.sound_mgr.scorpion_scuttle()

            ix = int(round(sc.x))
            iy = sc.y

            # Poison any mushroom touched
            if (ix, iy) in self.mushrooms:
                self.mushrooms[(ix, iy)].poisoned = True

            # Check boundary exit
            if sc.x < 0 or sc.x >= self.CANVAS_WIDTH:
                sc.active = False
                self.scorpion = None

    def _kill_scorpion(self):
        if not self.scorpion:
            return
        sc_x = int(round(self.scorpion.x))
        sc_y = self.scorpion.y
        self._add_score(1000, sc_x, sc_y, popup=True)
        self.sound_mgr.scorpion_killed()
        pal = get_palette(self.wave)
        self._spawn_explosion(sc_x, sc_y, pal["scorpion"], count=14)
        self.scorpion.active = False
        self.scorpion = None

    def _player_killed(self):
        if self.state != "PLAYING":
            return
        self.sound_mgr.player_hit()
        self._spawn_explosion(self.player_x, self.player_y, BOLD + C_YELLOW, count=16)
        self._spawn_explosion(self.player_x, self.player_y, BOLD + C_RED, count=12)
        self.dart = None
        self.lives -= 1
        self.state = "PLAYER_HIT"
        self.state_timer = 1.2

    # -----------------------------------------------------------------------
    # Authentic Arcade Mushroom Regeneration Sequence
    # -----------------------------------------------------------------------

    def _start_mushroom_regeneration(self):
        """Prepare list of damaged or poisoned mushrooms to heal sequentially."""
        self.regen_queue = [
            m for m in self.mushrooms.values()
            if m.health < 4 or m.poisoned
        ]
        # Sort top-to-bottom, left-to-right
        self.regen_queue.sort(key=lambda m: (m.y, m.x))
        self.state = "REGENERATING"
        self.regen_timer = 0.05

    def _update_mushroom_regeneration(self, dt: float):
        self.regen_timer -= dt
        if self.regen_timer <= 0:
            self.regen_timer = 0.04
            if self.regen_queue:
                mush = self.regen_queue.pop(0)
                mush.health = 4
                mush.poisoned = False
                self._add_score(10, mush.x, mush.y)
                self.sound_mgr.mushroom_heal()
                self._spawn_debris(mush.x, mush.y, C_YELLOW, count=2)
            else:
                # Finished healing all mushrooms! Respawn player
                self.player_x = self.CANVAS_WIDTH // 2
                self.player_y = 22
                self.player_invuln_timer = 2.0
                self.state = "PLAYING"

    # -----------------------------------------------------------------------
    # Particles and Effects
    # -----------------------------------------------------------------------

    def _spawn_explosion(self, x: float, y: float, color: str, count: int = 8):
        chars = ["*", "+", "×", "#", "·"]
        for _ in range(count):
            c = random.choice(chars)
            life = random.randint(6, 12)
            dx = random.choice([-1.4, -0.7, 0.0, 0.7, 1.4])
            dy = random.choice([-0.8, -0.4, 0.0, 0.4, 0.8])
            self.particles.append(Particle(x, y, c, color, life, dx, dy))

    def _spawn_debris(self, x: float, y: float, color: str, count: int = 3):
        for _ in range(count):
            c = random.choice([".", "·", "°"])
            life = random.randint(4, 8)
            dx = random.choice([-0.6, 0.0, 0.6])
            dy = random.choice([-0.4, 0.4])
            self.particles.append(Particle(x, y, c, color, life, dx, dy))

    def _update_particles(self, dt: float):
        for p in self.particles[:]:
            p.x += p.dx
            p.y += p.dy
            p.life -= 1
            if p.life <= 0 or not (0 <= p.x < self.CANVAS_WIDTH and 0 <= p.y < self.CANVAS_HEIGHT):
                self.particles.remove(p)

    def _update_floating_texts(self, dt: float):
        for ft in self.floating_texts[:]:
            ft.life -= 1
            if ft.life <= 0:
                self.floating_texts.remove(ft)

    # -----------------------------------------------------------------------
    # Flicker-free Double-buffered Frame Rendering
    # -----------------------------------------------------------------------

    def render(self):
        total_w = self.CANVAS_WIDTH + 2
        total_h = self.CANVAS_HEIGHT + 4

        # Query Terminal Size for Centering
        term_cols, term_rows = 80, 28
        try:
            sz = os.get_terminal_size()
            term_cols, term_rows = sz.columns, sz.lines
        except Exception:
            pass

        pad_x = max(0, (term_cols - total_w) // 2)
        pad_y = max(0, (term_rows - total_h) // 2)
        left_pad = " " * pad_x

        chars = [[" " for _ in range(total_w)] for _ in range(total_h)]
        colors = [["" for _ in range(total_w)] for _ in range(total_h)]

        pal = get_palette(self.wave)

        # 1. Top HUD (Row 0)
        score_str = f"SCORE {self.score:05d}"
        high_str = f"HIGH {self.high_score:05d}"
        wave_str = f"WAVE {self.wave}"
        lives_str = f"LIVES {self.lives}"
        sound_str = f"SOUND {'ON' if self.sound_mgr.enabled else 'OFF'}"

        hud_items = [
            (score_str, BOLD + C_YELLOW),
            (high_str, BOLD + (C_GREEN if self.new_high_score else C_WHITE)),
            (wave_str, BOLD + C_CYAN),
            (lives_str, BOLD + C_GREEN),
            (sound_str, DIM + C_WHITE),
        ]
        cursor_x = 2
        for text, col in hud_items:
            for ch in text:
                if cursor_x < total_w - 1:
                    chars[0][cursor_x] = ch
                    colors[0][cursor_x] = col
                    cursor_x += 1
            cursor_x += 2

        # 2. Outer Border (Rows 1 to total_h - 2)
        border_col = pal["border"]
        chars[1][0] = "╔"
        colors[1][0] = border_col
        for x in range(1, total_w - 1):
            chars[1][x] = "═"
            colors[1][x] = border_col
        chars[1][total_w - 1] = "╗"
        colors[1][total_w - 1] = border_col

        for y in range(2, total_h - 2):
            chars[y][0] = "║"
            colors[y][0] = border_col
            chars[y][total_w - 1] = "║"
            colors[y][total_w - 1] = border_col

        b_row = total_h - 2
        chars[b_row][0] = "╚"
        colors[b_row][0] = border_col
        for x in range(1, total_w - 1):
            chars[b_row][x] = "═"
            colors[b_row][x] = border_col
        chars[b_row][total_w - 1] = "╝"
        colors[b_row][total_w - 1] = border_col

        # Bottom Controls HUD (Row total_h - 1)
        ctrl_text = "WASD/ARROWS Move  SPACE Fire  P Pause  M Mute  Q Quit"
        for col_idx, ch in enumerate(ctrl_text[:total_w]):
            chars[total_h - 1][col_idx] = ch
            colors[total_h - 1][col_idx] = C_GRAY

        # 3. Canvas Content (Offset: x + 1, y + 2)
        # Background ambient stars
        for sx, sy, sch in self.stars:
            if 0 <= sx < self.CANVAS_WIDTH and 0 <= sy < self.CANVAS_HEIGHT:
                chars[sy + 2][sx + 1] = sch
                colors[sy + 2][sx + 1] = DIM + C_GRAY

        # Player Zone Boundary Guideline (Dotted line above player area)
        pz_y = self.PLAYER_MIN_Y + 2
        for x in range(1, total_w - 1):
            chars[pz_y][x] = "╌"
            colors[pz_y][x] = DIM + C_GREEN

        # Mushrooms
        for (mx, my), mush in self.mushrooms.items():
            if 0 <= mx < self.CANVAS_WIDTH and 0 <= my < self.CANVAS_HEIGHT:
                chars[my + 2][mx + 1] = mush.get_char()
                colors[my + 2][mx + 1] = pal["poison"] if mush.poisoned else pal["mushroom"]

        # Centipedes
        for cent in self.centipedes:
            for seg in cent.segments:
                if 0 <= seg.x < self.CANVAS_WIDTH and 0 <= seg.y < self.CANVAS_HEIGHT:
                    px = seg.x + 1
                    py = seg.y + 2
                    if seg.is_head:
                        chars[py][px] = "▼" if cent.is_plunging else "◉"
                        colors[py][px] = pal["centipede_head"]
                    else:
                        chars[py][px] = "●"
                        colors[py][px] = pal["centipede_body"]

        # Spider
        if self.spider and self.spider.active:
            sp_x = int(round(self.spider.x))
            sp_y = int(round(self.spider.y))
            if 0 <= sp_x < self.CANVAS_WIDTH and 0 <= sp_y < self.CANVAS_HEIGHT:
                chars[sp_y + 2][sp_x + 1] = "Ж"
                colors[sp_y + 2][sp_x + 1] = BOLD + pal["spider"]

        # Flea
        if self.flea and self.flea.active:
            fl_x = self.flea.x
            fl_y = int(round(self.flea.y))
            if 0 <= fl_x < self.CANVAS_WIDTH and 0 <= fl_y < self.CANVAS_HEIGHT:
                chars[fl_y + 2][fl_x + 1] = "▼"
                colors[fl_y + 2][fl_x + 1] = BOLD + pal["flea"]

        # Scorpion
        if self.scorpion and self.scorpion.active:
            sc_x = int(round(self.scorpion.x))
            sc_y = self.scorpion.y
            if 0 <= sc_x < self.CANVAS_WIDTH and 0 <= sc_y < self.CANVAS_HEIGHT:
                chars[sc_y + 2][sc_x + 1] = "»" if self.scorpion.dx > 0 else "«"
                colors[sc_y + 2][sc_x + 1] = BOLD + pal["scorpion"]

        # Player Dart
        if self.dart:
            dy = int(round(self.dart.y))
            dx = self.dart.x
            if 0 <= dx < self.CANVAS_WIDTH and 0 <= dy < self.CANVAS_HEIGHT:
                chars[dy + 2][dx + 1] = "|"
                colors[dy + 2][dx + 1] = BOLD + C_YELLOW

        # Player Bug Blaster
        if self.state in ("PLAYING", "REGENERATING", "WAVE_CLEAR"):
            # Flash when invulnerable
            show_player = True
            if self.player_invuln_timer > 0:
                show_player = int(self.player_invuln_timer * 10) % 2 == 0

            if show_player and 0 <= self.player_x < self.CANVAS_WIDTH and 0 <= self.player_y < self.CANVAS_HEIGHT:
                chars[self.player_y + 2][self.player_x + 1] = "▲"
                colors[self.player_y + 2][self.player_x + 1] = BOLD + C_WHITE

        # Particles
        for p in self.particles:
            px = int(round(p.x))
            py = int(round(p.y))
            if 0 <= px < self.CANVAS_WIDTH and 0 <= py < self.CANVAS_HEIGHT:
                chars[py + 2][px + 1] = p.char
                colors[py + 2][px + 1] = p.color

        # Floating Scores
        for ft in self.floating_texts:
            fy = ft.y + 2
            if 0 <= fy < total_h - 2:
                for i, ch in enumerate(ft.text):
                    px = ft.x + i + 1
                    if 1 <= px < total_w - 1:
                        chars[fy][px] = ch
                        colors[fy][px] = BOLD + ft.color

        # 4. State Overlays
        if self.state == "TITLE":
            self._render_title_overlay(chars, colors, total_w, total_h)
        elif self.state == "PAUSED":
            self._render_box_overlay(
                chars, colors, total_w, total_h,
                title="[ GAME PAUSED ]",
                lines=[
                    "Press [P] or [SPACE] to Resume",
                    "Press [M] to Toggle Sound",
                    "Press [Q] to Return to Title",
                ],
                border_color=BOLD + C_CYAN
            )
        elif self.state == "WAVE_CLEAR":
            self._render_box_overlay(
                chars, colors, total_w, total_h,
                title=f"[ WAVE {self.wave} COMPLETED! ]",
                lines=[
                    f"Wave Bonus: +{1000 * self.wave} PTS",
                    "Spawning Next Centipede Assault...",
                ],
                border_color=BOLD + C_GREEN
            )
        elif self.state == "REGENERATING":
            remaining = len(self.regen_queue)
            self._render_box_overlay(
                chars, colors, total_w, total_h,
                title="[ MUSHROOM REGENERATION ]",
                lines=[
                    "Healing Mushroom Field...",
                    f"Repaired: +10 PTS each ({remaining} remaining)",
                ],
                border_color=BOLD + C_YELLOW
            )
        elif self.state == "GAME_OVER":
            high_msg = "★ NEW HIGH SCORE! ★" if self.new_high_score else f"High Score: {self.high_score:05d}"
            self._render_box_overlay(
                chars, colors, total_w, total_h,
                title="[ GAME OVER ]",
                lines=[
                    f"Final Score: {self.score:05d}",
                    high_msg,
                    "",
                    "Press [R] or [SPACE] to Play Again",
                    "Press [Q] to Return to Title",
                ],
                border_color=BOLD + C_RED
            )

        # 5. Flush Screen String to STDOUT
        out_lines = []
        if pad_y > 0:
            out_lines.append("\n" * pad_y)

        for y in range(total_h):
            line_parts = [left_pad]
            curr_color = ""
            for x in range(total_w):
                ch = chars[y][x]
                col = colors[y][x]
                if col != curr_color:
                    line_parts.append(col if col else RESET)
                    curr_color = col
                line_parts.append(ch)
            if curr_color:
                line_parts.append(RESET)
            out_lines.append("".join(line_parts))

        frame_data = CURSOR_HOME + "\n".join(out_lines)
        sys.stdout.write(frame_data)
        sys.stdout.flush()

    def _render_box_overlay(self, chars, colors, total_w, total_h, title: str, lines: list, border_color: str):
        box_w = max(len(title) + 4, max((len(l) for l in lines), default=0) + 6, 38)
        box_h = len(lines) + 4
        start_x = (total_w - box_w) // 2
        start_y = (total_h - box_h) // 2

        # Draw box background & border
        for by in range(box_h):
            y = start_y + by
            for bx in range(box_w):
                x = start_x + bx
                if 0 <= y < total_h and 0 <= x < total_w:
                    chars[y][x] = " "
                    colors[y][x] = RESET

        chars[start_y][start_x] = "╔"
        colors[start_y][start_x] = border_color
        for bx in range(1, box_w - 1):
            chars[start_y][start_x + bx] = "═"
            colors[start_y][start_x + bx] = border_color
        chars[start_y][start_x + box_w - 1] = "╗"
        colors[start_y][start_x + box_w - 1] = border_color

        for by in range(1, box_h - 1):
            y = start_y + by
            chars[y][start_x] = "║"
            colors[y][start_x] = border_color
            chars[y][start_x + box_w - 1] = "║"
            colors[y][start_x + box_w - 1] = border_color

        b_bot = start_y + box_h - 1
        chars[b_bot][start_x] = "╚"
        colors[b_bot][start_x] = border_color
        for bx in range(1, box_w - 1):
            chars[b_bot][start_x + bx] = "═"
            colors[b_bot][start_x + bx] = border_color
        chars[b_bot][start_x + box_w - 1] = "╝"
        colors[b_bot][start_x + box_w - 1] = border_color

        # Draw Title
        t_pos = start_x + (box_w - len(title)) // 2
        for i, ch in enumerate(title):
            chars[start_y + 1][t_pos + i] = ch
            colors[start_y + 1][t_pos + i] = border_color

        # Draw lines
        for idx, line in enumerate(lines):
            l_y = start_y + 2 + idx
            l_pos = start_x + (box_w - len(line)) // 2
            for i, ch in enumerate(line):
                chars[l_y][l_pos + i] = ch
                colors[l_y][l_pos + i] = BOLD + C_WHITE

    def _render_title_overlay(self, chars, colors, total_w, total_h):
        title_art = [
            r"  ___ ___ _  _ _____ ___ ___ ___ ___  ___ ",
            r" / __| __| \| |_   _|_ _| _ \ __|   \| __|",
            r"| (__| _|| .` | | |  | ||  _/ _|| |) | _| ",
            r" \___|___|_|\_| |_| |___|_| |___|___/|___|",
            r"             (C) 1980 ATARI               ",
        ]

        start_y = 3
        for r_idx, line in enumerate(title_art):
            y = start_y + r_idx
            start_x = (total_w - len(line)) // 2
            color = BOLD + (C_GREEN if r_idx < 4 else C_YELLOW)
            for c_idx, ch in enumerate(line):
                if 0 <= y < total_h and 0 <= start_x + c_idx < total_w:
                    chars[y][start_x + c_idx] = ch
                    colors[y][start_x + c_idx] = color

        info_lines = [
            ("◉ CENTIPEDE HEAD      - 100 PTS", BOLD + C_YELLOW),
            ("● CENTIPEDE BODY      -  10 PTS", C_YELLOW),
            ("Ж SPIDER (PROXIMITY)  - 300 / 600 / 900 PTS", BOLD + C_WHITE),
            ("▼ FLEA (DROPS MUSH)   - 200 PTS", BOLD + C_CYAN),
            ("» SCORPION (POISONS)  - 1000 PTS", BOLD + C_RED),
            ("♠ MUSHROOM (4 HITS)   - 5 PTS (1 PT/HIT)", C_GREEN),
            ("★ BONUS EXTRA LIFE EVERY 12,000 PTS ★", BOLD + C_GOLD),
            ("", RESET),
            ("CONTROLS:", BOLD + C_CYAN),
            ("Move Bug Blaster:  [WASD] or [ARROW KEYS]", C_WHITE),
            ("Fire Blaster Dart: [SPACEBAR]", C_WHITE),
            ("Pause: [P]   Sound: [M]   Quit: [Q]", C_WHITE),
            ("", RESET),
            ("PRESS [SPACE] OR [ENTER] TO START MISSION", BOLD + C_LIME),
        ]

        curr_y = start_y + len(title_art) + 1
        for text, col in info_lines:
            if curr_y < total_h - 2:
                sx = (total_w - len(text)) // 2
                for i, ch in enumerate(text):
                    if 0 <= sx + i < total_w:
                        chars[curr_y][sx + i] = ch
                        colors[curr_y][sx + i] = col
                curr_y += 1


# ---------------------------------------------------------------------------
# Main Execution Entry Point
# ---------------------------------------------------------------------------

def main():
    # Setup terminal display
    sys.stdout.write(CURSOR_HIDE + CLEAR_SCREEN)
    sys.stdout.flush()

    game = CentipedeGame()
    last_time = time.perf_counter()
    target_fps = 30.0
    frame_time = 1.0 / target_fps

    try:
        while True:
            now = time.perf_counter()
            dt = min(now - last_time, 0.1)
            last_time = now

            actions = game.input_handler.poll_keys()
            if actions.get("quit") and game.state == "TITLE":
                break

            game.update(dt, actions)
            game.render()

            elapsed = time.perf_counter() - now
            sleep_time = frame_time - elapsed
            if sleep_time > 0:
                time.sleep(sleep_time)

    except KeyboardInterrupt:
        pass
    finally:
        game.sound_mgr.stop()
        game.input_handler.cleanup()
        sys.stdout.write(RESET + CURSOR_SHOW + CLEAR_SCREEN)
        sys.stdout.flush()
        print("\nThank you for playing CENTIPEDE!\n")


if __name__ == "__main__":
    main()
