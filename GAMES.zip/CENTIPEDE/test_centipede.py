#!/usr/bin/env python3
"""
Unit and Integration Test Suite for CENTIPEDE Terminal Game
===========================================================
Tests centipede mechanics, segment following, splitting, poisoned plunges,
mushrooms, spider proximity scoring, flea dropping, scorpion poisoning,
mushroom regeneration sequences, extra lives, high scores, and rendering.
"""

import unittest
import os
import tempfile
import json
import io
import re
from unittest.mock import MagicMock, patch

import centipede

# Redirect SCORE_FILE to temporary file for test isolation
_TMP_DIR = tempfile.mkdtemp()
centipede.SCORE_FILE = os.path.join(_TMP_DIR, "test_highscore.json")

from centipede import (
    CentipedeGame,
    Centipede,
    CentipedeSegment,
    Mushroom,
    Spider,
    Flea,
    Scorpion,
    Dart,
    SoundManager,
    InputHandler,
    load_high_score,
    save_high_score,
    get_palette,
)

NO_ACTIONS = {
    "left": False,
    "right": False,
    "up": False,
    "down": False,
    "fire": False,
    "pause": False,
    "mute": False,
    "quit": False,
    "restart": False,
    "start": False,
}


class CentipedeLogicTests(unittest.TestCase):
    def setUp(self):
        self.sound_patcher = patch("centipede.SoundManager")
        self.mock_sound = self.sound_patcher.start()
        self.addCleanup(self.sound_patcher.stop)

        self.game = CentipedeGame()
        self.game.sound_mgr.enabled = False
        self.game.start_game()
        self.game.player_invuln_timer = 0.0

    def test_initial_centipede_setup(self):
        """Wave 1 should spawn 1 centipede of 12 segments."""
        self.game.init_wave(1)
        self.assertEqual(len(self.game.centipedes), 1)
        cent = self.game.centipedes[0]
        self.assertEqual(len(cent.segments), 12)
        self.assertTrue(cent.segments[0].is_head)
        self.assertFalse(cent.segments[1].is_head)

    def test_centipede_horizontal_movement_and_trail(self):
        """Segments should follow the footprint of the segment ahead."""
        seg0 = CentipedeSegment(x=5, y=2, is_head=True, dx=1)
        seg1 = CentipedeSegment(x=4, y=2, is_head=False, dx=1)
        seg2 = CentipedeSegment(x=3, y=2, is_head=False, dx=1)
        cent = Centipede([seg0, seg1, seg2], dx=1, vertical_dir=1, speed=10.0)
        self.game.centipedes = [cent]
        self.game.mushrooms.clear()

        self.game._step_centipede(cent)
        # Head moved from (5,2) to (6,2)
        self.assertEqual((cent.segments[0].x, cent.segments[0].y), (6, 2))
        # Segment 1 took head's old pos (5,2)
        self.assertEqual((cent.segments[1].x, cent.segments[1].y), (5, 2))
        # Segment 2 took segment 1's old pos (4,2)
        self.assertEqual((cent.segments[2].x, cent.segments[2].y), (4, 2))

    def test_centipede_bounces_off_wall_and_drops(self):
        """When reaching right screen edge, centipede drops 1 row and reverses direction."""
        head_x = self.game.CANVAS_WIDTH - 1
        seg0 = CentipedeSegment(x=head_x, y=4, is_head=True, dx=1)
        seg1 = CentipedeSegment(x=head_x - 1, y=4, is_head=False, dx=1)
        cent = Centipede([seg0, seg1], dx=1, vertical_dir=1, speed=10.0)
        self.game.centipedes = [cent]
        self.game.mushrooms.clear()

        self.game._step_centipede(cent)
        # Head dropped to y=5 and reversed direction to dx=-1
        self.assertEqual(cent.segments[0].x, head_x)
        self.assertEqual(cent.segments[0].y, 5)
        self.assertEqual(cent.dx, -1)

    def test_centipede_bounces_off_mushroom(self):
        """Centipede head drops and turns upon encountering a mushroom."""
        seg0 = CentipedeSegment(x=10, y=4, is_head=True, dx=1)
        seg1 = CentipedeSegment(x=9, y=4, is_head=False, dx=1)
        cent = Centipede([seg0, seg1], dx=1, vertical_dir=1, speed=10.0)
        self.game.centipedes = [cent]
        self.game.mushrooms.clear()
        self.game.mushrooms[(11, 4)] = Mushroom(11, 4, health=4)

        self.game._step_centipede(cent)
        self.assertEqual(cent.segments[0].x, 10)
        self.assertEqual(cent.segments[0].y, 5)
        self.assertEqual(cent.dx, -1)

    def test_centipede_bounces_at_bottom_and_reverses_up(self):
        """When centipede hits bottom of canvas, it begins moving upward in player zone."""
        bottom_y = self.game.CANVAS_HEIGHT - 1
        seg0 = CentipedeSegment(x=self.game.CANVAS_WIDTH - 1, y=bottom_y, is_head=True, dx=1)
        cent = Centipede([seg0], dx=1, vertical_dir=1, speed=10.0)
        self.game.centipedes = [cent]
        self.game.mushrooms.clear()

        self.game._step_centipede(cent)
        self.assertEqual(cent.vertical_dir, -1)
        self.assertEqual(cent.segments[0].y, bottom_y - 1)

    def test_centipede_poison_plunge(self):
        """Hitting a poisoned mushroom triggers straight downward plunge until bottom."""
        seg0 = CentipedeSegment(x=10, y=4, is_head=True, dx=1)
        cent = Centipede([seg0], dx=1, vertical_dir=1, speed=10.0)
        self.game.centipedes = [cent]
        self.game.mushrooms.clear()
        self.game.mushrooms[(11, 4)] = Mushroom(11, 4, health=4, poisoned=True)

        self.game._step_centipede(cent)
        self.assertTrue(cent.is_plunging)

        # Subsequent steps plunge straight down vertically
        for expected_y in range(6, self.game.CANVAS_HEIGHT):
            self.game._step_centipede(cent)
            self.assertEqual(cent.segments[0].y, expected_y)

        # Once bottom is reached, plunge ends and centipede moves up
        self.assertFalse(cent.is_plunging)
        self.assertEqual(cent.vertical_dir, -1)

    def test_shooting_centipede_head(self):
        """Shooting head turns it into mushroom, awards 100 pts, promotes next segment."""
        seg0 = CentipedeSegment(x=15, y=5, is_head=True, dx=1)
        seg1 = CentipedeSegment(x=14, y=5, is_head=False, dx=1)
        cent = Centipede([seg0, seg1], dx=1, vertical_dir=1)
        self.game.centipedes = [cent]
        self.game.score = 0

        self.game._centipede_hit(cent, 0)
        self.assertEqual(self.game.score, 100)
        self.assertIn((15, 5), self.game.mushrooms)
        self.assertEqual(len(cent.segments), 1)
        self.assertTrue(cent.segments[0].is_head)
        self.assertEqual(cent.segments[0].x, 14)

    def test_shooting_centipede_middle_splits_into_two(self):
        """Shooting middle segment splits centipede into two independent trains."""
        s0 = CentipedeSegment(x=20, y=6, is_head=True, dx=1)
        s1 = CentipedeSegment(x=19, y=6, is_head=False, dx=1)
        s2 = CentipedeSegment(x=18, y=6, is_head=False, dx=1)
        s3 = CentipedeSegment(x=17, y=6, is_head=False, dx=1)
        s4 = CentipedeSegment(x=16, y=6, is_head=False, dx=1)
        cent = Centipede([s0, s1, s2, s3, s4], dx=1, vertical_dir=1)
        self.game.centipedes = [cent]
        self.game.score = 0

        # Shoot middle segment s2 (index 2)
        self.game._centipede_hit(cent, 2)
        self.assertEqual(self.game.score, 10)
        self.assertIn((18, 6), self.game.mushrooms)

        # Now there must be 2 separate centipedes
        self.assertEqual(len(self.game.centipedes), 2)
        cent_front = self.game.centipedes[0]
        cent_back = self.game.centipedes[1]

        self.assertEqual(len(cent_front.segments), 2)
        self.assertTrue(cent_front.segments[0].is_head)
        self.assertEqual(cent_front.segments[0].x, 20)

        self.assertEqual(len(cent_back.segments), 2)
        self.assertTrue(cent_back.segments[0].is_head)
        self.assertEqual(cent_back.segments[0].x, 17)

    def test_shooting_centipede_tail(self):
        """Shooting tail removes tail, spawns mushroom, awards 10 pts."""
        s0 = CentipedeSegment(x=20, y=6, is_head=True, dx=1)
        s1 = CentipedeSegment(x=19, y=6, is_head=False, dx=1)
        cent = Centipede([s0, s1], dx=1, vertical_dir=1)
        self.game.centipedes = [cent]
        self.game.score = 0

        self.game._centipede_hit(cent, 1)
        self.assertEqual(self.game.score, 10)
        self.assertIn((19, 6), self.game.mushrooms)
        self.assertEqual(len(cent.segments), 1)

    def test_shooting_solo_head_removes_centipede(self):
        """Shooting a 1-segment centipede eliminates it completely."""
        s0 = CentipedeSegment(x=25, y=7, is_head=True, dx=1)
        cent = Centipede([s0], dx=1, vertical_dir=1)
        self.game.centipedes = [cent]

        self.game._centipede_hit(cent, 0)
        self.assertEqual(len(self.game.centipedes), 0)
        self.assertIn((25, 7), self.game.mushrooms)

    def test_mushroom_takes_4_hits_to_destroy(self):
        """Mushroom loses health on dart hit and is removed when health reaches 0."""
        self.game.mushrooms = {(20, 10): Mushroom(20, 10, health=4)}
        self.game.dart = Dart(20, 12)
        self.game.score = 0

        # Hit 1
        self.game._update_dart(0.1)
        self.assertEqual(self.game.mushrooms[(20, 10)].health, 3)
        self.assertEqual(self.game.score, 1)
        self.assertIsNone(self.game.dart)

        # Hit 2
        self.game.dart = Dart(20, 12)
        self.game._update_dart(0.1)
        self.assertEqual(self.game.mushrooms[(20, 10)].health, 2)
        self.assertEqual(self.game.score, 2)

        # Hit 3
        self.game.dart = Dart(20, 12)
        self.game._update_dart(0.1)
        self.assertEqual(self.game.mushrooms[(20, 10)].health, 1)
        self.assertEqual(self.game.score, 3)

        # Hit 4 (destruction)
        self.game.dart = Dart(20, 12)
        self.game._update_dart(0.1)
        self.assertNotIn((20, 10), self.game.mushrooms)
        self.assertEqual(self.game.score, 8)  # 3 + 5 = 8

    def test_spider_proximity_scoring(self):
        """Spider awards 900, 600, or 300 pts depending on player distance."""
        self.game.player_y = 22

        # Close: dist <= 2 -> 900 pts
        self.game.score = 0
        self.game.spider = Spider(10, 21)
        self.game._kill_spider()
        self.assertEqual(self.game.score, 900)

        # Medium: dist <= 4 -> 600 pts
        self.game.score = 0
        self.game.spider = Spider(10, 18)
        self.game._kill_spider()
        self.assertEqual(self.game.score, 600)

        # Distant: dist > 4 -> 300 pts
        self.game.player_y = 23
        self.game.score = 0
        self.game.spider = Spider(10, 18)
        self.game.player_y = 23
        self.game.spider.y = 17
        self.game._kill_spider()
        self.assertEqual(self.game.score, 300)

    def test_flea_takes_two_hits(self):
        """Flea accelerates on hit 1, destroyed on hit 2 for 200 pts."""
        self.game.flea = Flea(25)
        initial_speed = self.game.flea.speed
        self.game.score = 0

        self.game._hit_flea()
        self.assertIsNotNone(self.game.flea)
        self.assertEqual(self.game.flea.health, 1)
        self.assertGreater(self.game.flea.speed, initial_speed)

        self.game._hit_flea()
        self.assertIsNone(self.game.flea)
        self.assertEqual(self.game.score, 200)

    def test_scorpion_poisons_mushrooms_and_gives_1000_pts(self):
        """Scorpion poisons crossed mushrooms and awards 1,000 pts when killed."""
        self.game.wave = 2
        self.game.mushrooms = {(15, 8): Mushroom(15, 8, health=4, poisoned=False)}
        self.game.scorpion = Scorpion(14, 8, dx=1)
        self.game.scorpion.speed = 100.0

        self.game._update_scorpion(0.05)
        self.assertTrue(self.game.mushrooms[(15, 8)].poisoned)

        self.game.score = 0
        self.game._kill_scorpion()
        self.assertEqual(self.game.score, 1000)
        self.assertIsNone(self.game.scorpion)

    def test_player_restricted_to_player_zone(self):
        """Player cannot move above PLAYER_MIN_Y or below PLAYER_MAX_Y."""
        self.game.player_y = self.game.PLAYER_MIN_Y
        self.game.player_x = 20
        self.game.mushrooms.clear()

        # Try to move up past PLAYER_MIN_Y
        actions = dict(NO_ACTIONS, up=True)
        self.game._update_player(0.1, actions)
        self.assertEqual(self.game.player_y, self.game.PLAYER_MIN_Y)

        # Move to bottom
        self.game.player_y = self.game.PLAYER_MAX_Y
        actions = dict(NO_ACTIONS, down=True)
        self.game._update_player(0.1, actions)
        self.assertEqual(self.game.player_y, self.game.PLAYER_MAX_Y)

    def test_mushroom_regeneration_sequence(self):
        """Partially damaged and poisoned mushrooms heal upon player death (+10 pts each)."""
        m1 = Mushroom(10, 5, health=2, poisoned=False)
        m2 = Mushroom(15, 8, health=4, poisoned=True)
        m3 = Mushroom(20, 10, health=4, poisoned=False)  # Healthy mushroom
        self.game.mushrooms = {(10, 5): m1, (15, 8): m2, (20, 10): m3}
        self.game.score = 0

        self.game._start_mushroom_regeneration()
        self.assertEqual(len(self.game.regen_queue), 2)

        # Process first mushroom
        self.game._update_mushroom_regeneration(0.1)
        self.assertEqual(m1.health, 4)
        self.assertEqual(self.game.score, 10)

        # Process second mushroom
        self.game._update_mushroom_regeneration(0.1)
        self.assertEqual(m2.health, 4)
        self.assertFalse(m2.poisoned)
        self.assertEqual(self.game.score, 20)

        # Done regenerating, state returns to PLAYING
        self.game._update_mushroom_regeneration(0.1)
        self.assertEqual(self.game.state, "PLAYING")
        self.assertGreater(self.game.player_invuln_timer, 0.0)

    def test_extra_life_awarded_every_12000_pts(self):
        """Every 12,000 points grants an additional life."""
        initial_lives = self.game.lives
        self.game._add_score(12000)
        self.assertEqual(self.game.lives, initial_lives + 1)
        self.game._add_score(12000)
        self.assertEqual(self.game.lives, initial_lives + 2)

    def test_high_score_persistence(self):
        """High score should persist to and load from JSON file."""
        save_high_score(98765)
        loaded = load_high_score()
        self.assertEqual(loaded, 98765)

    def test_wave_palettes(self):
        """Palettes cycle smoothly across waves."""
        pal1 = get_palette(1)
        pal2 = get_palette(2)
        pal7 = get_palette(7)
        self.assertNotEqual(pal1["name"], pal2["name"])
        self.assertEqual(pal1["name"], pal7["name"])

    def test_dart_hits_spider(self):
        """Dart moving upward hits spider in its path."""
        self.game.mushrooms.clear()
        self.game.centipedes.clear()
        self.game.spider = Spider(20, 18)
        self.game.dart = Dart(20, 20)
        self.game.score = 0
        self.game._update_dart(0.1)
        self.assertIsNone(self.game.dart)
        self.assertIsNone(self.game.spider)
        self.assertGreater(self.game.score, 0)

    def test_dart_hits_flea(self):
        """Dart hits dropping flea, damaging and then killing it."""
        self.game.mushrooms.clear()
        self.game.centipedes.clear()
        self.game.flea = Flea(15)
        self.game.flea.y = 10.0
        self.game.dart = Dart(15, 12)
        self.game.score = 0
        self.game._update_dart(0.1)
        # Flea takes 1 hit, accelerates
        self.assertIsNone(self.game.dart)
        self.assertIsNotNone(self.game.flea)
        self.assertEqual(self.game.flea.health, 1)

        # Second dart kills it
        self.game.dart = Dart(15, 11)
        self.game._update_dart(0.1)
        self.assertIsNone(self.game.flea)
        self.assertEqual(self.game.score, 200)

    def test_dart_hits_scorpion(self):
        """Dart hits crawling scorpion, awarding 1,000 points."""
        self.game.mushrooms.clear()
        self.game.centipedes.clear()
        self.game.wave = 2
        self.game.scorpion = Scorpion(12, 8, dx=1)
        self.game.dart = Dart(12, 10)
        self.game.score = 0
        self.game._update_dart(0.1)
        self.assertIsNone(self.game.dart)
        self.assertIsNone(self.game.scorpion)
        self.assertEqual(self.game.score, 1000)

    def test_player_killed_by_centipede(self):
        """Centipede stepping onto vulnerable player kills them."""
        self.game.player_x = 20
        self.game.player_y = 22
        self.game.player_invuln_timer = 0.0
        self.game.lives = 3
        seg = CentipedeSegment(x=19, y=22, is_head=True, dx=1)
        cent = Centipede([seg], dx=1, vertical_dir=1)
        self.game.centipedes = [cent]

        self.game._step_centipede(cent)
        self.assertEqual(self.game.lives, 2)
        self.assertEqual(self.game.state, "PLAYER_HIT")

    def test_player_killed_by_spider(self):
        """Spider touching player kills them."""
        self.game.player_x = 15
        self.game.player_y = 20
        self.game.player_invuln_timer = 0.0
        self.game.lives = 3
        self.game.spider = Spider(14, 20, dx=1)
        self.game.spider.dy = 0
        self.game.spider.speed = 100.0

        self.game._update_spider(0.05)
        self.assertEqual(self.game.lives, 2)
        self.assertEqual(self.game.state, "PLAYER_HIT")

    def test_player_killed_by_flea(self):
        """Flea falling onto player kills them."""
        self.game.player_x = 18
        self.game.player_y = 21
        self.game.player_invuln_timer = 0.0
        self.game.lives = 3
        self.game.flea = Flea(18)
        self.game.flea.y = 20.0
        self.game.flea.speed = 100.0

        self.game._update_flea(0.05)
        self.assertEqual(self.game.lives, 2)
        self.assertEqual(self.game.state, "PLAYER_HIT")

    def test_game_over_when_zero_lives(self):
        """When player loses last life, state transitions to GAME_OVER."""
        self.game.lives = 1
        self.game._player_killed()
        self.assertEqual(self.game.lives, 0)
        self.assertEqual(self.game.state, "PLAYER_HIT")
        self.game.state_timer = 0.0
        self.game.update(0.1, NO_ACTIONS)
        self.assertEqual(self.game.state, "GAME_OVER")

    def test_pause_resume_toggle(self):
        """Pressing P pauses game, pressing P or space resumes."""
        self.game.state = "PLAYING"
        self.game.update(0.05, dict(NO_ACTIONS, pause=True))
        self.assertEqual(self.game.state, "PAUSED")

        self.game.update(0.05, dict(NO_ACTIONS, pause=True))
        self.assertEqual(self.game.state, "PLAYING")

    def test_wave_clear_transitions_to_next_wave(self):
        """When all centipedes are eliminated, wave bonus is given and wave increments."""
        self.game.wave = 1
        self.game.centipedes.clear()
        self.game.score = 0

        self.game._update_playing(0.05, NO_ACTIONS)
        self.assertEqual(self.game.state, "WAVE_CLEAR")
        self.assertEqual(self.game.score, 1000)

        # Wait out transition timer
        self.game.state_timer = 0.0
        self.game.update(0.1, NO_ACTIONS)
        self.assertEqual(self.game.state, "PLAYING")
        self.assertEqual(self.game.wave, 2)
        self.assertGreater(len(self.game.centipedes), 1)

    def test_player_cannot_walk_into_mushrooms(self):
        """Player movement is blocked by mushrooms in the field."""
        self.game.player_x = 10
        self.game.player_y = 20
        self.game.mushrooms = {(11, 20): Mushroom(11, 20, health=4)}

        # Attempt to walk right into mushroom
        self.game.player_move_timer = 1.0
        self.game._update_player(0.05, dict(NO_ACTIONS, right=True))
        self.assertEqual(self.game.player_x, 10)

    def test_player_moving_into_stationary_centipede_is_hit_once(self):
        self.game.mushrooms.clear()
        self.game.player_x = 10
        self.game.player_y = 20
        self.game.centipedes = [Centipede([CentipedeSegment(11, 20, is_head=True)])]
        self.game.player_move_timer = 0.0
        self.game.update(0.05, dict(NO_ACTIONS, right=True))
        self.assertEqual(self.game.state, "PLAYER_HIT")
        self.assertEqual(self.game.lives, 2)
        self.game._player_killed()
        self.assertEqual(self.game.lives, 2)

    def test_death_does_not_award_wave_clear_bonus(self):
        self.game.mushrooms.clear()
        self.game.centipedes.clear()
        self.game.player_x = 10
        self.game.player_y = 20
        self.game.spider = Spider(11, 20)
        self.game.score = 0
        self.game.update(0.05, dict(NO_ACTIONS, right=True))
        self.assertEqual(self.game.state, "PLAYER_HIT")
        self.assertEqual(self.game.score, 0)

    def test_shot_hits_mushroom_adjacent_to_player(self):
        self.game.mushrooms.clear()
        self.game.player_x = 10
        self.game.player_y = 20
        self.game.mushrooms[(10, 19)] = Mushroom(10, 19)
        self.game._update_player(0.05, dict(NO_ACTIONS, fire=True))
        self.game._update_dart(0.05)
        self.assertEqual(self.game.mushrooms[(10, 19)].health, 3)
        self.assertIsNone(self.game.dart)

    def test_large_score_awards_every_crossed_extra_life(self):
        self.game._add_score(36000)
        self.assertEqual(self.game.lives, 6)
        self.assertEqual(self.game.next_extra_life_score, 48000)

    def test_restart_clears_transient_state(self):
        self.game.player_move_timer = 0.04
        self.game.regen_queue = [Mushroom(1, 1)]
        self.game.regen_timer = 1.0
        self.game.state_timer = 1.0
        self.game.start_game()
        self.assertEqual(self.game.player_move_timer, 0.0)
        self.assertEqual(self.game.regen_queue, [])
        self.assertEqual(self.game.regen_timer, 0.0)
        self.assertEqual(self.game.state_timer, 0.0)

    def test_hud_shows_all_status_at_recommended_width(self):
        output = io.StringIO()
        with patch("centipede.sys.stdout", output), patch(
            "centipede.os.get_terminal_size", return_value=os.terminal_size((80, 28))
        ):
            self.game.render()
        first_row = re.sub(r"\x1b\[[0-9;]*[A-Za-z]", "", output.getvalue()).splitlines()[0]
        for label in ("SCORE", "HIGH", "WAVE", "LIVES", "SOUND"):
            self.assertIn(label, first_row)
        self.assertIn("Q Quit", output.getvalue())

    def test_windows_restart_key_is_debounced(self):
        if not centipede.IS_WINDOWS:
            self.skipTest("Windows input path")
        handler = InputHandler()
        handler._get_async_key_state = lambda key: 0x8000 if key == 0x52 else 0
        with patch("centipede.msvcrt.kbhit", return_value=False):
            self.assertTrue(handler.poll_keys()["restart"])
            self.assertFalse(handler.poll_keys()["restart"])

    def test_fast_centipede_moves_multiple_cells_per_update(self):
        self.game.mushrooms.clear()
        cent = Centipede([CentipedeSegment(5, 2, is_head=True)], speed=40.0)
        self.game.centipedes = [cent]
        self.game._update_centipedes(0.1)
        self.assertEqual(cent.head.x, 9)


if __name__ == "__main__":
    unittest.main()
