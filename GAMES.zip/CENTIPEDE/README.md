# 🐛 CENTIPEDE - Terminal Arcade Edition

A feature-complete, retro-authentic recreation of Atari's legendary 1980 **Centipede** arcade classic, built in Python and played entirely in your terminal with zero external dependencies!

---

## 🕹️ Quick Start

To launch and play the game:

```bash
python main.py
```
*(or `python centipede.py`)*

> **Tip:** For the optimal visual experience, run in an 80-column by 28-line (or larger) terminal window. The game automatically centers itself within your console display.

---

## 🎮 Controls

| Action | Keys | Description |
| :--- | :--- | :--- |
| **Move Bug Blaster** | `W` `A` `S` `D` or `←` `↑` `→` `↓` | 4-way / 8-way movement within restricted player territory |
| **Fire Blaster Dart** | `Spacebar` | Fires high-speed upward dart (rapid repeat allowed) |
| **Pause / Resume** | `P` to pause; `P` or `Spacebar` to resume | Freezes gameplay with retro pause overlay |
| **Mute / Unmute Audio** | `M` | Toggle retro chiptune sound effects |
| **Restart (Game Over)** | `R` or `Spacebar` | Instantly restarts a fresh mission |
| **Quit Game** | `Q` or `Esc` | Exits cleanly to terminal |

---

## 🏆 Scoring & Advance Table

Faithfully tuned to the original 1980 arcade scoring matrix:

| Target | Symbol | Points | Description |
| :--- | :---: | :---: | :--- |
| **Centipede Head** | `◉` / `▼` | **100** | Head segment; turns into a mushroom upon hit |
| **Centipede Body** | `●` | **10** | Body segment; splits centipede and spawns mushroom |
| **Spider (Close)** | `Ж` | **900** | Eliminated within 2 rows of your ship |
| **Spider (Medium)** | `Ж` | **600** | Eliminated within 3 to 4 rows of your ship |
| **Spider (Distant)** | `Ж` | **300** | Eliminated more than 4 rows away |
| **Flea (Drop Bug)** | `▼` | **200** | Takes 2 hits to eliminate; speeds up after hit 1 |
| **Scorpion** | `»` / `«` | **1,000** | Crawls horizontally, poisoning all mushrooms in path |
| **Mushroom (Hit)** | `♠` `¥` `•` `·` | **1** | Each shot that damages a mushroom (takes 4 hits) |
| **Mushroom (Destroyed)** | `·` → 💥 | **5** | Destroying the 4th health stage of a mushroom |
| **Mushroom Regeneration** | `♠` | **10** | Awarded per healed mushroom during post-death tally |
| **Wave Clear Bonus** | — | **+1,000 × Wave** | Awarded upon destroying all centipedes in the wave |
| **Extra Bonus Life** | ★ 1-UP! ★ | **Every 12,000** | Bonus ship awarded at 12,000, 24,000, 36,000... pts |

---

## ✨ Features & Arcade Authenticity

- **100% Flicker-Free ANSI Double-Buffering**:
  Renders the playfield in a single contiguous write pass with cursor home repositioning (`\033[H`), eliminating all terminal stutter and tearing.
- **Authentic Centipede Physics**:
  - The centipede heads toward mushrooms and borders, dropping down 1 row and reversing direction.
  - Body segments accurately follow the exact trail and contour history of the segment in front.
  - Shooting any segment turns it into a mushroom and splits the centipede into two independent trains!
  - When reaching the bottom of the screen, the centipede rebounds and loops inside the player's zone, spawning additional fast solo heads from the side walls!
- **Poison Plunger Physics**:
  - Scorpions crawl across the middle rows, turning mushrooms into poisoned mushrooms (`☣`).
  - When a centipede touches a poisoned mushroom, it plunges straight down vertically to the bottom row!
- **Dynamic Bouncing Spiders**:
  - Spiders bounce in erratic zig-zag paths through the player's territory.
  - Spiders eat (erase) mushrooms they pass over, altering the maze layout.
  - Proximity-based scoring rewards daring close-range shots with **900 points**!
- **Rapid-Drop Fleas**:
  - When mushroom density in the player area is depleted, fleas drop rapidly from the ceiling.
  - Fleas seed new mushrooms behind them as they fall.
  - Takes 2 hits to destroy: fleas accelerate when wounded!
- **Authentic Post-Death Mushroom Regeneration Sequence**:
  - When the player is hit, gameplay pauses for the classic mushroom repair sequence.
  - All partially damaged and poisoned mushrooms heal one by one, playing a satisfying repair chime and awarding **+10 points** each!
- **Retro Color Cycling**:
  - Each wave features its own distinct retro arcade color theme:
    - *Wave 1: Emerald Glade* (Green mushrooms, Yellow centipedes)
    - *Wave 2: Neon Amber* (Cyan mushrooms, Orange centipedes)
    - *Wave 3: Violet Mire* (Magenta mushrooms, Lime centipedes)
    - *Wave 4: Solar Flare* (Yellow mushrooms, Cyan centipedes)
    - *Wave 5: Crimson Cavern* (Red mushrooms, White centipedes)
    - *Wave 6: Cyber Dusk* (Purple mushrooms, Neon Pink centipedes)
- **Multi-Threaded Chiptune Audio**:
  - Background audio worker thread using `winsound` on Windows with zero gameplay delay.
  - Sound effects for blaster darts, centipede splitting, mushroom hits/destruction, mushroom healing, spider warbles, flea whistling, scorpion scuttles, explosions, extra lives, and wave victory fanfares.
  - Instant toggle with `M`.
- **Zero External Dependencies**:
  - Pure Python 3 standard library.
  - Works on Windows (with `GetAsyncKeyState` physical key state support for zero-delay diagonals) and Unix (macOS / Linux terminal raw mode).

---

## 🧪 Testing

A comprehensive automated test suite covers game physics, collisions, hazard interactions, wave progression, and persistence:

```bash
python -m unittest -v test_centipede.py
```
*(37 tests covering gameplay, input, rendering, and persistence)*
