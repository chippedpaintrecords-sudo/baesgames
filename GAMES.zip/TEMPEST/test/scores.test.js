'use strict';

const test = require('node:test');
const assert = require('node:assert/strict');
const fs = require('node:fs');
const os = require('node:os');
const path = require('node:path');
const { loadHighScore, saveHighScore } = require('../src/scores');

test('high scores survive reloads and a lower score cannot replace a better one', t => {
  const directory = fs.mkdtempSync(path.join(os.tmpdir(), 'tempest-scores-'));
  t.after(() => fs.rmSync(directory, { recursive: true, force: true }));
  const file = path.join(directory, 'nested', 'high-score.json');
  assert.equal(loadHighScore(file), 0);
  assert.equal(saveHighScore(10000, file), true);
  assert.equal(loadHighScore(file), 10000);
  assert.equal(saveHighScore(500, file), true);
  assert.equal(loadHighScore(file), 10000);
  assert.equal(saveHighScore(12000, file), true);
  assert.equal(loadHighScore(file), 12000);
  assert.deepEqual(fs.readdirSync(path.dirname(file)), ['high-score.json']);
});

test('invalid score files and write failures do not prevent playing', t => {
  const directory = fs.mkdtempSync(path.join(os.tmpdir(), 'tempest-scores-'));
  t.after(() => fs.rmSync(directory, { recursive: true, force: true }));
  const file = path.join(directory, 'high-score.json');
  for (const value of ['not json', 'null', '{"highScore":-1}', '{"highScore":"9000"}', '{"highScore":1.5}']) {
    fs.writeFileSync(file, value);
    assert.equal(loadHighScore(file), 0);
  }
  assert.equal(saveHighScore(9000, file), true);
  assert.equal(loadHighScore(file), 9000);
  assert.equal(saveHighScore(-10, file), false);
  assert.equal(saveHighScore(500, path.join(file, 'impossible.json')), false);
});
