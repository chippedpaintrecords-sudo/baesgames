'use strict';

const test = require('node:test');
const assert = require('node:assert/strict');
const { WheelInput } = require('../src/mouse');

test('wheel reports move one lane per tick even when stdin splits a report', () => {
  const wheel = new WheelInput();
  assert.deepEqual(wheel.feed('\x1b[<64;10;'), []);
  assert.deepEqual(wheel.feed('5M\x1b[<65;10;5M'), [-1, 1]);
  assert.deepEqual(wheel.feed('\x1b[<68;10;5M\x1b[<81;10;5M'), [-1, 1]);
});

test('mouse clicks, releases, horizontal wheel, and keyboard input do not steer', () => {
  const wheel = new WheelInput();
  assert.deepEqual(wheel.feed('a\x1b[D\x1b[<0;10;5M\x1b[<64;10;5m\x1b[<66;10;5M'), []);
  assert.deepEqual(wheel.feed('\x1b[<64;garbageM\x1b[<64;10;5M'), [-1]);
});
