'use strict';

const test = require('node:test');
const assert = require('node:assert/strict');
const { Game, LANES, ENEMY_POINTS, BONUS_LIFE_SCORE, MAX_LIVES, pulseState } = require('../src/game');
const { render, createRenderer } = require('../src/render');
const { TUBES, tubeForWave, tubeLayoutForWave, laneCountForWave } = require('../src/geometry');

function newGame() {
  const game = new Game(() => 0.5);
  game.start();
  game.spawnRemaining = 0;
  game.spawnTimer = 999;
  return game;
}

test('player movement wraps around the tube', () => {
  const game = newGame();
  game.move(-1);
  assert.equal(game.playerLane, LANES - 1);
  game.move(1);
  assert.equal(game.playerLane, 0);
});

test('the sixteen webs include closed loops and open fifteen-lane shapes', () => {
  assert.equal(TUBES.length, 16);
  assert.equal(tubeForWave(17), 'CIRCLE');
  assert.deepEqual(TUBES.slice(0, 4), ['CIRCLE', 'SQUARE', 'PLUS', 'BOWTIE']);
  assert.equal(tubeForWave(14), 'W');
  assert.equal(tubeForWave(15), 'FAN');
  for (let wave = 1; wave <= 16; wave++) {
    const layout = tubeLayoutForWave(wave);
    assert.equal(layout.rails.length, 16);
    assert.equal(laneCountForWave(wave), layout.open ? 15 : 16);
    assert.ok(layout.rails.every(point => point.length === 2 && point.every(Number.isFinite)));
  }
  assert.deepEqual([8, 9, 10, 11, 12, 14, 15].map(wave => tubeLayoutForWave(wave).open), Array(7).fill(true));
  assert.equal(tubeLayoutForWave(13).open, false);
  assert.equal(tubeLayoutForWave(16).open, false);
  const w = tubeLayoutForWave(14).rails.map(([, y]) => y);
  assert.ok(w.slice(1, 7).some(y => y > 0.6));
  assert.ok(w.slice(7, 9).some(y => y < 0));
  assert.ok(w.slice(9, 15).some(y => y > 0.6));
});

test('open web ends stop movement and enemy pursuit does not wrap', () => {
  const game = newGame();
  game.wave = 8;
  game.playerLane = 0;
  game.move(-1);
  assert.equal(game.playerLane, 0);
  game.playerLane = 14;
  game.move(1);
  assert.equal(game.playerLane, 14);
  const enemy = game.spawnEnemy('flipper', 0, 0.99);
  enemy.onRim = true;
  enemy.rimTimer = 0;
  game.update(0.1);
  assert.equal(enemy.lane, 1);
  const tanker = game.spawnEnemy('tanker', 0, 0.5);
  game.destroyEnemy(tanker);
  assert.deepEqual(game.enemies.filter(item => item.type === 'flipper').map(item => item.lane).sort((a, b) => a - b), [1, 1]);
});

test('entering an open web keeps the player on a valid lane', () => {
  const game = newGame();
  game.wave = 7;
  game.playerLane = 15;
  game.nextWave();
  assert.equal(game.wave, 8);
  assert.equal(game.playerLane, 14);
  game.move(1);
  assert.equal(game.playerLane, 14);
});

test('waves 97 and 98 return to green circle and square, then 99 repeats random webs', () => {
  const game = new Game(() => 0.65);
  game.start();
  game.wave = 96;
  game.nextWave();
  assert.equal(game.wave, 97);
  assert.equal(game.tubeLayout.name, 'CIRCLE');
  game.nextWave();
  assert.equal(game.wave, 98);
  assert.equal(game.tubeLayout.name, 'SQUARE');

  game.playerLane = 15;
  game.nextWave();
  assert.equal(game.wave, 99);
  assert.equal(game.tubeLayout.name, 'FLAT');
  assert.equal(game.laneCount, 15);
  assert.equal(game.playerLane, 14);
  assert.equal(game.spawnEnemy('flipper', 15).lane, 14);
  game.move(1);
  assert.equal(game.playerLane, 14);
  for (const ascii of [false, true]) {
    assert.match(render(game, 80, 26, true, false, { ascii }), /WAVE 99\s+FLAT/);
  }

  game.random = () => 0.1;
  game.nextWave();
  assert.equal(game.wave, 99);
  assert.equal(game.tubeLayout.name, 'SQUARE');
  assert.equal(game.laneCount, 16);
  game.move(1);
  assert.equal(game.playerLane, 15);
  assert.match(render(game, 80, 26, true), /WAVE 99\s+SQUARE/);
});

test('enemy introductions follow the wave progression', () => {
  const cases = [[2, 0.3, 'flipper'], [3, 0.3, 'tanker'], [4, 0.3, 'spiker'], [11, 0.05, 'fuseball'], [16, 0.15, 'spiker'], [17, 0.15, 'spiker'], [20, 0.15, 'pulsar']];
  for (const [wave, roll, expected] of cases) {
    const game = new Game(() => roll);
    game.start();
    game.wave = wave;
    game.spawnRandom();
    assert.equal(game.enemies[0].type, expected, `wave ${wave}`);
  }
});

test('Skill-Step offers the arcade starting waves and previews the selected web', () => {
  const game = new Game(() => 0.5);
  assert.deepEqual(game.availableStartWaves, [1, 3, 5, 7, 9]);
  assert.equal(game.selectStartWave(1), true);
  assert.equal(game.selectedStartWave, 3);
  assert.equal(game.selectedStartBonus, 6000);
  for (const ascii of [false, true]) {
    const screen = screenRows(render(game, 60, 22, true, true, { ascii })).join('\n');
    assert.match(screen, /START WAVE 3\s+PLUS\s+BONUS 6000/);
    assert.match(screen, /WAVE 03\s+PLUS/);
  }
  game.start();
  assert.equal(game.wave, 3);
  assert.equal(game.score, 0);

  game.mode = 'title';
  game.lastGamePeakWave = 82;
  game.selectedStartWave = 81;
  for (const ascii of [false, true]) {
    const rows = screenRows(render(game, 60, 22, true, true, { ascii }));
    assert.ok(rows.every(row => row.length === 60));
    assert.match(rows.join('\n'), /START WAVE 81\s+CIRCLE\s+BONUS 898000/);
  }
});

test('Skill-Step bonus is awarded once when the chosen starting wave is cleared', () => {
  const game = new Game(() => 0.5);
  for (let i = 0; i < 4; i++) game.selectStartWave(1);
  game.start();
  assert.equal(game.wave, 9);
  game.spawnRemaining = 0;
  game.spawnTimer = 999;
  game.update(0.1);
  assert.equal(game.score, 54000 + 9 * 500);
  assert.equal(game.message, 'SKILL BONUS +54000');
  for (let i = 0; i < 26; i++) game.update(0.1);
  assert.equal(game.wave, 10);
  game.spawnRemaining = 0;
  game.spawnTimer = 999;
  game.update(0.1);
  assert.equal(game.score, 54000 + 9 * 500 + 10 * 500);
});

test('later Skill-Step choices depend on the wave reached in the previous game', () => {
  const game = newGame();
  for (let i = 0; i < 11; i++) game.nextWave();
  game.lives = 1;
  game.damagePlayer();
  assert.equal(game.mode, 'gameover');
  assert.deepEqual(game.availableStartWaves, [1, 3, 5, 7, 9, 11]);
  for (let i = 0; i < 5; i++) game.selectStartWave(1);
  assert.equal(game.selectedStartWave, 11);
  game.start();
  assert.equal(game.wave, 11);
  game.lives = 1;
  game.damagePlayer();
  assert.deepEqual(game.availableStartWaves, [1, 3, 5, 7, 9]);

  game.lastGamePeakWave = 20;
  assert.equal(game.availableStartWaves.at(-1), 17);
  game.lastGamePeakWave = 21;
  assert.equal(game.availableStartWaves.at(-1), 20);
  game.lastGamePeakWave = 81;
  assert.equal(game.availableStartWaves.at(-1), 73);
  game.lastGamePeakWave = 82;
  assert.equal(game.availableStartWaves.at(-1), 81);
});

test('shots destroy flippers and award points even across a long frame', () => {
  const game = newGame();
  game.spawnRemaining = 1;
  const enemy = game.spawnEnemy('flipper', game.playerLane, 0.75);
  enemy.speed = 0;
  assert.equal(game.fire(), true);
  game.update(0.1);
  assert.equal(game.enemies.length, 0);
  assert.equal(game.score, ENEMY_POINTS.flipper);
});

test('a shot hits the nearest enemy before an enemy spawned earlier behind it', () => {
  const game = newGame();
  const far = game.spawnEnemy('flipper', 0, 0.82);
  const near = game.spawnEnemy('flipper', 0, 0.9);
  far.speed = near.speed = 0;
  game.fire();
  game.update(0.1);
  assert.deepEqual(game.enemies, [far]);
  assert.equal(game.score, ENEMY_POINTS.flipper);
});

test('shots moving inward cannot hit an enemy already behind the shot', () => {
  const game = newGame();
  const enemy = game.spawnEnemy('flipper', 0, 0.8);
  enemy.speed = 0;
  game.shots.push({ lane: 0, depth: 0.6 });
  game.update(0.1);
  assert.equal(game.enemies.length, 1);
  assert.equal(enemy.hp, 1);
});

test('rapid fire is limited to eight shots and resumes when a shot expires', () => {
  const game = newGame();
  assert.equal(game.fire(), true);
  game.time = 0.06;
  assert.equal(game.fire(), false);
  for (let i = 1; i <= 7; i++) {
    game.time = i * 0.07;
    assert.equal(game.fire(), true);
  }
  game.time = 0.56;
  assert.equal(game.fire(), false);
  assert.equal(game.shots.length, 8);
  game.shots.shift();
  assert.equal(game.fire(), true);
  assert.equal(game.shots.length, 8);
});

test('one shot splits a tanker into adjacent flippers and awards its points', () => {
  const game = newGame();
  const enemy = game.spawnEnemy('tanker', 0, 0.8);
  enemy.speed = 0;
  game.fire();
  game.update(0.1);
  assert.equal(game.score, ENEMY_POINTS.tanker);
  assert.equal(game.enemies.length, 2);
  assert.ok(game.enemies.every(item => item.type === 'flipper'));
});

test('tankers split into adjacent flippers when destroyed', () => {
  const game = newGame();
  const enemy = game.spawnEnemy('tanker', 0, 0.5);
  game.destroyEnemy(enemy);
  assert.deepEqual(game.enemies.map(e => e.lane).sort((a, b) => a - b), [1, LANES - 1]);
  assert.equal(game.score, ENEMY_POINTS.tanker);
});

test('a tanker reaching the rim releases its flippers without awarding a kill', () => {
  const game = newGame();
  const tanker = game.spawnEnemy('tanker', 4, 0.95);
  tanker.speed = 0.2;
  game.update(0.1);
  assert.equal(game.enemies.includes(tanker), false);
  assert.deepEqual(game.enemies.map(enemy => enemy.lane).sort((a, b) => a - b), [3, 5]);
  assert.equal(game.score, 0);
});

test('later waves add fuseball and pulsar tanker cargo', () => {
  for (const [wave, cargoRoll, expected] of [
    [32, 0.1, 'flipper'], [33, 0.1, 'fuseball'], [49, 0.1, 'pulsar'],
    [49, 0.4, 'fuseball'], [49, 0.9, 'flipper']
  ]) {
    const rolls = [0.45, 0.25, cargoRoll];
    const game = new Game(() => rolls.shift() ?? 0.5);
    game.start();
    game.wave = wave;
    game.spawnRandom();
    assert.equal(game.enemies[0].type, 'tanker');
    assert.equal(game.enemies[0].cargoType, expected, `wave ${wave}, roll ${cargoRoll}`);
  }
});

test('shooting or reaching the rim releases a tanker’s cargo into adjacent lanes', () => {
  const shot = newGame();
  shot.wave = 33;
  shot.spawnRemaining = 1;
  shot.spawnEnemy('tanker', 0, 0.8, 'fuseball');
  shot.fire();
  shot.update(0.1);
  assert.equal(shot.score, ENEMY_POINTS.tanker);
  assert.deepEqual(shot.enemies.map(enemy => [enemy.lane, enemy.type]).sort((a, b) => a[0] - b[0]),
    [[1, 'fuseball'], [15, 'fuseball']]);

  const rim = newGame();
  rim.wave = 49;
  const tanker = rim.spawnEnemy('tanker', 4, 0.95, 'pulsar');
  tanker.speed = 0.2;
  rim.update(0.1);
  assert.equal(rim.score, 0);
  assert.deepEqual(rim.enemies.map(enemy => [enemy.lane, enemy.type]), [[3, 'pulsar'], [5, 'pulsar']]);
  assert.ok(rim.enemies.every(enemy => enemy.pulse === 0));
});

test('superzapper destroys loaded tankers without releasing cargo', () => {
  const game = newGame();
  game.spawnEnemy('tanker', 2, 0.5, 'fuseball');
  game.spawnEnemy('tanker', 6, 0.5, 'pulsar');
  game.zap();
  assert.equal(game.enemies.length, 0);
  assert.equal(game.score, ENEMY_POINTS.tanker * 2);
});

test('tanker cargo is recognizable in vector and ASCII graphics', () => {
  const game = newGame();
  game.wave = 49;
  game.spawnEnemy('tanker', 0, 0.7, 'fuseball');
  game.spawnEnemy('tanker', 4, 0.7, 'pulsar');
  const ascii = screenRows(render(game, 100, 32, false, true, { ascii: true })).slice(3, -5).join('');
  assert.match(ascii, /O/);
  assert.match(ascii, /P/);
  const vector = render(game, 100, 32, true, true);
  assert.match(vector, /\x1b\[38;2;106;255;245m/);
  assert.match(vector, /\x1b\[38;2;255;220;75m/);
});

test('first zapper clears the field, second picks one enemy, and both recharge next wave', () => {
  const game = newGame();
  game.spawnEnemy('flipper', 2);
  game.spawnEnemy('pulsar', 5);
  assert.equal(game.zap(), true);
  assert.equal(game.zappers, 1);
  assert.equal(game.enemies.length, 0);
  assert.equal(game.score, ENEMY_POINTS.flipper + ENEMY_POINTS.pulsar);
  game.spawnEnemy('flipper', 2);
  game.spawnEnemy('flipper', 3);
  assert.equal(game.zap(), true);
  assert.equal(game.enemies.length, 1);
  assert.equal(game.zap(), false);
  game.enemies = [];
  for (let i = 0; i < 26; i++) game.update(0.1);
  assert.equal(game.wave, 2);
  assert.equal(game.zappers, 2);
});

test('enemies fire outward along lanes and the zapper leaves their shots', () => {
  const game = newGame();
  game.wave = 4;
  game.spawnRemaining = 1;
  const tanker = game.spawnEnemy('tanker', game.playerLane, 0.5);
  tanker.speed = 0;
  tanker.fireTimer = 0;
  game.update(0.1);
  assert.equal(game.enemyShots.length, 1);
  assert.equal(game.enemyShots[0].lane, game.playerLane);
  game.zap();
  assert.equal(game.enemies.length, 0);
  assert.equal(game.enemyShots.length, 1);
});

test('an enemy shot hits an occupied rim lane but can be dodged', () => {
  const hit = newGame();
  hit.spawnRemaining = 1;
  hit.enemyShots.push({ lane: 0, depth: 0.92, speed: 1 });
  hit.update(0.1);
  assert.equal(hit.lives, 2);
  assert.equal(hit.enemyShots.length, 0);

  const safe = newGame();
  safe.spawnRemaining = 1;
  safe.enemyShots.push({ lane: 0, depth: 0.92, speed: 1 });
  safe.move(1);
  safe.update(0.1);
  assert.equal(safe.lives, 3);
});

test('a hit on the final frame of a wave keeps its message before the clear bonus', () => {
  const game = newGame();
  game.enemyShots.push({ lane: game.playerLane, depth: 0.92, speed: 1 });
  game.update(0.1);
  assert.equal(game.lives, 2);
  assert.equal(game.message, 'HULL HIT!');
  assert.equal(game.score, 0);
  game.update(0.1);
  assert.equal(game.score, 500);
});

test('a player shot intercepts an enemy shot before it reaches the rim', () => {
  const game = newGame();
  game.spawnRemaining = 1;
  game.enemyShots.push({ lane: 0, depth: 0.82, speed: 0.6 });
  game.fire();
  game.update(0.1);
  assert.equal(game.enemyShots.length, 0);
  assert.equal(game.shots.length, 0);
  assert.equal(game.lives, 3);
});

test('an enemy crossing the occupied rim costs one life', () => {
  const game = newGame();
  const enemy = game.spawnEnemy('flipper', game.playerLane, 0.95);
  enemy.speed = 0.2;
  game.update(0.1);
  assert.equal(game.lives, 2);
  assert.equal(game.enemies.length, 0);
});

test('enemies that reach another rim lane keep chasing the player', () => {
  const game = newGame();
  const enemy = game.spawnEnemy('flipper', 3, 0.95);
  enemy.speed = 0.2;
  game.update(0.1);
  assert.equal(game.enemies.length, 1);
  assert.equal(enemy.onRim, true);
  for (let i = 0; i < 5; i++) game.update(0.1);
  assert.equal(enemy.lane, 2);
});

test('invulnerability prevents repeated damage without silently deleting runners', () => {
  const game = newGame();
  const enemy = game.spawnEnemy('flipper', 0, 0.99);
  enemy.onRim = true;
  game.invulnerable = 1;
  game.update(0.1);
  assert.equal(game.lives, 3);
  assert.deepEqual(game.enemies, [enemy]);
  game.invulnerable = 0;
  game.update(0.1);
  assert.equal(game.lives, 2);
  assert.equal(game.enemies.length, 0);
});

test('pulsars warn before damaging their lane and leave other lanes safe', () => {
  const game = newGame();
  const enemy = game.spawnEnemy('pulsar', 0, 0.5);
  enemy.speed = 0;
  enemy.pulse = 1.6;
  assert.equal(pulseState(enemy), 'charging');
  game.update(0.1);
  assert.equal(game.lives, 3);
  enemy.pulse = 2.35;
  game.update(0.05);
  assert.equal(pulseState(enemy), 'active');
  assert.equal(game.lives, 2);
  game.update(0.1);
  assert.equal(game.lives, 2);
  game.move(1);
  game.invulnerable = 0;
  game.update(0.1);
  assert.equal(game.lives, 2);
});

test('pulsars emerging from the core start with a full warning cycle', () => {
  const game = newGame();
  const enemy = game.spawnEnemy('pulsar', 0, 0.34);
  enemy.pulse = 2.4;
  enemy.speed = 0;
  game.update(0.1);
  assert.equal(enemy.pulse, 0);
  enemy.speed = 0.2;
  game.update(0.1);
  assert.equal(pulseState(enemy), 'idle');
  assert.equal(game.lives, 3);
});

test('pulsars ride up and down while advancing and eventually reach the rim', () => {
  const game = newGame();
  game.wave = 20;
  game.playerLane = 8;
  game.spawnRemaining = 1;
  const enemy = game.spawnEnemy('pulsar', 0, 0.5);
  enemy.speed = 0.08;
  let previousDepth = enemy.depth;
  let previousAdvance = enemy.advanceDepth;
  let inwardSteps = 0;
  for (let i = 0; i < 80 && !enemy.onRim; i++) {
    game.update(0.1);
    if (enemy.depth < previousDepth - 0.01) inwardSteps++;
    assert.ok(enemy.advanceDepth >= previousAdvance);
    previousDepth = enemy.depth;
    previousAdvance = enemy.advanceDepth;
  }
  assert.ok(inwardSteps >= 2);
  assert.equal(enemy.onRim, true);
  assert.equal(enemy.depth, 0.99);
});

test('a pulsar keeps charging while its visible position dips toward the core', () => {
  const game = newGame();
  game.wave = 20;
  game.playerLane = 8;
  game.spawnRemaining = 1;
  const enemy = game.spawnEnemy('pulsar', 0, 0.36);
  enemy.speed = 0.05;
  enemy.pulse = 1.6;
  for (let i = 0; i < 8 && enemy.depth >= 0.35; i++) game.update(0.1);
  assert.ok(enemy.depth < 0.35);
  assert.ok(enemy.advanceDepth > 0.35);
  assert.equal(pulseState(enemy), 'charging');
});

test('destroying an active pulsar prevents pulse damage in that frame', () => {
  const game = newGame();
  const enemy = game.spawnEnemy('pulsar', 0, 0.85);
  enemy.speed = 0;
  enemy.pulse = 2.35;
  game.fire();
  game.update(0.1);
  assert.equal(game.enemies.length, 0);
  assert.equal(game.lives, 3);
});

test('wave clear bonus is awarded once and zapper recharges after the warp', () => {
  const game = newGame();
  game.zappers = 0;
  game.update(0.1);
  assert.equal(game.score, 500);
  for (let i = 0; i < 5; i++) game.update(0.1);
  assert.equal(game.score, 500);
  assert.equal(game.wave, 1);
  for (let i = 0; i < 9; i++) game.update(0.1);
  assert.equal(game.wavePhase, 'warp');
  assert.equal(game.wave, 1);
  for (let i = 0; i < 11; i++) game.update(0.1);
  assert.equal(game.wave, 2);
  assert.equal(game.zappers, 2);
  assert.equal(game.score, 500);
});

test('spikers lay persistent spikes, then retreat without becoming runners', () => {
  const game = newGame();
  game.wave = 4;
  const spiker = game.spawnEnemy('spiker', 3, 0.85);
  spiker.speed = 0.2;
  game.update(0.1);
  assert.ok(game.spikes[3] > 0.85);
  assert.equal(spiker.retreating, true);
  assert.equal(spiker.onRim, false);
  for (let i = 0; i < 36; i++) game.update(0.1);
  assert.equal(game.enemies.includes(spiker), false);
  assert.ok(game.spikes[3] > 0.85);
});

test('shots shave the nearest spike tip while the zapper leaves spikes intact', () => {
  const game = newGame();
  game.spawnRemaining = 1;
  game.spikes[0] = 0.8;
  game.fire();
  game.update(0.1);
  assert.ok(game.spikes[0] < 0.8);
  assert.equal(game.score, 2);
  const shaved = game.spikes[0];
  game.zap();
  assert.equal(game.spikes[0], shaved);
});

test('shooting a climbing spiker kills it but leaves its spike', () => {
  const game = newGame();
  game.spawnRemaining = 1;
  const spiker = game.spawnEnemy('spiker', 0, 0.8);
  spiker.speed = 0;
  game.spikes[0] = 0.8;
  game.fire();
  game.update(0.1);
  assert.equal(game.enemies.includes(spiker), false);
  assert.equal(game.spikes[0], 0.8);
  assert.equal(game.score, ENEMY_POINTS.spiker);
});

test('a spike in the warp lane costs one life, while steering clear preserves it', () => {
  const hit = newGame();
  hit.spikes[0] = 0.65;
  hit.clearTimer = 1.4;
  hit.wavePhase = 'warp';
  for (let i = 0; i < 5; i++) hit.update(0.1);
  assert.equal(hit.lives, 2);
  assert.equal(hit.wave, 2);
  assert.equal(hit.message, 'SPIKE HIT!');

  const safe = newGame();
  safe.spikes[0] = 0.65;
  safe.wavePhase = 'warp';
  safe.move(1);
  for (let i = 0; i < 11; i++) safe.update(0.1);
  assert.equal(safe.lives, 3);
  assert.equal(safe.wave, 2);
});

test('a warp shot can shave a spike before the ship reaches it', () => {
  const game = newGame();
  game.spikes[0] = 0.5;
  game.wavePhase = 'warp';
  game.warpDepth = 0.7;
  game.fire();
  game.update(0.1);
  assert.ok(game.spikes[0] < 0.5);
  assert.equal(game.lives, 3);
});

test('spikes and warp warning render in both graphics modes', () => {
  const game = newGame();
  game.wave = 4;
  game.spikes[2] = 0.8;
  game.wavePhase = 'warp';
  game.messageTime = 0;
  const ascii = screenRows(render(game, 80, 26, false, true, { ascii: true })).join('\n');
  assert.match(ascii, /\^/);
  assert.match(ascii, /WARP! DODGE SPIKES!/);
  const vector = render(game, 80, 26, true, true);
  assert.match(vector, /\x1b\[38;2;53;231;116m/);
});

test('incoming enemy shots are visible and warned about in both graphics modes', () => {
  const game = newGame();
  game.messageTime = 0;
  game.enemyShots.push({ lane: 0, depth: 0.82, speed: 0.6 });
  const ascii = screenRows(render(game, 80, 26, false, true, { ascii: true })).join('\n');
  assert.match(ascii, /INCOMING SHOT!/);
  assert.match(ascii, /x/);
  const vector = render(game, 80, 26, true, true);
  assert.match(vector, /\x1b\[38;2;255;95;71m/);
});

test('fuseballs enter the spawn mix in later waves and seek the player', () => {
  const game = new Game(() => 0.05);
  game.start();
  game.wave = 11;
  game.spawnRandom();
  const enemy = game.enemies[0];
  assert.equal(enemy.type, 'fuseball');
  enemy.lane = 3;
  enemy.depth = 0.5;
  game.spawnRemaining = 1;
  for (let i = 0; i < 5; i++) game.update(0.1);
  assert.equal(enemy.lane, 2);
  assert.equal(enemy.onRim, false);
});

test('fuseballs ride rails and can only be shot while crossing a lane', () => {
  const game = newGame();
  game.wave = 11;
  game.spawnRemaining = 1;
  const enemy = game.spawnEnemy('fuseball', 3, 0.5);
  enemy.speed = 0;
  enemy.shiftTimer = 10;
  game.shots.push({ lane: 3, depth: 0.69 });
  game.update(0.1);
  assert.ok(game.enemies.includes(enemy));
  assert.equal(game.score, 0);
  assert.match(screenRows(render(game, 80, 26, false, true, { ascii: true })).slice(3, -5).join(''), /o/);

  enemy.shiftTimer = 0;
  game.shots = [];
  game.update(0.1);
  assert.match(screenRows(render(game, 80, 26, false, true, { ascii: true })).slice(3, -5).join(''), /@/);

  game.shots = [{ lane: 2, depth: 0.69 }];
  game.update(0.1);
  assert.equal(game.enemies.includes(enemy), false);
  assert.equal(game.score, 500);
});

test('a fuseball crossing the wrap seam exposes the adjacent lane', () => {
  const game = newGame();
  game.wave = 17;
  game.spawnRemaining = 1;
  game.playerLane = 15;
  const enemy = game.spawnEnemy('fuseball', 0, 0.5);
  enemy.speed = 0;
  enemy.shiftTimer = 0;
  game.shots.push({ lane: 15, depth: 0.69 });
  game.update(0.1);
  assert.equal(game.enemies.includes(enemy), false);
});

test('fuseballs remain on valid runner lanes at an open web end', () => {
  const game = newGame();
  game.wave = 11;
  game.spawnRemaining = 1;
  game.playerLane = 0;
  const enemy = game.spawnEnemy('fuseball', 14, 0.95);
  enemy.lane = 15;
  enemy.speed = 0.2;
  game.update(0.1);
  assert.equal(enemy.onRim, true);
  assert.equal(enemy.lane, 14);
});

test('ordinary shots cannot destroy a fuseball riding the rim', () => {
  const game = newGame();
  game.wave = 17;
  game.playerLane = 5;
  game.spawnRemaining = 1;
  const enemy = game.spawnEnemy('fuseball', 0, 0.99);
  enemy.onRim = true;
  enemy.rimTimer = 1;
  game.shots.push({ lane: 0, depth: 0.99 });
  game.update(0.1);
  assert.ok(game.enemies.includes(enemy));
  assert.equal(game.score, 0);
  game.zap();
  assert.equal(game.enemies.includes(enemy), false);
  assert.equal(game.score, 750);
});

test('fuseball points increase as it nears the rim', () => {
  for (const [depth, expected] of [[0.3, 250], [0.6, 500], [0.85, 750]]) {
    const game = newGame();
    game.spawnRemaining = 1;
    const enemy = game.spawnEnemy('fuseball', 0, depth);
    game.destroyEnemy(enemy);
    assert.equal(game.score, expected);
  }
});

test('zero or invalid frame times cannot award repeated wave bonuses or corrupt the game', () => {
  const game = newGame();
  const before = JSON.stringify(game);
  for (const dt of [0, -1, NaN, Infinity]) game.update(dt);
  assert.equal(JSON.stringify(game), before);
});

test('bonus lives cross score thresholds once, respect the cap, and preserve the best score', () => {
  const game = new Game(() => 0.5, 12345);
  game.start();
  game.awardPoints(BONUS_LIFE_SCORE - 1);
  assert.equal(game.lives, 3);
  game.awardPoints(1);
  assert.equal(game.lives, 4);
  game.awardPoints(BONUS_LIFE_SCORE * 2);
  assert.equal(game.lives, MAX_LIVES);
  assert.equal(game.highScore, 30000);
  game.damagePlayer();
  game.awardPoints(1);
  assert.equal(game.lives, MAX_LIVES - 1);
  game.start();
  assert.equal(game.score, 0);
  assert.equal(game.highScore, 30001);
  assert.equal(game.nextBonusLife, BONUS_LIFE_SCORE);
});

test('earning a life briefly flashes rainbow rails', () => {
  const game = newGame();
  game.spawnRemaining = 1;
  const normal = screenRows(render(game, 80, 26, false, false, { ascii: true })).slice(3, -5).join('');
  game.awardPoints(BONUS_LIFE_SCORE);
  assert.equal(game.lives, 4);
  assert.ok(game.effects.some(effect => effect.kind === 'bonusLife'));
  const ascii = screenRows(render(game, 80, 26, false, false, { ascii: true })).slice(3, -5).join('');
  assert.ok((ascii.match(/#/g) || []).length > (normal.match(/#/g) || []).length);
  const vector = render(game, 80, 26, true, false);
  assert.match(vector, /\x1b\[38;2;95;246;125m/);
  for (let i = 0; i < 7; i++) game.update(0.1);
  assert.equal(game.effects.some(effect => effect.kind === 'bonusLife'), false);
});

test('pause freezes the entire simulation and resumes normally', () => {
  const game = newGame();
  game.spawnEnemy('pulsar', 0, 0.5);
  game.fire();
  game.togglePause();
  const before = JSON.stringify(game);
  game.move(1);
  assert.equal(game.fire(), false);
  assert.equal(game.zap(), false);
  game.update(0.1);
  assert.equal(JSON.stringify(game), before);
  game.togglePause();
  game.update(0.1);
  assert.equal(game.mode, 'playing');
  assert.ok(game.time > 0);
});

test('terminal renderer highlights the selected lane with and without color', () => {
  const game = newGame();
  const mono = render(game, 80, 24, false);
  const color = render(game, 80, 24, true);
  assert.match(mono, /T E M P E S T/);
  assert.match(mono, /SCORE/);
  assert.match(mono, /ZAPPER FULL/);
  assert.match(mono, /\x1b\[7m/);
  assert.doesNotMatch(mono, /\x1b\[38;2;/);
  assert.match(color, /\x1b\[48;2;56;44;0m/);
});

test('web colors change at sixteen-wave boundaries', () => {
  const game = newGame();
  game.messageTime = 0;
  const blue = render(game, 60, 22, true);
  game.wave = 16;
  assert.match(render(game, 60, 22, true), /\x1b\[38;2;58;212;245m/);
  game.wave = 17;
  const red = render(game, 60, 22, true);
  assert.notEqual(red, blue);
  assert.match(red, /\x1b\[38;2;255;89;105m/);
});

test('ship and enemy colors follow the arcade color eras through wave 97', () => {
  const game = newGame();
  game.messageTime = 0;
  for (const [wave, rim, player, flipper, tanker] of [
    [1, '58;212;245', '255;238;98', '255;92;98', '189;110;255'],
    [17, '255;89;105', '102;246;120', '181;100;245', '80;170;255'],
    [33, '255;207;83', '95;172;255', '112;245;126', '90;225;245'],
    [49, '87;235;232', '95;172;255', '112;245;126', '189;110;255'],
    [65, '18;23;31', '255;238;98', '255;92;98', '189;110;255'],
    [81, '130;236;105', '255;95;103', '255;225;85', '189;110;255'],
    [97, '130;236;105', '255;95;103', '255;225;85', '189;110;255']
  ]) {
    game.wave = wave;
    game.enemies = [];
    game.spawnEnemy('flipper', 4, 0.7);
    game.spawnEnemy('tanker', 8, 0.7);
    const output = render(game, 100, 32, true);
    for (const rgb of [rim, player, flipper, tanker]) {
      assert.ok(output.includes(`\x1b[38;2;${rgb}m`), `wave ${wave} should show ${rgb}`);
    }
    if (wave === 65) assert.match(output, /\x1b\[38;2;199;231;242m\x1b\[48;2;8;15;29m  T E M P E S T/);
  }
});

function screenRows(output) {
  return (output.match(/\x1b\[\d+;1H[\s\S]*?(?=\x1b\[\d+;1H|$)/g) || [])
    .map(row => row.replace(/\x1b\[[0-9;?]*[A-Za-z]/g, ''));
}

test('HUD, ship, and all controls fit at the minimum terminal size on every tube', () => {
  const game = newGame();
  for (let wave = 1; wave <= TUBES.length; wave++) {
    game.wave = wave;
    game.messageTime = 0;
    assert.equal(tubeForWave(wave), TUBES[wave - 1]);
    for (let lane = 0; lane < laneCountForWave(wave); lane++) {
      game.playerLane = lane;
      for (const ascii of [false, true]) {
        const rows = screenRows(render(game, 60, 22, false, true, { ascii }));
        assert.equal(rows.length, 22);
        assert.ok(rows.every(row => row.length === 60));
        assert.match(rows[0], /SCORE 000000/);
        assert.match(rows[0], /BEST 000000/);
        assert.match(rows[1], /ZAPPER FULL/);
        if (ascii) {
          assert.ok(rows.slice(3, 18).some(row => row.includes('A')), `${TUBES[wave - 1]} lane ${lane} ASCII ship visible`);
          assert.ok(rows.every(row => /^[\x20-\x7e]*$/.test(row)));
        } else {
          // Compare with the invisible phase of the protection blink to
          // detect a ship even though the vector mode has no letter A.
          game.invulnerable = 1;
          game.time = 0.1;
          const hidden = screenRows(render(game, 60, 22, false, true));
          game.invulnerable = 0;
          game.time = 0;
          assert.ok(rows.slice(3, 18).some((row, index) => row !== hidden[index + 3]), `${TUBES[wave - 1]} lane ${lane} vector ship visible`);
        }
        assert.match(rows[20], /ARROWS \/ A D: MOVE.*SPACE: FIRE.*Z: ZAP/);
        assert.match(rows[21], /F: AUTO FIRE.*G: GRAPHICS.*P: PAUSE.*Q \/ ESC: QUIT/);
      }
    }
  }
  assert.equal(tubeForWave(17), TUBES[0]);
});

test('pulse warnings remain visible in monochrome and resize redraws the screen', () => {
  const game = newGame();
  const enemy = game.spawnEnemy('pulsar', 0, 0.6);
  enemy.pulse = 1.7;
  let screen = render(game, 60, 22, false);
  assert.match(screen, /LANE CHARGING!/);
  assert.match(screen, /[\u2801-\u28ff]/);
  assert.match(render(game, 60, 22, false, false, { ascii: true }), /~/);
  enemy.pulse = 2.4;
  screen = render(game, 60, 22, false);
  assert.match(screen, /PULSE! MOVE!/);
  const draw = createRenderer();
  assert.match(draw(game, 60, 22, false), /\x1b\[2J/);
  assert.equal(draw(game, 60, 22, false), '');
  game.score = 50;
  const changed = screenRows(draw(game, 60, 22, false));
  assert.equal(changed.length, 1);
  assert.match(changed[0], /SCORE 000050/);
  assert.match(draw(game, 80, 24, false), /\x1b\[2J/);
  assert.match(draw(game, 80, 24, false, false, { ascii: true }), /\x1b\[2J/);
  assert.equal(draw(game, 80, 24, false, false, { ascii: true }), '');
  assert.match(draw(game, 40, 15, false), /Resize to at least 60 x 22/);
});

test('a pulsar opens a rim gap and flashes its bordering rails', () => {
  const game = newGame();
  game.wave = 17; // circle keeps the tested rim segment away from corners
  game.playerLane = 8;
  const enemy = game.spawnEnemy('pulsar', 0, 0.5);
  const arena = () => screenRows(render(game, 80, 26, false, false, { ascii: true })).slice(3, -5);
  const idle = arena();
  enemy.pulse = 1.7;
  const charging = arena();
  const rimPart = rows => rows[1].slice(37, 44);
  assert.ok((rimPart(charging).match(/#/g) || []).length < (rimPart(idle).match(/#/g) || []).length);
  enemy.pulse = 2.4;
  const active = arena();
  assert.match(active.join(''), /!/);
  assert.match(active.join(''), /\+/);
});

test('vector sprites, trails, bursts, and zap waves render without mutating the simulation', () => {
  const game = newGame();
  game.wave = 4;
  game.messageTime = 0;
  game.spawnEnemy('flipper', 3, 0.8);
  game.spawnEnemy('tanker', 7, 0.7);
  game.spawnEnemy('pulsar', 11, 0.6).pulse = 2.4;
  game.fire();
  const before = JSON.stringify(game);
  const playing = render(game, 100, 32, true, true);
  assert.match(playing, /[\u2801-\u28ff]/);
  assert.equal(JSON.stringify(game), before);
  game.zap();
  game.update(0.1);
  const burst = render(game, 100, 32, true, true);
  assert.notEqual(burst, playing);
  game.togglePause();
  const paused = render(game, 100, 32, true, true);
  for (let i = 0; i < 5; i++) game.update(0.1);
  assert.equal(render(game, 100, 32, true, true), paused);
});

test('title, pause, and game over panels fit in both graphics modes', () => {
  const game = newGame();
  for (const mode of ['title', 'paused', 'gameover']) {
    game.mode = mode;
    for (const ascii of [false, true]) {
      const rows = screenRows(render(game, 60, 22, true, true, { ascii }));
      assert.equal(rows.length, 22);
      assert.ok(rows.every(row => row.length === 60));
      const screen = rows.join('\n');
      assert.match(screen, mode === 'title' ? /ENTER.*[Ss][Tt][Aa][Rr][Tt]/ : mode === 'paused' ? /PAUSED/ : /GAME OVER/);
    }
  }
});
