@echo off
setlocal
pushd "%~dp0"
node .\src\index.js
if errorlevel 1 pause
popd
endlocal
