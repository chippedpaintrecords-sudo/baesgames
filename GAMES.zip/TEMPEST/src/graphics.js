'use strict';

const BACKGROUND = [3, 7, 18];
const TEXT = [199, 231, 242];
const DOTS = [[1, 8], [2, 16], [4, 32], [64, 128]];
const FONT = {
  T: ['11111', '00100', '00100', '00100', '00100'],
  E: ['11111', '10000', '11110', '10000', '11111'],
  M: ['10001', '11011', '10101', '10001', '10001'],
  P: ['11110', '10001', '11110', '10000', '10000'],
  S: ['11111', '10000', '11111', '00001', '11111']
};

class Canvas {
  constructor(width, height, color, ascii = false) {
    this.width = width;
    this.height = height;
    this.color = color;
    this.ascii = ascii;
    this.cells = Array.from({ length: height }, () =>
      Array.from({ length: width }, () => this.empty()));
  }

  empty(bg = BACKGROUND) {
    return { char: ' ', ink: TEXT, bg, highlight: false, dots: 0, priority: -1 };
  }

  put(x, y, char, ink = TEXT) {
    x = Math.round(x);
    y = Math.round(y);
    if (x < 0 || x >= this.width || y < 0 || y >= this.height) return;
    const { bg, highlight } = this.cells[y][x];
    this.cells[y][x] = { ...this.empty(bg), char, ink, highlight };
  }

  shade(x, y, bg) {
    if (x < 0 || x >= this.width || y < 0 || y >= this.height) return;
    this.cells[y][x].bg = bg;
    this.cells[y][x].highlight = true;
  }

  fillRect(left, top, width, height, bg) {
    for (let y = Math.max(0, Math.round(top)); y < Math.min(this.height, Math.round(top + height)); y++) {
      for (let x = Math.max(0, Math.round(left)); x < Math.min(this.width, Math.round(left + width)); x++) {
        this.cells[y][x] = this.empty(bg);
      }
    }
  }

  shadePolygon(points, bg) {
    const top = Math.max(0, Math.ceil(Math.min(...points.map(p => p[1]))));
    const bottom = Math.min(this.height - 1, Math.floor(Math.max(...points.map(p => p[1]))));
    for (let y = top; y <= bottom; y++) {
      const intersections = [];
      for (let i = 0; i < points.length; i++) {
        const a = points[i];
        const b = points[(i + 1) % points.length];
        if ((a[1] > y) !== (b[1] > y)) {
          intersections.push(a[0] + (y - a[1]) / (b[1] - a[1]) * (b[0] - a[0]));
        }
      }
      intersections.sort((a, b) => a - b);
      for (let i = 0; i + 1 < intersections.length; i += 2) {
        for (let x = Math.max(0, Math.ceil(intersections[i])); x <= Math.min(this.width - 1, Math.floor(intersections[i + 1])); x++) {
          this.shade(x, y, bg);
        }
      }
    }
  }

  text(x, y, value, ink = TEXT) {
    for (let i = 0; i < value.length; i++) this.put(x + i, y, value[i], ink);
  }

  centered(y, value, ink = TEXT) {
    if (value.length > this.width) value = value.slice(0, this.width);
    this.text(Math.floor((this.width - value.length) / 2), y, value, ink);
  }

  line(x1, y1, x2, y2, char, ink) {
    const count = Math.ceil(Math.max(Math.abs(x2 - x1), Math.abs(y2 - y1)) * 2);
    for (let i = 0; i <= count; i++) {
      const t = count ? i / count : 0;
      this.put(x1 + (x2 - x1) * t, y1 + (y2 - y1) * t, char, ink);
    }
  }

  // Each braille character is a 2 by 4 pixel tile. Brighter sprites take
  // priority over the wireframe so a ship cannot merge into a grid line.
  pixel(px, py, ink, priority = 1, glow = false) {
    px = Math.round(px);
    py = Math.round(py);
    if (px < 0 || px >= this.width * 2 || py < 0 || py >= this.height * 4) return;
    const cell = this.cells[Math.floor(py / 4)][Math.floor(px / 2)];
    if (priority < cell.priority && cell.priority >= 5) return;
    if (priority >= 5 && cell.priority < priority) cell.dots = 0;
    cell.dots |= DOTS[py % 4][px % 2];
    cell.char = String.fromCharCode(0x2800 + cell.dots);
    if (priority >= cell.priority) {
      cell.ink = ink;
      cell.priority = priority;
    }
    if (glow && this.color) {
      cell.bg = cell.bg.map((value, i) => Math.max(value, Math.round(ink[i] * 0.13)));
    }
  }

  dot(x, y, ink, priority = 1, glow = false) {
    this.pixel(x * 2 + 0.5, y * 4 + 1.5, ink, priority, glow);
  }

  stroke(a, b, ink, priority = 1, glow = false, char = '.') {
    if (this.ascii) return this.line(...a, ...b, char, ink);
    const x1 = Math.round(a[0] * 2 + 0.5);
    const y1 = Math.round(a[1] * 4 + 1.5);
    const x2 = Math.round(b[0] * 2 + 0.5);
    const y2 = Math.round(b[1] * 4 + 1.5);
    const count = Math.max(Math.abs(x2 - x1), Math.abs(y2 - y1));
    for (let i = 0; i <= count; i++) {
      const t = count ? i / count : 0;
      this.pixel(x1 + (x2 - x1) * t, y1 + (y2 - y1) * t, ink, priority, glow);
    }
  }

  path(points, ink, priority = 1, glow = false) {
    for (let i = 0; i < points.length - 1; i++) this.stroke(points[i], points[i + 1], ink, priority, glow);
  }

  logo(x, y, value, ink) {
    for (let i = 0; i < value.length; i++) {
      const glyph = FONT[value[i]];
      if (!glyph) continue;
      glyph.forEach((row, gy) => {
        for (let gx = 0; gx < row.length; gx++) {
          if (row[gx] !== '1') continue;
          for (let dy = 0; dy < 2; dy++) {
            for (let dx = 0; dx < 2; dx++) {
              this.pixel(x * 2 + i * 12 + gx * 2 + dx, y * 4 + gy * 2 + dy, ink, 9, true);
            }
          }
        }
      });
    }
  }

  output() {
    let out = '';
    for (let y = 0; y < this.cells.length; y++) {
      let currentInk = '';
      let currentBg = '';
      let reverse = false;
      out += `\x1b[${y + 1};1H\x1b[0m`;
      for (const cell of this.cells[y]) {
        if (this.color) {
          const ink = cell.ink.join(';');
          if (ink !== currentInk) {
            out += `\x1b[38;2;${ink}m`;
            currentInk = ink;
          }
          const bg = cell.bg.join(';');
          if (bg !== currentBg) {
            out += `\x1b[48;2;${bg}m`;
            currentBg = bg;
          }
        } else if (cell.highlight !== reverse) {
          out += cell.highlight ? '\x1b[7m' : '\x1b[27m';
          reverse = cell.highlight;
        }
        out += cell.char;
      }
      out += '\x1b[K';
    }
    return out + '\x1b[0m';
  }
}

module.exports = { Canvas };
