'use strict';

const { tubeLayoutForWave } = require('./geometry');

const LANES = 16;
const SHOT_SPEED = 1.75;
const FIRE_INTERVAL = 0.065;
const MAX_PLAYER_SHOTS = 8;
const ENEMY_POINTS = { flipper: 150, tanker: 100, pulsar: 200, spiker: 50, fuseball: 250 };
const BONUS_LIFE_SCORE = 10000;
const MAX_LIVES = 5;
const HIT_RADIUS = 0.065;
const MAX_ENEMY_SHOTS = 4;
const FUSEBALL_JUMP_TIME = 0.24;
const PULSAR_BOB_AMPLITUDE = 0.075;
const PULSAR_BOB_RATE = Math.PI * 2 * 1.3;
// Arcade Skill-Step starting waves and the previous-game wave needed to offer each one.
const START_WAVES = [1, 3, 5, 7, 9, 11, 13, 15, 17, 20, 22, 24, 26, 28,
  31, 33, 36, 40, 44, 47, 49, 52, 56, 60, 63, 65, 73, 81];
const START_UNLOCK_WAVES = [0, 0, 0, 0, 0, 12, 14, 16, 18, 21, 23, 25, 27, 29,
  32, 34, 37, 41, 45, 48, 50, 53, 57, 61, 64, 66, 74, 82];
const START_BONUSES = [0, 6000, 16000, 32000, 54000, 74000, 94000, 114000,
  134000, 152000, 170000, 188000, 208000, 226000, 248000, 266000,
  300000, 340000, 382000, 415000, 439000, 472000, 531000, 581000,
  624000, 656000, 766000, 898000];

function pulseState(enemy) {
  if (enemy.type !== 'pulsar' || enemy.onRim || (enemy.advanceDepth ?? enemy.depth) < 0.35) return 'idle';
  const phase = enemy.pulse % 3;
  if (phase >= 2.35 && phase < 2.75) return 'active';
  if (phase >= 1.55 && phase < 2.35) return 'charging';
  return 'idle';
}

class Game {
  constructor(random = Math.random, highScore = 0) {
    this.random = random;
    this.highScore = Number.isSafeInteger(highScore) && highScore >= 0 ? highScore : 0;
    this.lastGamePeakWave = 0;
    this.reset();
  }

  get availableStartWaves() {
    return START_WAVES.filter((_, index) => this.lastGamePeakWave >= START_UNLOCK_WAVES[index]);
  }

  get selectedStartBonus() {
    return START_BONUSES[START_WAVES.indexOf(this.selectedStartWave)] || 0;
  }

  get startingWaveBonus() {
    return START_BONUSES[START_WAVES.indexOf(this.startingWave)] || 0;
  }

  get laneCount() {
    return this.tubeLayout.open ? LANES - 1 : LANES;
  }

  get openTube() {
    return this.tubeLayout.open;
  }

  get tubeLayout() {
    return this.wave === 99 && this.randomWeb !== null
      ? tubeLayoutForWave(this.randomWeb + 1) : tubeLayoutForWave(this.wave);
  }

  normalizeLane(lane) {
    return this.openTube ? Math.max(0, Math.min(this.laneCount - 1, lane))
      : ((lane % this.laneCount) + this.laneCount) % this.laneCount;
  }

  neighborLane(lane, direction) {
    const next = lane + direction;
    return this.openTube && (next < 0 || next >= this.laneCount) ? null : this.normalizeLane(next);
  }

  directionTowardPlayer(lane) {
    if (lane === this.playerLane) return 0;
    if (this.openTube) return Math.sign(this.playerLane - lane);
    const clockwise = (this.playerLane - lane + this.laneCount) % this.laneCount;
    const counterclockwise = (lane - this.playerLane + this.laneCount) % this.laneCount;
    return clockwise <= counterclockwise ? 1 : -1;
  }

  reset() {
    this.mode = 'title';
    this.score = 0;
    this.nextBonusLife = BONUS_LIFE_SCORE;
    this.lives = 3;
    this.wave = 0;
    this.randomWeb = null;
    this.currentPeakWave = 0;
    this.startingWave = 1;
    this.selectedStartWave = 1;
    this.startBonusAwarded = false;
    this.playerLane = 0;
    this.enemies = [];
    this.shots = [];
    this.enemyShots = [];
    this.effects = [];
    this.time = 0;
    this.lastShot = -1;
    this.invulnerable = 0;
    this.zappers = 0;
    this.message = '';
    this.messageTime = 0;
    this.nextId = 1;
    this.spawnRemaining = 0;
    this.waveTotal = 0;
    this.spawnTimer = 0;
    this.clearTimer = 0;
    this.wavePhase = 'combat';
    this.warpDepth = 1.05;
    this.spikes = Array(LANES).fill(0);
  }

  start() {
    const selected = this.availableStartWaves.includes(this.selectedStartWave) ? this.selectedStartWave : 1;
    this.reset();
    this.mode = 'playing';
    this.startingWave = selected;
    this.wave = selected - 1;
    this.nextWave();
  }

  selectStartWave(direction) {
    if (this.mode !== 'title' && this.mode !== 'gameover') return false;
    const choices = this.availableStartWaves;
    const current = choices.indexOf(this.selectedStartWave);
    const next = (current + Math.sign(direction) + choices.length) % choices.length;
    if (!direction || next === current) return false;
    this.selectedStartWave = choices[next];
    return true;
  }

  nextWave() {
    this.wave = Math.min(99, this.wave + 1);
    this.randomWeb = this.wave === 99
      ? Math.max(0, Math.min(LANES - 1, Math.floor(this.random() * LANES))) : null;
    this.currentPeakWave = Math.max(this.currentPeakWave, this.wave);
    this.playerLane = this.normalizeLane(this.playerLane);
    this.zappers = 2;
    this.spawnRemaining = 5 + this.wave * 2;
    this.waveTotal = this.spawnRemaining;
    this.spawnTimer = 0.8;
    this.clearTimer = 0;
    this.wavePhase = 'combat';
    this.warpDepth = 1.05;
    this.spikes = Array(LANES).fill(0);
    this.shots = [];
    this.enemyShots = [];
    this.effects = [];
    this.message = `WAVE ${this.wave}`;
    this.messageTime = 1.5;
  }

  move(direction) {
    if (this.mode !== 'playing') return;
    this.playerLane = this.normalizeLane(this.playerLane + direction);
  }

  togglePause() {
    if (this.mode === 'playing') this.mode = 'paused';
    else if (this.mode === 'paused') this.mode = 'playing';
  }

  awardPoints(points) {
    this.score += points;
    this.highScore = Math.max(this.highScore, this.score);
    while (this.score >= this.nextBonusLife) {
      this.nextBonusLife += BONUS_LIFE_SCORE;
      if (this.lives < MAX_LIVES) {
        this.lives++;
        this.effects.push({ kind: 'bonusLife', time: 0.65, duration: 0.65 });
        this.message = 'BONUS LIFE!';
        this.messageTime = 1.5;
      }
    }
  }

  fire() {
    if (this.mode !== 'playing' || this.time - this.lastShot < FIRE_INTERVAL ||
        this.shots.length >= MAX_PLAYER_SHOTS) return false;
    this.lastShot = this.time;
    this.shots.push({ lane: this.playerLane, depth: this.wavePhase === 'warp' ? this.warpDepth : 0.99 });
    return true;
  }

  zap() {
    if (this.mode !== 'playing' || this.zappers === 0) return false;
    const fullBlast = this.zappers === 2;
    this.zappers--;
    let points = 0;
    const victims = fullBlast ? [...this.enemies] : this.enemies.length ? [this.enemies[Math.floor(this.random() * this.enemies.length)]] : [];
    for (const enemy of victims) {
      points += this.pointsForEnemy(enemy);
      this.effects.push({ lane: this.effectLane(enemy), depth: enemy.depth, time: 0.35, duration: 0.35, char: '*' });
    }
    const victimIds = new Set(victims.map(enemy => enemy.id));
    this.enemies = this.enemies.filter(enemy => !victimIds.has(enemy.id));
    this.effects.push({ kind: 'zapWave', time: 0.45, duration: 0.45 });
    this.message = fullBlast ? 'SUPER ZAPPER!' : 'ZAPPER SHOT!';
    this.messageTime = 0.9;
    this.awardPoints(points);
    return true;
  }

  spawnEnemy(type, lane, depth = 0.16, cargoType = 'flipper') {
    const enemy = {
      id: this.nextId++,
      type,
      cargoType: type === 'tanker' ? cargoType : null,
      lane: this.normalizeLane(lane),
      depth,
      advanceDepth: type === 'pulsar' ? depth : null,
      bobTime: 0,
      speed: (0.085 + Math.min(this.wave, 16) * 0.011) * (type === 'tanker' ? 0.7 : type === 'pulsar' ? 0.83 : type === 'spiker' ? 0.8 : type === 'fuseball' ? 1.2 : 1),
      hp: 1,
      shiftTimer: type === 'fuseball' ? 0.18 + this.random() * 0.1 : 0.48 + this.random() * 0.5,
      jump: null,
      fireTimer: 1.1 + this.random() * 1.4,
      pulse: 0,
      onRim: false,
      rimTimer: 0
    };
    this.enemies.push(enemy);
    return enemy;
  }

  spawnRandom() {
    const roll = this.random();
    const type = this.wave >= 11 && roll < 0.1 ? 'fuseball'
      : this.wave >= 20 && roll < 0.22 ? 'pulsar'
        : this.wave >= 4 && roll < 0.38 ? 'spiker'
          : this.wave >= 3 && roll < 0.53 ? 'tanker' : 'flipper';
    const lane = Math.floor(this.random() * this.laneCount);
    let cargoType = 'flipper';
    if (type === 'tanker' && this.wave >= 33) {
      const cargoRoll = this.random();
      cargoType = this.wave >= 49 && cargoRoll < 0.25 ? 'pulsar'
        : cargoRoll < 0.6 ? 'fuseball' : 'flipper';
    }
    this.spawnEnemy(type, lane, 0.16, cargoType);
  }

  damagePlayer() {
    if (this.invulnerable > 0 || this.mode !== 'playing') return false;
    this.lives--;
    this.invulnerable = 1.5;
    this.effects.push({ lane: this.playerLane, depth: 1.03, time: 0.6, duration: 0.6, char: 'X' });
    this.message = this.lives ? 'HULL HIT!' : 'GAME OVER';
    this.messageTime = 1.2;
    if (this.lives <= 0) this.mode = 'gameover';
    if (this.mode === 'gameover') {
      this.lastGamePeakWave = this.currentPeakWave;
      this.selectedStartWave = 1;
    }
    return true;
  }

  pointsForEnemy(enemy) {
    return enemy.type === 'fuseball' ? (enemy.depth >= 0.75 ? 750 : enemy.depth >= 0.45 ? 500 : 250) : ENEMY_POINTS[enemy.type];
  }

  effectLane(enemy) {
    if (enemy.type !== 'fuseball' || enemy.onRim) return enemy.lane;
    const rail = enemy.jump
      ? enemy.jump.from + (enemy.jump.to - enemy.jump.from) * enemy.jump.progress
      : enemy.lane;
    return rail - 0.5;
  }

  destroyEnemy(enemy) {
    if (!this.enemies.includes(enemy)) return;
    this.awardPoints(this.pointsForEnemy(enemy));
    this.effects.push({ lane: this.effectLane(enemy), depth: enemy.depth, time: 0.28, duration: 0.28, char: '*' });
    this.enemies = this.enemies.filter(e => e.id !== enemy.id);
    if (enemy.type === 'tanker') this.releaseTanker(enemy, enemy.depth);
  }

  releaseTanker(enemy, depth) {
    for (const direction of [-1, 1]) {
      const lane = this.neighborLane(enemy.lane, direction);
      if (lane === null) continue;
      this.waveTotal++;
      this.spawnEnemy(enemy.cargoType || 'flipper', lane, depth);
    }
  }

  update(dt) {
    if (this.mode !== 'playing' || !Number.isFinite(dt) || dt <= 0) return;
    dt = Math.min(dt, 0.1);
    const livesBefore = this.lives;
    this.time += dt;
    this.invulnerable = Math.max(0, this.invulnerable - dt);
    this.messageTime = Math.max(0, this.messageTime - dt);
    this.effects.forEach(effect => { effect.time -= dt; });
    this.effects = this.effects.filter(effect => effect.time > 0);

    if (this.spawnRemaining > 0) {
      this.spawnTimer -= dt;
      if (this.spawnTimer <= 0) {
        this.spawnRandom();
        this.spawnRemaining--;
        this.spawnTimer = Math.max(0.32, 1.08 - this.wave * 0.045) * (0.7 + this.random() * 0.6);
      }
    }

    for (const shot of this.shots) {
      shot.previousDepth = shot.depth;
      shot.depth -= SHOT_SPEED * dt;
    }
    for (const shot of this.enemyShots) {
      shot.previousDepth = shot.depth;
      shot.depth += shot.speed * dt;
    }

    for (const enemy of [...this.enemies]) {
      enemy.previousDepth = enemy.depth;
      enemy.completedJump = null;
      if (enemy.onRim) {
        enemy.rimTimer -= dt;
        if (enemy.rimTimer <= 0) {
          enemy.lane = this.normalizeLane(enemy.lane + this.directionTowardPlayer(enemy.lane));
          enemy.rimTimer = enemy.type === 'fuseball' ? 0.18 : Math.max(0.2, 0.55 - this.wave * 0.015);
        }
      } else {
        if (enemy.type === 'pulsar') {
          enemy.advanceDepth += enemy.speed * dt;
          if (enemy.speed > 0) enemy.bobTime += dt;
          enemy.depth = Math.max(0.12, Math.min(0.94,
            enemy.advanceDepth + PULSAR_BOB_AMPLITUDE * Math.sin(enemy.bobTime * PULSAR_BOB_RATE)));
        } else {
          enemy.depth += enemy.speed * dt * (enemy.retreating ? -1 : 1);
        }
        if (enemy.type === 'spiker') {
          if (!enemy.retreating) this.spikes[enemy.lane] = Math.max(this.spikes[enemy.lane], enemy.depth);
          if (enemy.depth >= 0.86) enemy.retreating = true;
          if (enemy.retreating && enemy.depth <= 0.16) {
            this.enemies = this.enemies.filter(e => e.id !== enemy.id);
            continue;
          }
        }
        if (this.wave > 1 && enemy.type === 'flipper' && enemy.depth > 0.45) {
          enemy.shiftTimer -= dt;
          if (enemy.shiftTimer <= 0) {
            const direction = this.random() < 0.5 ? -1 : 1;
            enemy.lane = this.neighborLane(enemy.lane, direction) ?? this.neighborLane(enemy.lane, -direction);
            enemy.shiftTimer = 0.42 + this.random() * 0.48;
          }
        }
        if (enemy.type === 'fuseball' && enemy.depth > 0.35) {
          let jumpStep = dt;
          if (!enemy.jump) {
            enemy.shiftTimer -= dt;
            if (enemy.shiftTimer <= 0) {
              // Fuseballs rest on a rail. Only the crossing between rails
              // exposes them to shots travelling down a lane.
              const target = this.playerLane + 0.5;
              let direction;
              if (this.openTube) direction = Math.sign(target - enemy.lane);
              else {
                const clockwise = (target - enemy.lane + this.laneCount) % this.laneCount;
                direction = clockwise <= this.laneCount / 2 ? 1 : -1;
              }
              const next = enemy.lane + direction;
              if (!this.openTube || (next >= 0 && next <= this.laneCount)) {
                enemy.jump = { from: enemy.lane, to: next, progress: 0, previousProgress: 0 };
              }
              jumpStep = -enemy.shiftTimer;
              enemy.shiftTimer = Math.max(0.14, 0.32 - this.wave * 0.006) + this.random() * 0.08;
            }
          }
          if (enemy.jump) {
            enemy.jump.previousProgress = enemy.jump.progress;
            enemy.jump.progress = Math.min(1, enemy.jump.progress + jumpStep / FUSEBALL_JUMP_TIME);
            if (enemy.jump.progress >= 1) {
              enemy.lane = this.openTube ? enemy.jump.to : this.normalizeLane(enemy.jump.to);
              enemy.completedJump = enemy.jump;
              enemy.jump = null;
            }
          }
        }
        if (enemy.type !== 'spiker' && (enemy.type === 'pulsar' ? enemy.advanceDepth >= 0.96 : enemy.depth >= 0.96)) {
          if (enemy.type === 'tanker') {
            this.enemies = this.enemies.filter(item => item.id !== enemy.id);
            this.releaseTanker(enemy, 0.94);
            continue;
          }
          enemy.depth = 0.99;
          enemy.onRim = true;
          if (enemy.type === 'fuseball') {
            const rail = enemy.jump
              ? enemy.jump.from + (enemy.jump.to - enemy.jump.from) * enemy.jump.progress
              : enemy.lane;
            enemy.lane = this.normalizeLane(Math.floor(rail));
          }
          enemy.jump = null;
          enemy.rimTimer = enemy.type === 'fuseball' ? 0.18 : 0.4;
        }
      }
      if (enemy.type === 'pulsar') {
        enemy.pulse = enemy.advanceDepth >= 0.35 ? enemy.pulse + dt : 0;
      }

      if (this.wave > 1 && !enemy.onRim && enemy.type !== 'fuseball' &&
          enemy.depth > 0.38 && enemy.depth < 0.94) {
        enemy.fireTimer -= dt;
        if (enemy.fireTimer <= 0) {
          if (this.enemyShots.length < MAX_ENEMY_SHOTS &&
              (enemy.lane === this.playerLane || this.random() < 0.3)) {
            this.enemyShots.push({ lane: enemy.lane, depth: enemy.depth + 0.04,
              speed: 0.48 + Math.min(this.wave, 24) * 0.012 });
          }
          enemy.fireTimer = Math.max(0.9, 2.6 - this.wave * 0.035) + this.random() * 0.8;
        }
      }

    }

    for (const shot of [...this.shots]) {
      let target = null;
      let firstContact = Infinity;
      for (const enemy of this.enemies) {
        const startGap = shot.previousDepth - (enemy.previousDepth ?? enemy.depth);
        const endGap = shot.depth - enemy.depth;
        if (startGap < -HIT_RADIUS || endGap > HIT_RADIUS) continue;
        const closingSpeed = startGap - endGap;
        const contact = closingSpeed > 0 ? Math.max(0, (startGap - HIT_RADIUS) / closingSpeed) : 0;
        if (enemy.type === 'fuseball') {
          if (enemy.onRim) continue;
          const jump = enemy.jump || enemy.completedJump;
          if (!jump) continue;
          const progress = jump.previousProgress + (jump.progress - jump.previousProgress) * contact;
          if (progress < 0.2 || progress > 0.8) continue;
          const crossingLane = jump.to > jump.from ? jump.from : jump.to;
          if (this.normalizeLane(crossingLane) !== shot.lane) continue;
        } else if (enemy.lane !== shot.lane) continue;
        if (contact < firstContact) {
          target = enemy;
          firstContact = contact;
        }
      }
      for (const enemyShot of this.enemyShots) {
        if (enemyShot.lane !== shot.lane) continue;
        const startGap = shot.previousDepth - (enemyShot.previousDepth ?? enemyShot.depth);
        const endGap = shot.depth - enemyShot.depth;
        if (startGap < -HIT_RADIUS || endGap > HIT_RADIUS) continue;
        const closingSpeed = startGap - endGap;
        const contact = closingSpeed > 0 ? Math.max(0, (startGap - HIT_RADIUS) / closingSpeed) : 0;
        if (contact < firstContact) {
          target = enemyShot;
          firstContact = contact;
        }
      }
      const spike = this.spikes[shot.lane];
      if (spike > 0.13 && !(target?.type === 'spiker' && !target.retreating && Math.abs(target.depth - spike) < HIT_RADIUS * 2)) {
        const startGap = shot.previousDepth - spike;
        const endGap = shot.depth - spike;
        if (startGap >= -HIT_RADIUS && endGap <= HIT_RADIUS) {
          const closingSpeed = startGap - endGap;
          const contact = closingSpeed > 0 ? Math.max(0, (startGap - HIT_RADIUS) / closingSpeed) : 0;
          if (contact < firstContact) target = 'spike';
        }
      }
      if (!target) continue;
      this.shots = this.shots.filter(s => s !== shot);
      if (target === 'spike') {
        this.spikes[shot.lane] = Math.max(0, spike - 0.12);
        this.awardPoints(2);
        this.effects.push({ lane: shot.lane, depth: spike, time: 0.16, duration: 0.16, char: '+' });
        continue;
      }
      if (this.enemyShots.includes(target)) {
        this.enemyShots = this.enemyShots.filter(enemyShot => enemyShot !== target);
        this.effects.push({ lane: target.lane, depth: target.depth, time: 0.16, duration: 0.16, char: '+' });
        continue;
      }
      target.hp--;
      if (target.hp <= 0) this.destroyEnemy(target);
      else this.effects.push({ lane: target.lane, depth: target.depth, time: 0.18, duration: 0.18, char: '+' });
    }
    this.shots = this.shots.filter(shot => shot.depth > 0.12);
    for (const enemyShot of [...this.enemyShots]) {
      if (enemyShot.depth < 0.98) continue;
      this.enemyShots = this.enemyShots.filter(shot => shot !== enemyShot);
      if (enemyShot.lane === this.playerLane && this.wavePhase !== 'warp') this.damagePlayer();
    }

    if (this.wavePhase === 'warp') {
      this.warpDepth = Math.max(0.08, this.warpDepth - dt * 0.95);
      const spike = this.spikes[this.playerLane];
      if (spike > 0.13 && this.warpDepth <= spike) {
        const hit = this.damagePlayer();
        if (this.mode === 'playing') {
          this.nextWave();
          if (hit) {
            this.message = 'SPIKE HIT!';
            this.messageTime = 1.2;
            this.effects.push({ lane: this.playerLane, depth: 1.03, time: 0.6, duration: 0.6, char: 'X' });
          }
        }
        return;
      }
      if (this.warpDepth <= 0.08) this.nextWave();
      return;
    }

    for (const enemy of [...this.enemies]) {
      if (!enemy.onRim || enemy.lane !== this.playerLane) continue;
      if (this.damagePlayer()) this.enemies = this.enemies.filter(e => e.id !== enemy.id);
    }
    if (this.enemies.some(enemy => enemy.lane === this.playerLane && pulseState(enemy) === 'active')) {
      this.damagePlayer();
    }
    if (this.mode !== 'playing' || this.lives < livesBefore) return;

    if (this.spawnRemaining === 0 && this.enemies.length === 0) {
      if (this.clearTimer === 0) {
        const bonus = this.wave * 500;
        const startBonus = this.wave === this.startingWave && !this.startBonusAwarded ? this.startingWaveBonus : 0;
        if (startBonus) this.startBonusAwarded = true;
        this.awardPoints(bonus + startBonus);
        this.message = startBonus ? `SKILL BONUS +${startBonus}` : `WAVE CLEAR +${bonus}`;
        this.messageTime = 1.4;
      }
      this.clearTimer += dt;
      if (this.clearTimer >= 1.4) {
        this.wavePhase = 'warp';
        this.warpDepth = 1.05;
        this.enemyShots = [];
        this.message = 'AVOID SPIKES!';
        this.messageTime = 0.9;
      }
    } else {
      this.clearTimer = 0;
    }
  }
}

module.exports = { Game, LANES, ENEMY_POINTS, BONUS_LIFE_SCORE, MAX_LIVES, pulseState };
