'use strict';

const TAU = Math.PI * 2;
const RAILS = 16;

function radial(name, radius) {
  return {
    name,
    open: false,
    rails: Array.from({ length: RAILS }, (_, index) => {
      const angle = -Math.PI / 2 + index * TAU / RAILS;
      const distance = radius(angle, index);
      return [Math.cos(angle) * distance, Math.sin(angle) * distance];
    })
  };
}

function path(name, points, open = true) {
  const edges = open ? points.length - 1 : points.length;
  const lengths = [];
  let total = 0;
  for (let i = 0; i < edges; i++) {
    const a = points[i];
    const b = points[(i + 1) % points.length];
    total += Math.hypot(b[0] - a[0], b[1] - a[1]);
    lengths.push(total);
  }
  const rails = Array.from({ length: RAILS }, (_, index) => {
    const distance = total * index / (open ? RAILS - 1 : RAILS);
    const edge = lengths.findIndex(length => length >= distance);
    const previous = edge ? lengths[edge - 1] : 0;
    const fraction = (distance - previous) / (lengths[edge] - previous);
    const a = points[edge];
    const b = points[(edge + 1) % points.length];
    return [a[0] + (b[0] - a[0]) * fraction, a[1] + (b[1] - a[1]) * fraction];
  });
  return { name, open, rails };
}

const plusRadius = angle => {
  const x = Math.abs(Math.cos(angle));
  const y = Math.abs(Math.sin(angle));
  return Math.max(Math.min(1 / x, 0.42 / y), Math.min(0.42 / x, 1 / y));
};

// Sixteen rails form sixteen sectors on closed webs, or fifteen on open webs.
// The contour is sampled by distance so open sectors remain playable at their ends.
const LAYOUTS = [
  radial('CIRCLE', () => 1),
  radial('SQUARE', angle => 1 / Math.max(Math.abs(Math.cos(angle)), Math.abs(Math.sin(angle)))),
  radial('PLUS', plusRadius),
  radial('BOWTIE', angle => 0.47 + 0.53 * Math.abs(Math.cos(angle)) ** 3),
  radial('CROSS', angle => 0.7 + 0.3 * Math.abs(Math.cos(angle * 2)) ** 4),
  path('TRIANGLE', [[0, -1], [1, 0.75], [-1, 0.75]], false),
  radial('CLOVER', angle => 0.8 + 0.2 * Math.cos(angle * 4)),
  path('V', [[-1, -0.75], [0, 0.9], [1, -0.75]]),
  path('STEPS', [[-1, 0.8], [-0.7, 0.8], [-0.7, 0.4], [-0.3, 0.4], [-0.3, 0], [0.1, 0], [0.1, -0.4], [0.5, -0.4], [0.5, -0.8], [1, -0.8]]),
  path('U', [[-1, -0.8], [-1, 0.25], [-0.8, 0.7], [-0.4, 0.9], [0.4, 0.9], [0.8, 0.7], [1, 0.25], [1, -0.8]]),
  path('FLAT', [[-1, 0], [1, 0]]),
  path('HEART', [[-1, 0.75], [-0.9, -0.25], [-0.55, -0.8], [-0.25, -0.75], [0, -0.35], [0.25, -0.75], [0.55, -0.8], [0.9, -0.25], [1, 0.75]]),
  radial('STAR', (_angle, index) => index % 2 ? 0.55 : 1),
  path('W', [[-1, -0.75], [-0.56, 0.8], [0, -0.2], [0.56, 0.8], [1, -0.75]]),
  path('FAN', [[-1, -0.65], [-0.75, -0.2], [-0.45, 0.45], [-0.15, 0.8], [0.15, 0.4], [0.4, 0.7], [0.65, 0.15], [0.85, 0.15], [1, -0.45]]),
  path('INFINITY', Array.from({ length: RAILS }, (_, index) => {
    const angle = index * TAU / RAILS;
    const denominator = 1 + Math.sin(angle) ** 2;
    return [Math.cos(angle) / denominator, 1.35 * Math.sin(angle) * Math.cos(angle) / denominator];
  }), false)
];

const TUBES = LAYOUTS.map(layout => layout.name);
const tubeLayoutForWave = wave => LAYOUTS[Math.max(0, wave - 1) % LAYOUTS.length];
const tubeForWave = wave => tubeLayoutForWave(wave).name;
const laneCountForWave = wave => tubeLayoutForWave(wave).open ? RAILS - 1 : RAILS;

module.exports = { TUBES, RAILS, tubeForWave, tubeLayoutForWave, laneCountForWave };
