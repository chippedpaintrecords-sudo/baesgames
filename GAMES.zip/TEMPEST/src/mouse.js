'use strict';

// Route ordinary keys to readline while consuming both SGR and older X10
// mouse reports. A terminal without SGR support can still send X10 reports
// after mouse tracking is enabled; those bytes must not become keystrokes.
class WheelInput {
  constructor() {
    this.sequence = '';
  }

  get pending() {
    return this.sequence.length > 0;
  }

  flush() {
    const keyboard = this.sequence === '\x1b' || this.sequence === '\x1b[' ? this.sequence : '';
    this.sequence = '';
    return keyboard;
  }

  feed(chunk) {
    let keyboard = '';
    const moves = [];
    for (const char of String(chunk)) {
      if (!this.sequence) {
        if (char === '\x1b') this.sequence = char;
        else keyboard += char;
      } else if (this.sequence === '\x1b') {
        if (char === '[') this.sequence += char;
        else {
          keyboard += this.sequence + char;
          this.sequence = '';
        }
      } else if (this.sequence === '\x1b[') {
        if (char === '<' || char === 'M') this.sequence += char;
        else {
          keyboard += this.sequence + char;
          this.sequence = '';
        }
      } else if (this.sequence.startsWith('\x1b[M')) {
        this.sequence += char;
        if (this.sequence.length === 6) {
          const button = this.sequence.charCodeAt(3) - 32;
          if (button >= 64 && button < 96 && (button & 3) < 2) {
            moves.push(button & 1 ? 1 : -1);
          }
          this.sequence = '';
        }
      } else if (/^[\d;]$/.test(char) && this.sequence.length < 48) {
        this.sequence += char;
      } else {
        if (char === 'M') {
          const report = /^\x1b\[<(\d+);(\d+);(\d+)$/.exec(this.sequence);
          if (report) {
            const button = Number(report[1]);
            if (button >= 64 && button < 96 && (button & 3) < 2) {
              moves.push(button & 1 ? 1 : -1);
            }
          }
        }
        this.sequence = char === '\x1b' ? char : '';
      }
    }
    return { keyboard, moves };
  }
}

module.exports = { WheelInput };
