'use strict';

const { LANES, pulseState } = require('./game');
const { tubeLayoutForWave } = require('./geometry');
const { Canvas } = require('./graphics');

const C = {
  dim: [64, 88, 118],
  core: [40, 88, 132],
  player: [255, 238, 98],
  lane: [255, 218, 70],
  laneShade: [56, 44, 0],
  shot: [249, 252, 255],
  shotTrail: [83, 171, 211],
  enemyShot: [255, 95, 71],
  flipper: [255, 82, 146],
  tanker: [255, 169, 64],
  pulsar: [192, 105, 255],
  spiker: [96, 255, 169],
  spike: [53, 231, 116],
  fuseball: [106, 255, 245],
  pulseShade: [35, 12, 54],
  pulseActive: [75, 18, 85],
  effect: [255, 250, 135],
  text: [199, 231, 242],
  danger: [255, 96, 105],
  hud: [8, 15, 29],
  panel: [9, 18, 34]
};
const BASE_COLORS = C;
const THEMES = [[58, 212, 245], [255, 89, 105], [255, 207, 83], [87, 235, 232], [18, 23, 31], [130, 236, 105]];
const ERA_COLORS = [
  { player: [255, 238, 98], lane: [255, 218, 70], flipper: [255, 92, 98], tanker: [189, 110, 255],
    spiker: [96, 255, 169], spike: [53, 231, 116], pulsar: [192, 105, 255], effect: [255, 250, 135] },
  { player: [102, 246, 120], lane: [102, 246, 120], flipper: [181, 100, 245], tanker: [80, 170, 255],
    spiker: [95, 250, 240], spike: [65, 225, 225], pulsar: [255, 220, 75], effect: [95, 250, 240] },
  { player: [95, 172, 255], lane: [95, 172, 255], flipper: [112, 245, 126], tanker: [90, 225, 245],
    spiker: [255, 92, 106], spike: [240, 68, 90], pulsar: [98, 175, 255], effect: [95, 172, 255] },
  { player: [95, 172, 255], lane: [95, 172, 255], flipper: [112, 245, 126], tanker: [189, 110, 255],
    spiker: [255, 92, 106], spike: [240, 68, 90], pulsar: [255, 220, 75], effect: [255, 92, 106] },
  { player: [255, 238, 98], lane: [255, 218, 70], flipper: [255, 92, 98], tanker: [189, 110, 255],
    spiker: [96, 255, 169], spike: [53, 231, 116], pulsar: [95, 250, 240], effect: [249, 252, 255] },
  { player: [255, 95, 103], lane: [255, 95, 103], flipper: [255, 225, 85], tanker: [189, 110, 255],
    spiker: [95, 172, 255], spike: [65, 145, 245], pulsar: [255, 220, 75], effect: [189, 110, 255] }
];
const BONUS_RAINBOW = [[255, 95, 110], [255, 225, 85], [95, 246, 125],
  [80, 223, 245], [100, 155, 255], [202, 105, 255]];
const TAU = Math.PI * 2;
const tint = (ink, amount) => ink.map(value => Math.round(value * amount));
function render(game, width, height, color = true, autoFire = false, options = {}) {
  const choosingWave = game.mode === 'title' || game.mode === 'gameover';
  const wheelHint = options.mouse ? ' / WHEEL' : '';
  const displayWave = choosingWave ? game.selectedStartWave : game.wave;
  const era = Math.min(5, Math.floor(Math.max(0, displayWave - 1) / 16));
  const eraColors = ERA_COLORS[era];
  const C = { ...BASE_COLORS, ...eraColors,
    laneShade: era ? tint(eraColors.lane, 0.18) : BASE_COLORS.laneShade,
    pulseShade: tint(eraColors.pulsar, 0.13), pulseActive: tint(eraColors.pulsar, 0.3) };
  const canvas = new Canvas(width, height, color, Boolean(options.ascii));
  if (width < 60 || height < 22) {
    canvas.centered(Math.floor(height / 2) - 1, 'TEMPEST needs a larger terminal', C.danger);
    canvas.centered(Math.floor(height / 2) + 1, 'Resize to at least 60 x 22', C.text);
    return canvas.output();
  }

  const layout = choosingWave ? tubeLayoutForWave(displayWave) : game.tubeLayout;
  const displayTube = layout.name;
  const laneCount = layout.open ? LANES - 1 : LANES;
  const rimInk = THEMES[era];
  const hudInk = era === 4 ? C.text : rimInk;
  const top = 3;
  const bottom = height - 5;
  const cx = Math.floor(width / 2);
  const cy = (top + bottom) / 2;
  const ry = (bottom - top) / 2 / 1.16;
  const rx = Math.min((width - 8) / 2 / 1.12, ry * 2.3);
  const core = [cx - rx * 0.18, cy - ry * 0.12];
  const point = (rail, depth) => {
    const position = layout.open ? Math.max(0, Math.min(LANES - 1, rail)) : ((rail % LANES) + LANES) % LANES;
    const index = Math.floor(position);
    const fraction = position - index;
    const a = layout.rails[index];
    const b = layout.rails[(index + 1) % LANES];
    const x = a[0] + (b[0] - a[0]) * fraction;
    const y = a[1] + (b[1] - a[1]) * fraction;
    const outer = [cx + x * rx, cy + y * ry];
    const inner = [core[0] + x * rx * 0.09, core[1] + y * ry * 0.09];
    return [inner[0] + (outer[0] - inner[0]) * depth, inner[1] + (outer[1] - inner[1]) * depth];
  };
  const lanePoint = (lane, depth) => point(lane + 0.5, depth);
  const laneTransform = (lane, position, size) => {
    const left = point(lane, 1);
    const right = point(lane + 1, 1);
    const outward = lanePoint(lane, 1);
    const inward = lanePoint(lane, 0);
    return localTransform(position, [right[0] - left[0], right[1] - left[1]],
      [outward[0] - inward[0], outward[1] - inward[1]], size);
  };
  const ring = (depth, ink, priority = 1, glow = false, gaps = null) => {
    for (let i = 0; i < laneCount; i++) {
      if (gaps?.has(i)) continue;
      canvas.stroke(point(i, depth), point(i + 1, depth), ink, priority, glow, '#');
    }
  };
  const lanePolygon = lane => {
    return [point(lane, 0), point(lane, 1), point(lane + 1, 1), point(lane + 1, 0)];
  };
  const energized = new Map();
  for (const enemy of game.enemies) {
    const state = pulseState(enemy);
    if (state !== 'idle' && energized.get(enemy.lane) !== 'active') energized.set(enemy.lane, state);
  }
  const showingPlayer = game.mode === 'playing' || game.mode === 'paused';

  // Static, sparse stars keep the arena still while the action animates.
  for (let y = top; y <= bottom; y++) {
    for (let x = 2; x < width - 2; x++) {
      const dx = (x - cx) / rx;
      const dy = (y - cy) / ry;
      if (Math.hypot(dx, dy) < 1.35) continue;
      const hash = ((x * 73856093) ^ (y * 19349663)) >>> 0;
      if (hash % 89 !== 0) continue;
      if (canvas.ascii) canvas.put(x, y, '.', C.dim);
      else canvas.dot(x, y, hash % 3 ? tint(C.dim, 0.65) : C.dim, 0);
    }
  }

  if (showingPlayer) canvas.shadePolygon(lanePolygon(game.playerLane), C.laneShade);
  for (const [lane, state] of energized) {
    canvas.shadePolygon(lanePolygon(lane), state === 'active' ? C.pulseActive : C.pulseShade);
  }

  for (const depth of [0, 0.26, 0.52, 0.76]) ring(depth, tint(rimInk, 0.14 + depth * 0.18));
  for (let lane = 0; lane < LANES; lane++) {
    for (let step = 0; step < 8; step++) {
      canvas.stroke(point(lane, step / 8), point(lane, (step + 1) / 8), tint(rimInk, 0.18 + step / 8 * 0.36));
    }
  }
  ring(1, rimInk, 2, true, energized);
  if (game.effects.some(effect => effect.kind === 'bonusLife')) {
    const phase = Math.floor(game.time * 16);
    for (let lane = 0; lane < LANES; lane++) {
      const ink = BONUS_RAINBOW[(lane + phase) % BONUS_RAINBOW.length];
      canvas.stroke(point(lane, 0), point(lane, 1), ink, 3, true, '#');
      if (lane < laneCount && !energized.has(lane)) {
        canvas.stroke(point(lane, 1), point(lane + 1, 1), ink, 3, true, '#');
      }
    }
  }
  for (let lane = 0; lane < laneCount; lane++) {
    const tip = game.spikes?.[lane] || 0;
    if (tip <= 0.13) continue;
    if (canvas.ascii) {
      canvas.stroke(lanePoint(lane, 0.12), lanePoint(lane, tip), C.spike, 4, false, '|');
      canvas.put(...lanePoint(lane, tip), '^', C.spiker);
    } else {
      const zigzag = [];
      const steps = Math.max(2, Math.ceil((tip - 0.12) * 18));
      for (let i = 0; i <= steps; i++) {
        const depth = 0.12 + (tip - 0.12) * i / steps;
        const offset = i === 0 || i === steps ? 0 : (i % 2 ? 0.035 : -0.035);
        zigzag.push(point(lane + 0.5 + offset, depth));
      }
      canvas.path(zigzag, C.spike, 4, true);
      canvas.dot(...lanePoint(lane, tip), C.spiker, 5, true);
    }
  }
  if (canvas.ascii) canvas.put(...core, 'O', C.core);
  else {
    canvas.stroke([core[0] - 0.5, core[1]], [core[0] + 0.5, core[1]], C.core);
    canvas.dot(...core, rimInk, 3, true);
  }

  if (showingPlayer) {
    const a = game.playerLane;
    const b = a + 1;
    canvas.stroke(point(a, 0), point(a, 1), tint(C.lane, 0.7), 3);
    canvas.stroke(point(b, 0), point(b, 1), tint(C.lane, 0.7), 3);
    if (!energized.has(game.playerLane)) {
      for (let i = 0; i < 6; i++) {
        canvas.stroke(point(a + (b - a) * i / 6, 1), point(a + (b - a) * (i + 1) / 6, 1), C.lane, 3, true, '#');
      }
    }
    if (canvas.ascii) canvas.stroke(lanePoint(game.playerLane, 0), lanePoint(game.playerLane, 1), C.lane, 3, false, ':');
  }

  for (const [lane, state] of energized) {
    if (state === 'active') {
      const flash = [C.pulsar, C.shot, C.effect][Math.floor(game.time * 12) % 3];
      for (const rail of [lane, lane + 1]) {
        canvas.stroke(point(rail, 0.56), point(rail, 1), flash, 4, true, '!');
      }
    }
    if (canvas.ascii) {
      canvas.stroke(lanePoint(lane, 0), lanePoint(lane, 1), C.pulsar, 4, false, state === 'active' ? '+' : '~');
      continue;
    }
    const beam = [];
    for (let i = 0; i <= 16; i++) {
      const spread = state === 'active' ? 0.3 : 0.12;
      const offset = i % 2 ? spread : -spread;
      beam.push(point(lane + 0.5 + offset, i / 16));
    }
    canvas.path(beam, state === 'active' ? [236, 189, 255] : C.pulsar, 4, state === 'active');
  }

  for (const shot of game.shots) {
    if (canvas.ascii) {
      canvas.put(...lanePoint(shot.lane, shot.depth), '*', C.shot);
    } else {
      const tail = Math.min(1, shot.depth + 0.15);
      const middle = (tail + shot.depth) / 2;
      canvas.stroke(lanePoint(shot.lane, tail), lanePoint(shot.lane, middle), tint(C.shotTrail, 0.55), 4);
      canvas.stroke(lanePoint(shot.lane, middle), lanePoint(shot.lane, shot.depth), C.shotTrail, 4, true);
      canvas.dot(...lanePoint(shot.lane, shot.depth), C.shot, 7, true);
    }
  }
  // Far objects are drawn first, so overlapping near threats stay visible.
  for (const enemy of [...game.enemies].sort((a, b) => a.depth - b.depth)) {
    const rail = enemy.jump
      ? enemy.jump.from + (enemy.jump.to - enemy.jump.from) * enemy.jump.progress
      : enemy.lane;
    const position = enemy.type === 'fuseball' && !enemy.onRim
      ? point(rail, enemy.depth) : lanePoint(enemy.lane, enemy.depth);
    if (canvas.ascii) {
      const tankerGlyph = enemy.cargoType === 'fuseball' ? 'O' : enemy.cargoType === 'pulsar' ? 'P' : 'T';
      const glyph = enemy.onRim ? '!' : enemy.type === 'flipper' ? 'F'
        : enemy.type === 'tanker' ? tankerGlyph : enemy.type === 'spiker' ? 'S'
          : enemy.type === 'fuseball' ? enemy.jump && enemy.jump.progress >= 0.2 && enemy.jump.progress <= 0.8 ? '@' : 'o'
            : pulseState(enemy) === 'active' ? 'P' : 'p';
      canvas.put(...position, glyph, enemy.onRim ? C.danger : C[enemy.type]);
      continue;
    }
    const size = (0.6 + enemy.depth * 0.7) * Math.min(1.4, Math.max(0.8, ry / 10));
    const ink = enemy.onRim ? C.danger : C[enemy.type];
    const orient = laneTransform(enemy.lane, position, size);
    if (enemy.onRim) {
      canvas.path([[-1, 0.5], [0, -0.75], [1, 0.5]].map(orient), ink, 6, true);
      canvas.dot(...position, C.shot, 6);
    } else if (enemy.type === 'flipper') {
      const flip = Math.sin(game.time * 6 + enemy.id) * 0.25;
      const shape = [[-1, -0.65], [1, 0.65], [1, -0.65], [-1, 0.65], [-1, -0.65]];
      canvas.path(shape.map(([x, y]) => orient([x, y + x * flip])), ink, 6, true);
    } else if (enemy.type === 'tanker') {
      canvas.path([[0, -1], [1, 0], [0, 1], [-1, 0], [0, -1]].map(orient), ink, 6, true);
      if (enemy.cargoType === 'fuseball') {
        canvas.dot(...position, C.fuseball, 8, true);
      } else if (enemy.cargoType === 'pulsar') {
        canvas.stroke(orient([-0.4, -0.3]), orient([0.1, 0.1]), C.pulsar, 8, true);
        canvas.stroke(orient([0.1, 0.1]), orient([0.4, -0.25]), C.pulsar, 8, true);
      } else {
        canvas.stroke(orient([-0.4, 0]), orient([0.4, 0]), C.flipper, 8, true);
      }
    } else if (enemy.type === 'spiker') {
      const spiral = [];
      for (let i = 0; i <= 16; i++) {
        const angle = i / 16 * TAU * 1.75 + game.time * 4;
        const radius = 1 - i / 18;
        spiral.push(orient([Math.cos(angle) * radius, Math.sin(angle) * radius]));
      }
      canvas.path(spiral, ink, 6, true);
    } else if (enemy.type === 'fuseball') {
      const ring = [];
      for (let i = 0; i <= 8; i++) {
        const angle = i / 8 * TAU;
        ring.push(orient([Math.cos(angle) * 0.8, Math.sin(angle) * 0.8]));
      }
      canvas.path(ring, ink, 6, true);
      canvas.stroke(orient([-1.2, -0.25]), orient([1.2, 0.25]), C.shot, 7, true);
    } else {
      const shape = [];
      for (let i = 0; i <= 8; i++) {
        const angle = i / 8 * TAU + enemy.pulse * 0.8;
        const radius = i % 2 ? 0.38 : 1.15;
        shape.push(orient([Math.cos(angle) * radius, Math.sin(angle) * radius]));
      }
      canvas.path(shape, pulseState(enemy) === 'active' ? [236, 189, 255] : ink, 6, true);
    }
  }

  for (const enemyShot of game.enemyShots || []) {
    if (canvas.ascii) {
      canvas.put(...lanePoint(enemyShot.lane, enemyShot.depth), 'x', C.enemyShot);
    } else {
      const tail = Math.max(0, enemyShot.depth - 0.11);
      canvas.stroke(lanePoint(enemyShot.lane, tail), lanePoint(enemyShot.lane, enemyShot.depth), C.enemyShot, 7, true);
      canvas.dot(...lanePoint(enemyShot.lane, enemyShot.depth), C.enemyShot, 8, true);
    }
  }

  for (const effect of game.effects) {
    if (effect.kind === 'bonusLife') continue;
    const duration = effect.duration || (effect.char === 'X' ? 0.6 : effect.char === '+' ? 0.18 : 0.35);
    const age = Math.max(0, Math.min(1, 1 - effect.time / duration));
    if (effect.kind === 'zapWave') {
      if (canvas.ascii) ring(age, C.effect, 5);
      else ring(age * 1.12, tint(C.shot, 1 - age * 0.7), 7, true);
      continue;
    }
    const position = lanePoint(effect.lane, effect.depth);
    if (canvas.ascii) {
      canvas.put(...position, effect.char, C.effect);
      continue;
    }
    const hit = effect.char === 'X';
    const ink = tint(hit ? C.danger : C.effect, 1 - age * 0.55);
    const radius = (0.4 + age * (hit ? 3.5 : 2.2)) * Math.min(1.4, Math.max(0.8, ry / 10));
    for (let i = 0; i < 8; i++) {
      const angle = i / 8 * TAU + effect.lane * 0.37;
      const head = [position[0] + Math.cos(angle) * radius, position[1] + Math.sin(angle) * radius / 2];
      const tail = [position[0] + Math.cos(angle) * radius * 0.6, position[1] + Math.sin(angle) * radius * 0.3];
      canvas.stroke(tail, head, ink, 7, age < 0.5);
    }
    if (age < 0.3) canvas.dot(...position, C.shot, 8, true);
  }

  if (showingPlayer && (game.invulnerable <= 0 || Math.floor(game.time * 10) % 2 === 0)) {
    const position = lanePoint(game.playerLane, game.wavePhase === 'warp' ? game.warpDepth : 1.035);
    if (canvas.ascii) canvas.put(...position, 'A', C.player);
    else {
      const orient = laneTransform(game.playerLane, position, Math.min(1.45, Math.max(0.85, ry / 9)));
      const ship = [[-1.8, 0.15], [-1.15, -0.8], [0, -0.35], [1.15, -0.8], [1.8, 0.15], [0.65, 0.7], [-0.65, 0.7], [-1.8, 0.15]];
      canvas.path(ship.map(orient), C.player, 8, true);
      canvas.stroke(orient([-0.5, 0.3]), orient([0.5, 0.3]), C.shot, 8, true);
    }
  }

  drawHud(canvas, game, hudInk, autoFire, energized, displayWave, displayTube, wheelHint);
  if (game.mode === 'title') {
    const selection = `START WAVE ${game.selectedStartWave}  ${displayTube}  BONUS ${game.selectedStartBonus}`;
    if (canvas.ascii) {
      panel(canvas, Math.floor(cy) - 4, ['***  T E M P E S T  ***', 'Defend the rim. Clear the tube.', 'F: flipper  T: tanker  S: spiker  !: runner', 'Pulsars charge. Spikes linger into warp.', `Auto fire is on. Steer with ARROWS / A D${wheelHint}.`, selection, `ARROWS / A D${wheelHint}: CHOOSE START WAVE`, 'ENTER to start'], hudInk);
    } else {
      const panelTop = Math.floor(cy) - 4;
      panel(canvas, panelTop, ['', '', '', 'Defend the rim. Clear the tube.', 'Flippers flip. Tankers split. Spikers lay spikes.', selection, `ARROWS / A D${wheelHint}: CHOOSE START WAVE`, 'ENTER TO START'], hudInk, 49);
      canvas.logo((width - 41) / 2, panelTop + 0.2, 'TEMPEST', hudInk);
    }
  } else if (game.mode === 'gameover') {
    panel(canvas, Math.floor(cy) - 3, ['GAME OVER', `FINAL SCORE  ${game.score}`, `BEST  ${game.highScore}    WAVE  ${game.wave}`, `START WAVE ${game.selectedStartWave}  ${displayTube}  BONUS ${game.selectedStartBonus}`, `ARROWS / A D${wheelHint}: CHOOSE START WAVE`, 'ENTER to play again'], C.danger);
  } else if (game.mode === 'paused') {
    panel(canvas, Math.floor(cy) - 1, ['PAUSED', 'P to resume'], hudInk);
  } else if (game.messageTime > 0) {
    const label = ` ${game.message} `;
    const left = Math.floor((width - label.length) / 2);
    canvas.fillRect(left, Math.round(core[1]), label.length, 1, C.panel);
    canvas.text(left, Math.round(core[1]), label, game.message === 'HULL HIT!' || game.message === 'SPIKE HIT!' ? C.danger : C.player);
  }
  return canvas.output();
}

function localTransform(position, tangent, outward, size) {
  const length = Math.hypot(...tangent) || 1;
  const tx = tangent[0] / length;
  const ty = tangent[1] / length;
  const sign = -ty * outward[0] + tx * outward[1] < 0 ? -1 : 1;
  const nx = -ty * sign;
  const ny = tx * sign;
  return ([x, y]) => [position[0] + (tx * x + nx * y * 0.55) * size,
    position[1] + (ty * x + ny * y * 0.55) * size];
}

function drawHud(canvas, game, rimInk, autoFire, energized, displayWave, displayTube, wheelHint) {
  const { width, height, ascii } = canvas;
  canvas.fillRect(0, 0, width, 3, C.hud);
  canvas.fillRect(0, height - 3, width, 3, C.hud);
  const score = `SCORE ${String(game.score).padStart(6, '0')}`;
  const best = `BEST ${String(game.highScore).padStart(6, '0')}`;
  const zapState = game.mode === 'title' ? 'FULL' : game.zappers === 2 ? 'FULL' : game.zappers === 1 ? 'SINGLE' : 'EMPTY';
  const lives = `LIVES ${'A'.repeat(game.lives).padEnd(5)}  ZAPPER ${zapState}`;
  canvas.text(2, 0, 'T E M P E S T', rimInk);
  canvas.centered(0, score, C.text);
  canvas.text(width - best.length - 2, 0, best, C.player);
  canvas.text(2, 1, `WAVE ${String(displayWave).padStart(2, '0')}  ${displayTube}`, rimInk);
  canvas.text(width - lives.length - 2, 1, lives, game.lives <= 1 ? C.danger : C.player);
  canvas.text(0, 2, (ascii ? '-' : '\u2500').repeat(width), tint(rimInk, 0.3));
  canvas.text(2, 2, ` AUTO ${autoFire ? 'ON' : 'OFF'} (F)  ${ascii ? 'ASCII' : 'VECTOR'} (G) `, C.text);
  const bonus = ` BONUS LIFE AT ${String(game.nextBonusLife).padStart(6, '0')} `;
  canvas.text(width - bonus.length - 2, 2, bonus, C.dim);
  if (game.mode === 'playing' || game.mode === 'paused') {
    const remaining = game.spawnRemaining + game.enemies.length;
    const progress = Math.round(16 * Math.max(0, 1 - remaining / Math.max(1, game.waveTotal)));
    const bar = (ascii ? '#' : '\u2588').repeat(progress) + (ascii ? '-' : '\u2591').repeat(16 - progress);
    canvas.text(2, height - 3, `LEFT ${String(remaining).padStart(2, '0')}  [${bar}]`, rimInk);
    const incomingShot = game.enemyShots?.some(shot => shot.lane === game.playerLane && shot.depth > 0.72);
    const warning = game.wavePhase === 'warp' ? 'WARP! DODGE SPIKES!' : energized.get(game.playerLane) === 'active' ? 'PULSE! MOVE!' : energized.get(game.playerLane) === 'charging' ? 'LANE CHARGING!' : incomingShot ? 'INCOMING SHOT!' : [...energized.values()].includes('active') ? 'PULSE ACTIVE' : '';
    canvas.text(width - warning.length - 2, height - 3, warning, C.danger);
  }
  canvas.centered(height - 2, `ARROWS / A D${wheelHint}: MOVE   SPACE: FIRE   Z: ZAP`, C.text);
  canvas.centered(height - 1, 'F: AUTO FIRE   G: GRAPHICS   P: PAUSE   Q / ESC: QUIT', C.text);
}

function panel(canvas, top, lines, ink, minimumWidth = 0) {
  const width = Math.min(canvas.width - 4, Math.max(minimumWidth, ...lines.map(line => line.length + 6)));
  const left = Math.floor((canvas.width - width) / 2);
  canvas.fillRect(left, top - 1, width, lines.length + 2, C.panel);
  const edge = canvas.ascii ? ['+', '-', '|', '+', '+', '+'] : ['\u256d', '\u2500', '\u2502', '\u256e', '\u2570', '\u256f'];
  canvas.text(left, top - 1, edge[0] + edge[1].repeat(width - 2) + edge[3], ink);
  canvas.text(left, top + lines.length, edge[4] + edge[1].repeat(width - 2) + edge[5], ink);
  for (let y = top; y < top + lines.length; y++) {
    canvas.put(left, y, edge[2], tint(ink, 0.5));
    canvas.put(left + width - 1, y, edge[2], tint(ink, 0.5));
  }
  lines.forEach((line, index) => canvas.centered(top + index, line, index === 0 || index === lines.length - 1 ? C.player : C.text));
}

function createRenderer() {
  let previousRows = [];
  let previousSize = '';
  return (game, width, height, color = true, autoFire = false, options = {}) => {
    const rows = render(game, width, height, color, autoFire, options).match(/\x1b\[\d+;1H[\s\S]*?(?=\x1b\[\d+;1H|$)/g) || [];
    const size = `${width}:${height}:${color}:${Boolean(options.ascii)}`;
    let output = '';
    if (size !== previousSize) {
      output = '\x1b[2J';
      previousRows = [];
      previousSize = size;
    }
    rows.forEach((row, index) => {
      if (row !== previousRows[index]) output += row;
    });
    previousRows = rows;
    return output ? output + '\x1b[0m' : '';
  };
}

module.exports = { render, createRenderer };
