'use strict';

const readline = require('node:readline');
const { performance } = require('node:perf_hooks');
const { PassThrough } = require('node:stream');
const { Game } = require('./game');
const { createRenderer } = require('./render');
const { loadHighScore, saveHighScore } = require('./scores');
const { WheelInput } = require('./mouse');

if (!process.stdin.isTTY || !process.stdout.isTTY) {
  console.error('Run this game in an interactive terminal.');
  process.exit(1);
}

const game = new Game(Math.random, loadHighScore());
const draw = createRenderer();
let autoFire = true;
let ascii = process.argv.includes('--ascii');
let lastFrame = performance.now();
let running = true;
let timer;
const color = !Object.hasOwn(process.env, 'NO_COLOR');
const mouseEnabled = !process.argv.includes('--no-mouse');
const wheelInput = new WheelInput();
const keyboardInput = new PassThrough();
let pendingInputTimer;

function terminalFits() {
  return (process.stdout.columns || 80) >= 60 && (process.stdout.rows || 24) >= 22;
}

function cleanup() {
  if (!running) return;
  running = false;
  clearInterval(timer);
  clearTimeout(pendingInputTimer);
  process.stdin.setRawMode(false);
  process.stdin.pause();
  process.stdout.write((mouseEnabled ? '\x1b[?1006l\x1b[?1000l' : '') + '\x1b[0m\x1b[?25h\x1b[?1049l');
  saveHighScore(game.highScore);
}

function quit() {
  cleanup();
  process.exit(0);
}

function steer(direction) {
  if (game.mode === 'title' || game.mode === 'gameover') game.selectStartWave(direction);
  else if (game.mode === 'playing' && terminalFits()) {
    game.move(direction);
    if (autoFire) game.fire();
  }
}

readline.emitKeypressEvents(keyboardInput);
process.stdin.setRawMode(true);
process.stdin.resume();
process.stdout.write('\x1b[?1049h\x1b[?25l\x1b[2J\x1b[H' +
  (mouseEnabled ? '\x1b[?1000h\x1b[?1006h' : ''));

process.stdin.on('data', chunk => {
  const { keyboard, moves } = wheelInput.feed(chunk);
  if (keyboard) keyboardInput.write(keyboard);
  if (mouseEnabled) for (const direction of moves) steer(direction);
  clearTimeout(pendingInputTimer);
  if (wheelInput.pending) {
    pendingInputTimer = setTimeout(() => {
      const pending = wheelInput.flush();
      if (pending) keyboardInput.write(pending);
    }, 50);
  }
});

keyboardInput.on('keypress', (_chunk, key) => {
  if (!key) return;
  if ((key.ctrl && key.name === 'c') || key.name === 'q' ||
      (key.name === 'escape' && key.sequence === '\x1b')) return quit();
  if (key.name === 'return' && (game.mode === 'title' || game.mode === 'gameover')) {
    if (!terminalFits()) return;
    saveHighScore(game.highScore);
    game.start();
    autoFire = true;
    return;
  }
  if (key.name === 'p') {
    game.togglePause();
    return;
  }
  if (key.name === 'g') {
    ascii = !ascii;
    return;
  }
  if (game.mode === 'title' || game.mode === 'gameover') {
    if (key.name === 'left' || key.name === 'a') steer(-1);
    else if (key.name === 'right' || key.name === 'd') steer(1);
    return;
  }
  if (game.mode !== 'playing' || !terminalFits()) return;
  if (key.name === 'left' || key.name === 'a') steer(-1);
  else if (key.name === 'right' || key.name === 'd') steer(1);
  else if (key.name === 'space') game.fire();
  else if (key.name === 'f') autoFire = !autoFire;
  else if (key.name === 'z') game.zap();
});

timer = setInterval(() => {
  const now = performance.now();
  const dt = (now - lastFrame) / 1000;
  lastFrame = now;
  const width = process.stdout.columns || 80;
  const height = process.stdout.rows || 24;
  const previousMode = game.mode;
  if (terminalFits()) {
    if (autoFire) game.fire();
    game.update(dt);
  }
  if (previousMode !== 'gameover' && game.mode === 'gameover') saveHighScore(game.highScore);
  if (process.stdout.writableNeedDrain) return;
  const screen = draw(game, width, height, color, autoFire, { ascii, mouse: mouseEnabled });
  if (screen) process.stdout.write(screen);
}, 33);

process.on('SIGINT', quit);
process.on('SIGTERM', quit);
process.on('exit', cleanup);
