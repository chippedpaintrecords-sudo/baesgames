'use strict';

const fs = require('node:fs');
const path = require('node:path');

const SCORE_FILE = path.join(__dirname, '..', '.data', 'high-score.json');

function loadHighScore(file = SCORE_FILE) {
  try {
    const { highScore } = JSON.parse(fs.readFileSync(file, 'utf8'));
    return Number.isSafeInteger(highScore) && highScore >= 0 ? highScore : 0;
  } catch {
    return 0;
  }
}

function saveHighScore(highScore, file = SCORE_FILE) {
  if (!Number.isSafeInteger(highScore) || highScore < 0) return false;
  try {
    if (loadHighScore(file) >= highScore) return true;
    fs.mkdirSync(path.dirname(file), { recursive: true });
    const temporary = `${file}.${process.pid}.tmp`;
    fs.writeFileSync(temporary, JSON.stringify({ highScore }) + '\n', 'utf8');
    fs.renameSync(temporary, file);
    return true;
  } catch {
    return false;
  }
}

module.exports = { loadHighScore, saveHighScore };
