# Terminal Tempest

A fast, dependency-free terminal game inspired by the arcade classic *Tempest*.
Move around the rim, fire inward, and survive rising waves of enemies. Closed webs have 16 lanes; open webs have 15 lanes and hard ends.

Waves cycle through 16 webs, from the circle and square to the V, W, fan, flat line, star, and infinity shape. The web, ship, and enemy colors change every 16 waves; waves 65–80 use a nearly invisible web. After the green circle on wave 97 and square on wave 98, the counter stays at 99 and each new round chooses a random green web. The HUD shows enemies remaining (including those still waiting to spawn), wave progress, and your best score.

## Run

Use an interactive terminal that supports ANSI colors, at least **60 columns by 22 rows**, and Node.js 18 or newer:

```powershell
node .\src\index.js
```

On Windows, you can also double-click `run.bat`. Resizing below the minimum freezes the game until the terminal is large enough again.

## Controls

| Key | Action |
| --- | --- |
| Enter | Start or restart |
| Left / Right, A / D | Move one lane; choose a starting wave on the title or game-over screen |
| Mouse wheel | Spin around the rim; choose a starting wave on the title or game-over screen |
| Space | Fire an immediate shot |
| F | Toggle automatic fire (on by default, so you can steer and shoot together) |
| G | Switch between vector graphics and ASCII graphics |
| Z | Use the super zapper: first blast clears enemies, second picks one |
| P | Pause or resume |
| Q, Esc, Ctrl+C | Quit |

Mouse-wheel steering uses SGR mouse reports when your terminal supports them. Start with `node .\src\index.js --no-mouse` to leave terminal mouse tracking off.

Before starting, choose wave 1, 3, 5, 7, or 9 with Left / Right or A / D, then press Enter. Reaching later waves in a game unlocks higher starting choices for the next game in the same session. The selected web is previewed on the menu. Clear that starting wave to collect its displayed one-time Skill-Step bonus; later waves only award their regular clear bonus.

Flippers (`F`) switch lanes as they climb, starting with stationary targets in wave 1. Tankers (`T`) appear from wave 3. One shot splits a tanker into adjacent enemies; it also releases them if it reaches the rim. Regular tankers carry flippers. From wave 33, some carry fuseballs (marked `O` in ASCII); from wave 49, some carry pulsars (marked `P`). Their vector diamonds show a colored cargo symbol in the center.

From wave 4, spikers (`S`) climb a lane, leave a green spike behind, then retreat. Shoot a spiker for points; shoot the spike tip to shorten it. From wave 11, fuseballs (`o`) ride the rails and jump toward you. Shoot one while it crosses a lane (`@` in ASCII); it scores more points near the rim. Once on the rim, only the super zapper can destroy it. Pulsars (`p`) appear from wave 20 and ride up and down as they advance: their rim section goes dark and the lane shows `~` as they charge, then the bordering rails flash and the lane shows `+` when the pulse is live. Move out of that lane or destroy the pulsar before it fires. Enemies also fire red shots (`x`) toward the rim; dodge or intercept them with your own fire. Enemies that reach the rim become runners (`!`) and chase you. A collision, enemy shot, or pulse costs a life and gives a brief period of protection.

Clear a wave to earn a bonus of 500 points times the wave number, then ride down the tube. Steer clear of lingering spikes during this warp or shoot them down before your ship reaches them. The super zapper leaves spikes and enemy shots intact, and recharges at the next wave. Every 10,000 points earns another life, up to five lives, with a brief rainbow flash across the rails. Your best score is saved in `.data/high-score.json` when a game ends or you quit. If that folder cannot be written, you can still play with a best score for the current session.

Your current lane glows amber from the core to the rim. Automatic fire follows your ship as you move and can keep up to eight shots in flight; press **F** if you prefer to fire manually with **Space**.

## Graphics

The default renderer uses Unicode braille cells as a fine pixel grid: each terminal cell holds eight dots. The tube has a receding core, depth shading, a glowing rim, and a sparse star field. In the first color era, your ship is a yellow claw, flippers are red bow ties, tankers are purple diamonds, and spikers are green spirals; later eras recolor them. Fuseballs are cyan rings and rim runners are red chevrons. Shots leave light trails, enemies burst into particles, and the super zapper sends a ring through the tube.

Use a font such as Cascadia Mono or Consolas. A larger window (for example, 100 columns by 32 rows) gives the shapes more room. Press **G** at any time to switch to ASCII, or start in that mode with:

```powershell
node .\src\index.js --ascii
```

Set the `NO_COLOR` environment variable for monochrome play; highlighted lanes and pulse patterns remain visible in both graphics modes. Animations freeze while paused. The renderer updates only changed rows and redraws after a resize or graphics switch.

Run the logic tests with `node --test`.
